
from __future__ import annotations

import argparse
import math
import re
from pathlib import Path

import cobra
import numpy as np
import pandas as pd
from cobra.flux_analysis import pfba, flux_variability_analysis


DEFAULT_OPEN = {
    "EX_h_e": (-1000, 1000),
    "EX_h2o_e": (-1000, 1000),
    "EX_o2_e": (-1000, 1000),
    "EX_co2_e": (-1000, 1000),
    "EX_hco3_e": (-1000, 1000),
    "EX_pi_e": (-1000, 1000),
    "EX_so4_e": (-1000, 1000),
}


def clean_id(x):
    return str(x).strip().replace("\ufeff", "").replace("\u200b", "")


def clean_condition(x):
    return str(x).strip().replace("\ufeff", "").replace("\u200b", "").replace(".0", "") if str(x).strip().endswith(".0") else str(x).strip()


def finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except Exception:
        return False


def pick_model(base: Path, model_file: str | None) -> Path:
    if model_file:
        p = Path(model_file)
        return p if p.is_absolute() else base / p

    candidates = [
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.json",
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.xml",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError("Model file not found. Use --model-file")


def load_model(model_file: Path):
    if model_file.suffix.lower() == ".json":
        return cobra.io.load_json_model(str(model_file))
    return cobra.io.read_sbml_model(str(model_file))


def set_bounds(rxn, lb, ub):
    lb, ub = float(lb), float(ub)
    if lb > ub:
        lb, ub = ub, lb
    lb = max(lb, -1000.0)
    ub = min(ub, 1000.0)
    if lb > ub:
        raise ValueError(f"Invalid bounds after clamp: {lb}, {ub}")
    rxn.bounds = (lb, ub)


def strict_bounds(row, buffer=0.5):
    if finite(row.get("lower_bound")) and finite(row.get("upper_bound")):
        lb, ub = float(row["lower_bound"]), float(row["upper_bound"])
        if lb > ub:
            lb, ub = ub, lb

        # If old lower/upper accidentally include 0 too broadly, rebuild from rate.
        rate = row.get("rate")
        if finite(rate):
            rate = float(rate)
            if rate != 0 and (lb <= 0 <= ub):
                if rate < 0:
                    lb, ub = rate * (1 + buffer), rate * (1 - buffer)
                else:
                    lb, ub = rate * (1 - buffer), rate * (1 + buffer)
                if lb > ub:
                    lb, ub = ub, lb
        return lb, ub

    rate = row.get("rate")
    if not finite(rate):
        return None
    rate = float(rate)
    if rate < 0:
        lb, ub = rate * (1 + buffer), rate * (1 - buffer)
    else:
        lb, ub = rate * (1 - buffer), rate * (1 + buffer)
    if lb > ub:
        lb, ub = ub, lb
    return lb, ub


def relaxed_bounds(row, multiplier=10.0):
    rate = row.get("rate")
    if not finite(rate):
        return None
    rate = float(rate)
    if rate < 0:
        return rate * multiplier, 0.0
    if rate > 0:
        return 0.0, rate * multiplier
    return 0.0, 0.0


def apply_constraints(model, interval_df, mode="strict", bound_buffer=0.5, relax_multiplier=10.0):
    applied = []
    warnings = []

    for rid, (lb, ub) in DEFAULT_OPEN.items():
        if rid in model.reactions:
            try:
                set_bounds(model.reactions.get_by_id(rid), lb, ub)
            except Exception as e:
                warnings.append({"reaction": rid, "issue": "default_open_failed", "detail": str(e)})

    for _, row in interval_df.drop_duplicates(subset=["exchange_rxn"], keep="last").iterrows():
        rid = clean_id(row.get("exchange_rxn", ""))
        if rid not in model.reactions:
            warnings.append({"reaction": rid, "issue": "reaction_missing", "metabolite": row.get("metabolite", "")})
            continue

        b = strict_bounds(row, bound_buffer) if mode == "strict" else relaxed_bounds(row, relax_multiplier)
        if b is None:
            warnings.append({"reaction": rid, "issue": "invalid_rate_or_bounds", "metabolite": row.get("metabolite", "")})
            continue

        rxn = model.reactions.get_by_id(rid)
        set_bounds(rxn, *b)
        applied.append({
            "reaction": rid,
            "metabolite": row.get("metabolite", ""),
            "rate": row.get("rate", np.nan),
            "lower_bound": rxn.lower_bound,
            "upper_bound": rxn.upper_bound,
            "excludes_zero": not (rxn.lower_bound <= 0 <= rxn.upper_bound),
            "mode": mode,
        })

    return pd.DataFrame(applied), pd.DataFrame(warnings)


def load_pathway_sets(pathway_file: Path, model) -> pd.DataFrame:
    df = pd.read_csv(pathway_file)
    if "pathway" not in df.columns or "reaction" not in df.columns:
        raise ValueError("Pathway file must have columns: pathway, reaction")

    df["pathway"] = df["pathway"].astype(str).str.strip()
    df["reaction"] = df["reaction"].map(clean_id)

    if "include" in df.columns:
        include = df["include"].astype(str).str.lower().isin(["true", "1", "yes", "y"])
        # If include column exists but everything is false due weird formatting, do not drop all.
        if include.sum() > 0:
            df = df[include].copy()

    model_rxns = {r.id for r in model.reactions}
    before = len(df)
    df = df[df["reaction"].isin(model_rxns)].drop_duplicates(subset=["pathway", "reaction"]).copy()
    after = len(df)
    if after == 0:
        raise ValueError(f"No pathway reactions overlap with model reactions. Before={before}, after={after}")

    return df


def solve_and_get_flux(model):
    sol = model.optimize()
    if sol.status != "optimal":
        return sol.status, sol.objective_value, sol.fluxes, "fba_not_optimal"

    try:
        psol = pfba(model)
        return psol.status, psol.objective_value, psol.fluxes, "pfba"
    except Exception as e:
        print("[WARN] pFBA failed; using FBA fluxes:", e)
        return sol.status, sol.objective_value, sol.fluxes, "fba"


def summarize_pathways(pathway_df, flux, condition, d0, d1, mode, status, obj, flux_source):
    fdf = pd.DataFrame({
        "reaction": flux.index.astype(str),
        "flux": pd.to_numeric(flux.values, errors="coerce"),
    })
    merged = pathway_df.merge(fdf, on="reaction", how="left")
    merged["flux"] = pd.to_numeric(merged["flux"], errors="coerce").fillna(0.0)
    merged["abs_flux"] = merged["flux"].abs()
    merged["active"] = merged["abs_flux"] > 1e-10

    summary = (
        merged.groupby("pathway", as_index=False)
        .agg(
            n_reactions=("reaction", "nunique"),
            pfba_sum_abs_flux=("abs_flux", "sum"),
            pfba_mean_abs_flux=("abs_flux", "mean"),
            pfba_net_flux=("flux", "sum"),
            pfba_positive_flux_sum=("flux", lambda x: x[x > 0].sum()),
            pfba_negative_flux_sum=("flux", lambda x: x[x < 0].sum()),
            pfba_nonzero_reactions=("active", "sum"),
        )
    )

    summary.insert(0, "condition", condition)
    summary.insert(1, "day_start", d0)
    summary.insert(2, "day_end", d1)
    summary.insert(3, "interval", f"{d0:g}-{d1:g}")
    summary.insert(4, "mode", mode)
    summary.insert(5, "fba_status", status)
    summary.insert(6, "objective_value", obj)
    summary.insert(7, "flux_source", flux_source)

    merged.insert(0, "condition", condition)
    merged.insert(1, "day_start", d0)
    merged.insert(2, "day_end", d1)
    merged.insert(3, "interval", f"{d0:g}-{d1:g}")
    merged.insert(4, "mode", mode)
    merged.insert(5, "flux_source", flux_source)

    return summary, merged


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--rates-file", required=True)
    ap.add_argument("--pathway-file", default="results/tables/pathway_reaction_sets_core.csv")
    ap.add_argument("--model-file", default=None)
    ap.add_argument("--objective", default=None)
    ap.add_argument("--mode", choices=["strict", "relaxed", "strict_then_relaxed"], default="strict")
    ap.add_argument("--bound-buffer", type=float, default=0.5)
    ap.add_argument("--relax-multiplier", type=float, default=10.0)
    ap.add_argument("--conditions", nargs="*", default=None)
    ap.add_argument("--run-fva", action="store_true")
    ap.add_argument("--fraction", type=float, default=0.0)
    args = ap.parse_args()

    base = Path(args.base).resolve()
    model_file = pick_model(base, args.model_file)

    rates_path = Path(args.rates_file)
    if not rates_path.is_absolute():
        rates_path = base / rates_path

    pathway_file = Path(args.pathway_file)
    if not pathway_file.is_absolute():
        pathway_file = base / pathway_file

    outdir = base / "results" / "tables" / "pathway"
    outdir.mkdir(parents=True, exist_ok=True)

    rates = pd.read_csv(rates_path)
    rates["condition"] = rates["condition"].map(clean_condition)
    rates["exchange_rxn"] = rates["exchange_rxn"].map(clean_id)
    rates["day_start"] = pd.to_numeric(rates["day_start"], errors="coerce")
    rates["day_end"] = pd.to_numeric(rates["day_end"], errors="coerce")
    rates["rate"] = pd.to_numeric(rates["rate"], errors="coerce")

    if args.conditions:
        keep = {clean_condition(x) for x in args.conditions}
        rates = rates[rates["condition"].isin(keep)].copy()

    base_model = load_model(model_file)
    pathway_df = load_pathway_sets(pathway_file, base_model)

    print("[INFO] model:", model_file)
    print("[INFO] rates:", rates_path)
    print("[INFO] pathway:", pathway_file)
    print("[INFO] pathway reactions:", pathway_df["reaction"].nunique())
    print(pathway_df.groupby("pathway")["reaction"].nunique().sort_values(ascending=False).to_string())

    intervals = (
        rates[["condition", "day_start", "day_end"]]
        .dropna()
        .drop_duplicates()
        .sort_values(["condition", "day_start", "day_end"])
    )

    all_summary = []
    all_fluxes = []
    all_fva = []
    all_applied = []
    all_warn = []
    debug_rows = []

    for _, iv in intervals.iterrows():
        cond = clean_condition(iv["condition"])
        d0 = float(iv["day_start"])
        d1 = float(iv["day_end"])

        sub = rates[
            (rates["condition"] == cond)
            & (rates["day_start"] == d0)
            & (rates["day_end"] == d1)
        ].copy()

        modes = ["strict", "relaxed"] if args.mode == "strict_then_relaxed" else [args.mode]
        done = False

        for mode in modes:
            model = load_model(model_file)
            if args.objective:
                if args.objective not in model.reactions:
                    raise ValueError(f"Objective not found in model: {args.objective}")
                model.objective = args.objective

            applied, warn = apply_constraints(
                model,
                sub,
                mode=mode,
                bound_buffer=args.bound_buffer,
                relax_multiplier=args.relax_multiplier,
            )

            status, obj, flux, flux_source = solve_and_get_flux(model)

            nonzero_model = int((pd.to_numeric(flux, errors="coerce").abs() > 1e-10).sum())
            exchange_nonzero = 0
            for rid in applied["reaction"].tolist() if not applied.empty else []:
                try:
                    if abs(float(flux.get(rid, 0))) > 1e-10:
                        exchange_nonzero += 1
                except Exception:
                    pass

            if args.mode == "strict_then_relaxed" and mode == "strict" and status != "optimal":
                print(f"[RUN] {cond} {d0:g}-{d1:g} strict={status}; retry relaxed")
                continue

            print(f"[RUN] {cond} {d0:g}-{d1:g} mode={mode} status={status} obj={obj} nonzero_model={nonzero_model} exchange_nonzero={exchange_nonzero}")

            if not applied.empty:
                applied.insert(0, "condition", cond)
                applied.insert(1, "day_start", d0)
                applied.insert(2, "day_end", d1)
                all_applied.append(applied)

            if not warn.empty:
                warn.insert(0, "condition", cond)
                warn.insert(1, "day_start", d0)
                warn.insert(2, "day_end", d1)
                warn.insert(3, "mode", mode)
                all_warn.append(warn)

            if status == "optimal":
                summary, merged_flux = summarize_pathways(pathway_df, flux, cond, d0, d1, mode, status, obj, flux_source)
                active_pathway = int(summary["pfba_nonzero_reactions"].sum())
                all_summary.append(summary)
                all_fluxes.append(merged_flux)

                if args.run_fva:
                    rxn_list = sorted(set(pathway_df["reaction"]))
                    try:
                        fva = flux_variability_analysis(model, reaction_list=rxn_list, fraction_of_optimum=args.fraction, processes=1)
                        fva = fva.reset_index().rename(columns={"index": "reaction"})
                        fva["reaction"] = fva["reaction"].map(clean_id)
                        fva["range"] = fva["maximum"] - fva["minimum"]
                        fva = fva.merge(pathway_df[["pathway", "reaction"]].drop_duplicates(), on="reaction", how="left")
                        fva.insert(0, "condition", cond)
                        fva.insert(1, "day_start", d0)
                        fva.insert(2, "day_end", d1)
                        fva.insert(3, "interval", f"{d0:g}-{d1:g}")
                        fva.insert(4, "mode", mode)
                        all_fva.append(fva)
                    except Exception as e:
                        all_warn.append(pd.DataFrame([{
                            "condition": cond,
                            "day_start": d0,
                            "day_end": d1,
                            "mode": mode,
                            "reaction": "",
                            "issue": "fva_failed",
                            "detail": str(e),
                        }]))
            else:
                active_pathway = 0
                all_summary.append(pd.DataFrame([{
                    "condition": cond,
                    "day_start": d0,
                    "day_end": d1,
                    "interval": f"{d0:g}-{d1:g}",
                    "mode": mode,
                    "fba_status": status,
                    "objective_value": obj,
                    "flux_source": flux_source,
                    "pathway": "MODEL_NOT_OPTIMAL",
                    "n_reactions": 0,
                    "pfba_sum_abs_flux": 0,
                    "pfba_mean_abs_flux": 0,
                    "pfba_net_flux": 0,
                    "pfba_positive_flux_sum": 0,
                    "pfba_negative_flux_sum": 0,
                    "pfba_nonzero_reactions": 0,
                }]))

            debug_rows.append({
                "condition": cond,
                "day_start": d0,
                "day_end": d1,
                "interval": f"{d0:g}-{d1:g}",
                "mode": mode,
                "status": status,
                "objective_value": obj,
                "flux_source": flux_source,
                "applied_constraints": len(applied),
                "applied_excluding_zero": int(applied["excludes_zero"].sum()) if not applied.empty and "excludes_zero" in applied.columns else 0,
                "nonzero_exchange_fluxes": exchange_nonzero,
                "nonzero_model_fluxes": nonzero_model,
                "active_pathway_reactions": active_pathway,
            })

            done = True
            break

        if not done:
            print(f"[WARN] no successful mode for {cond} {d0:g}-{d1:g}")

    interval_summary = pd.concat(all_summary, ignore_index=True) if all_summary else pd.DataFrame()
    reaction_fluxes = pd.concat(all_fluxes, ignore_index=True) if all_fluxes else pd.DataFrame()
    applied_df = pd.concat(all_applied, ignore_index=True) if all_applied else pd.DataFrame()
    warn_df = pd.concat(all_warn, ignore_index=True) if all_warn else pd.DataFrame()
    debug_df = pd.DataFrame(debug_rows)

    interval_summary.to_csv(outdir / "pathway_interval_summary.csv", index=False, encoding="utf-8-sig")
    reaction_fluxes.to_csv(outdir / "pathway_reaction_fluxes.csv", index=False, encoding="utf-8-sig")
    applied_df.to_csv(outdir / "pathway_applied_exchange_constraints.csv", index=False, encoding="utf-8-sig")
    warn_df.to_csv(outdir / "pathway_warnings.csv", index=False, encoding="utf-8-sig")
    debug_df.to_csv(outdir / "pathway_interval_debug.csv", index=False, encoding="utf-8-sig")

    if not interval_summary.empty:
        clone_summary = (
            interval_summary[~interval_summary["pathway"].isin(["MODEL_NOT_OPTIMAL"])]
            .groupby(["condition", "pathway"], as_index=False)
            .agg(
                mean_pfba_sum_abs_flux=("pfba_sum_abs_flux", "mean"),
                mean_pfba_net_flux=("pfba_net_flux", "mean"),
                mean_pfba_nonzero_reactions=("pfba_nonzero_reactions", "mean"),
                n_intervals=("interval", "nunique"),
            )
        )
        clone_summary.to_csv(outdir / "pathway_clone_summary.csv", index=False, encoding="utf-8-sig")

    if all_fva:
        fva_df = pd.concat(all_fva, ignore_index=True)
        fva_df.to_csv(outdir / "pathway_reaction_fva.csv", index=False, encoding="utf-8-sig")
        fva_summary = (
            fva_df.groupby(["condition", "day_start", "day_end", "interval", "mode", "pathway"], as_index=False)
            .agg(
                fva_sum_range=("range", "sum"),
                fva_mean_range=("range", "mean"),
                fva_max_range=("range", "max"),
                n_fva_reactions=("reaction", "nunique"),
            )
        )
        fva_summary.to_csv(outdir / "pathway_fva_summary.csv", index=False, encoding="utf-8-sig")

    print("[OK] saved:", outdir / "pathway_interval_summary.csv")
    print("[OK] saved:", outdir / "pathway_reaction_fluxes.csv")
    print("[OK] saved:", outdir / "pathway_clone_summary.csv")
    print("[OK] saved:", outdir / "pathway_interval_debug.csv")

    if not debug_df.empty:
        print("\n[DEBUG TOP]")
        print(debug_df.head(20).to_string(index=False))

    if not interval_summary.empty:
        print("\n[NONZERO PATHWAY SUMMARY TOP]")
        show = interval_summary.sort_values("pfba_sum_abs_flux", ascending=False)
        cols = ["condition", "interval", "pathway", "pfba_sum_abs_flux", "pfba_nonzero_reactions"]
        print(show[cols].head(30).to_string(index=False))


if __name__ == "__main__":
    main()
