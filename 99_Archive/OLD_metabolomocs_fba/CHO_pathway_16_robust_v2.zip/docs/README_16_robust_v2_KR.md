
# 16_batch_pathway_pfba_fva.py robust v2

## 왜 필요한가?

19번 diagnostic에서는:

```text
Applied constraints = 5
Nonzero model fluxes = 132
Active pathway overlap = 27
```

인데 기존 16번 결과가 모두 0이면, 16번 summary 쪽에서 pathway reaction/flux join이 제대로 안 되었을 가능성이 큽니다.

v2는 다음을 강화했습니다.

- condition/reaction ID 정리
- pathway reaction과 model flux를 merge 방식으로 직접 join
- 각 interval마다 nonzero model flux / active pathway overlap debug 저장
- `pathway_interval_debug.csv` 생성
- 실행 마지막에 nonzero pathway summary top 출력

## 설치

기존 16번을 덮어쓰세요.

```text
C:\CHO_POC\scripts\16_batch_pathway_pfba_fva.py
```

## 실행

```bat
cd C:\CHO_POC

python scripts\16_batch_pathway_pfba_fva.py --base C:\CHO_POC --rates-file data\metabolomics\processed\exchange_rates_feed_corrected.csv --pathway-file results\tables\pathway_reaction_sets_core.csv --mode strict --bound-buffer 0.5
```

## 확인

```text
results\tables\pathway\pathway_interval_summary.csv
results\tables\pathway\pathway_reaction_fluxes.csv
results\tables\pathway\pathway_clone_summary.csv
results\tables\pathway\pathway_interval_debug.csv
```

`pathway_interval_debug.csv`에서 아래를 확인하세요.

```text
nonzero_model_fluxes
active_pathway_reactions
```
