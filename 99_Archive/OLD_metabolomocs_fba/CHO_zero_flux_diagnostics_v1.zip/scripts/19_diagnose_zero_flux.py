
from __future__ import annotations

import argparse
import math
from pathlib import Path

import pandas as pd
import numpy as np
import cobra

try:
    from cobra.flux_analysis import pfba
except Exception:
    pfba = None


DEFAULT_MODEL_CANDIDATES = [
    "model/iCHO3K-main/iCHO3K/Model/iCHO3K_cho_prod_generic_unblocked.json",
    "model/iCHO3K-main/iCHO3K/Model/iCHO3K_cho_prod_generic_unblocked.xml",
]


def load_model(path: Path):
    if path.suffix.lower() == ".json":
        return cobra.io.load_json_model(str(path))
    return cobra.io.read_sbml_model(str(path))


def pick_model(base: Path, model_file: str | None):
    if model_file:
        p = Path(model_file)
        return p if p.is_absolute() else base / p
    for rel in DEFAULT_MODEL_CANDIDATES:
        p = base / rel
        if p.exists():
            return p
    raise FileNotFoundError("Model file not found. Use --model-file")


def finite(x):
    try:
        return math.isfinite(float(x))
    except Exception:
        return False


def strict_bounds(row, buffer=0.5):
    if "lower_bound" in row.index and "upper_bound" in row.index and finite(row["lower_bound"]) and finite(row["upper_bound"]):
        lb, ub = float(row["lower_bound"]), float(row["upper_bound"])
    else:
        rate = float(row["rate"])
        if rate < 0:
            lb, ub = rate * (1 + buffer), rate * (1 - buffer)
        else:
            lb, ub = rate * (1 - buffer), rate * (1 + buffer)
    if lb > ub:
        lb, ub = ub, lb
    return max(lb, -1000), min(ub, 1000)


def classify_pathway_text(text: str):
    t = text.lower()
    hits = []
    rules = {
        "glycolysis": ["hexokinase", "phosphofructokinase", "fructose", "glyceraldehyde", "phosphoglycerate", "enolase", "pyruvate kinase", "glucose-6", "gapd", "pgk", "pfk", "pyk"],
        "tca_cycle": ["citrate", "aconitase", "isocitrate", "ketoglutarate", "succinate", "fumarate", "malate", "oxaloacetate", "citrate synthase", "mdh", "fum"],
        "lactate_pyruvate": ["lactate", "pyruvate", "ldh"],
        "glutamine_glutamate": ["glutamine", "glutamate", "glutaminase", "glutamate dehydrogenase", "gln", "glu"],
        "ammonia_nitrogen": ["ammonia", "ammonium", "nh4", "nitrogen"],
        "pentose_phosphate": ["pentose", "ribose", "ribulose", "transketolase", "transaldolase", "6-phosphogluconate", "g6pd"],
        "oxidative_phosphorylation": ["cytochrome", "ubiquinone", "atp synthase", "nadh dehydrogenase", "electron transport"],
        "biomass_product": ["biomass", "product", "igg", "antibody", "mab", "protein"],
    }
    for pathway, kws in rules.items():
        if any(k in t for k in kws):
            hits.append(pathway)
    return ";".join(hits)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--rates-file", default="data/metabolomics/processed/exchange_rates_feed_corrected.csv")
    ap.add_argument("--pathway-file", default="results/tables/pathway_reaction_sets_core.csv")
    ap.add_argument("--model-file", default=None)
    ap.add_argument("--condition", default=None)
    ap.add_argument("--day-start", type=float, default=None)
    ap.add_argument("--day-end", type=float, default=None)
    ap.add_argument("--bound-buffer", type=float, default=0.5)
    ap.add_argument("--top-n", type=int, default=300)
    args = ap.parse_args()

    base = Path(args.base).resolve()
    outdir = base / "results" / "tables" / "debug_zero_flux"
    outdir.mkdir(parents=True, exist_ok=True)

    rates_path = Path(args.rates_file)
    if not rates_path.is_absolute():
        rates_path = base / rates_path

    pathway_path = Path(args.pathway_file)
    if not pathway_path.is_absolute():
        pathway_path = base / pathway_path

    model_path = pick_model(base, args.model_file)
    model = load_model(model_path)

    rates = pd.read_csv(rates_path)
    rates["condition"] = rates["condition"].astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
    rates["rate"] = pd.to_numeric(rates["rate"], errors="coerce")
    rates["day_start"] = pd.to_numeric(rates["day_start"], errors="coerce")
    rates["day_end"] = pd.to_numeric(rates["day_end"], errors="coerce")

    # 1. Rate QC
    rate_qc = (
        rates.groupby(["metabolite", "exchange_rxn"], as_index=False)
        .agg(
            n=("rate", "size"),
            n_nonzero=("rate", lambda x: int((x.abs() > 1e-12).sum())),
            min_rate=("rate", "min"),
            max_rate=("rate", "max"),
            mean_abs_rate=("rate", lambda x: x.abs().mean()),
        )
    )
    rate_qc.to_csv(outdir / "01_rates_qc.csv", index=False, encoding="utf-8-sig")

    missing = sorted(set(rates["exchange_rxn"].dropna().astype(str)) - {r.id for r in model.reactions})
    pd.DataFrame({"missing_exchange_rxn": missing}).to_csv(outdir / "02_missing_exchange_reactions.csv", index=False, encoding="utf-8-sig")

    # 2. Choose interval
    valid = rates.dropna(subset=["condition", "day_start", "day_end", "exchange_rxn", "rate"]).copy()
    valid = valid[valid["rate"].abs() > 1e-12].copy()

    if args.condition is not None:
        valid = valid[valid["condition"] == str(args.condition)]
    if args.day_start is not None:
        valid = valid[valid["day_start"] == args.day_start]
    if args.day_end is not None:
        valid = valid[valid["day_end"] == args.day_end]

    if valid.empty:
        print("[DIAGNOSIS] No nonzero rates found for selected filter.")
        print("[CHECK] See:", outdir / "01_rates_qc.csv")
        return

    first = valid[["condition", "day_start", "day_end"]].drop_duplicates().iloc[0]
    cond, d0, d1 = str(first["condition"]), float(first["day_start"]), float(first["day_end"])

    interval = rates[
        (rates["condition"] == cond)
        & (rates["day_start"] == d0)
        & (rates["day_end"] == d1)
    ].copy()

    # Apply strict bounds
    applied_rows = []
    warnings = []
    for _, row in interval.drop_duplicates(subset=["exchange_rxn"], keep="last").iterrows():
        rid = str(row["exchange_rxn"]).strip()
        if rid not in model.reactions:
            warnings.append({"reaction": rid, "issue": "not_in_model", "metabolite": row.get("metabolite", "")})
            continue
        lb, ub = strict_bounds(row, args.bound_buffer)
        rxn = model.reactions.get_by_id(rid)
        rxn.bounds = (lb, ub)
        excludes_zero = not (lb <= 0 <= ub)
        applied_rows.append({
            "condition": cond,
            "day_start": d0,
            "day_end": d1,
            "metabolite": row.get("metabolite", ""),
            "reaction": rid,
            "rate": row.get("rate", ""),
            "lower_bound": lb,
            "upper_bound": ub,
            "excludes_zero": excludes_zero,
        })

    applied = pd.DataFrame(applied_rows)
    applied.to_csv(outdir / "03_applied_constraints_one_interval.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(warnings).to_csv(outdir / "04_constraint_warnings.csv", index=False, encoding="utf-8-sig")

    sol = model.optimize()
    if sol.status == "optimal" and pfba is not None:
        try:
            psol = pfba(model)
            flux = psol.fluxes
            flux_source = "pfba"
        except Exception as e:
            print("[WARN] pfba failed, using FBA solution:", e)
            flux = sol.fluxes
            flux_source = "fba"
    else:
        flux = sol.fluxes
        flux_source = "fba"

    # 3. Exchange fluxes
    exch = []
    for rid in sorted(set(interval["exchange_rxn"].dropna().astype(str))):
        if rid in model.reactions:
            rxn = model.reactions.get_by_id(rid)
            exch.append({
                "reaction": rid,
                "flux": float(flux.get(rid, np.nan)),
                "lower_bound": rxn.lower_bound,
                "upper_bound": rxn.upper_bound,
                "excludes_zero": not (rxn.lower_bound <= 0 <= rxn.upper_bound),
            })
    pd.DataFrame(exch).to_csv(outdir / "05_solution_exchange_fluxes.csv", index=False, encoding="utf-8-sig")

    # 4. Nonzero model fluxes
    nonzero = flux[flux.abs() > 1e-10].sort_values(key=lambda s: s.abs(), ascending=False)
    nz_rows = []
    for rid, val in nonzero.head(args.top_n).items():
        rxn = model.reactions.get_by_id(rid)
        mets = " ".join([m.id + " " + (m.name or "") for m in rxn.metabolites])
        text = f"{rxn.id} {rxn.name} {rxn.reaction} {mets}"
        nz_rows.append({
            "reaction": rid,
            "reaction_name": rxn.name,
            "flux": float(val),
            "abs_flux": abs(float(val)),
            "auto_pathway_hits": classify_pathway_text(text),
            "is_boundary": bool(rxn.boundary),
            "reaction_string": rxn.reaction,
        })
    nzdf = pd.DataFrame(nz_rows)
    nzdf.to_csv(outdir / "06_nonzero_model_fluxes_top.csv", index=False, encoding="utf-8-sig")

    # 5. Pathway overlap
    if pathway_path.exists():
        pset = pd.read_csv(pathway_path)
        pset["reaction"] = pset["reaction"].astype(str)
        pset_active = pset[pset["reaction"].isin(nonzero.index.astype(str))].copy()
        if not pset_active.empty:
            pset_active["flux"] = pset_active["reaction"].map(flux.to_dict())
            pset_active["abs_flux"] = pset_active["flux"].abs()
            overlap_summary = (
                pset_active.groupby("pathway", as_index=False)
                .agg(
                    n_active=("reaction", "nunique"),
                    sum_abs_flux=("abs_flux", "sum"),
                    mean_abs_flux=("abs_flux", "mean"),
                )
                .sort_values("sum_abs_flux", ascending=False)
            )
        else:
            overlap_summary = pd.DataFrame(columns=["pathway", "n_active", "sum_abs_flux", "mean_abs_flux"])
        pset_active.to_csv(outdir / "07_active_fluxes_in_pathway_set.csv", index=False, encoding="utf-8-sig")
        overlap_summary.to_csv(outdir / "08_pathway_overlap_summary.csv", index=False, encoding="utf-8-sig")
    else:
        overlap_summary = pd.DataFrame()
        print("[WARN] pathway file not found:", pathway_path)

    # 6. Diagnosis summary
    n_applied = len(applied)
    n_exclude_zero = int(applied["excludes_zero"].sum()) if not applied.empty and "excludes_zero" in applied.columns else 0
    n_exchange_nonzero = int((pd.DataFrame(exch)["flux"].abs() > 1e-10).sum()) if exch else 0
    n_model_nonzero = len(nonzero)
    n_pathway_active = int(overlap_summary["n_active"].sum()) if not overlap_summary.empty and "n_active" in overlap_summary.columns else 0

    lines = [
        "ZERO FLUX DIAGNOSTIC SUMMARY",
        f"Model: {model_path}",
        f"Rates: {rates_path}",
        f"Pathway file: {pathway_path}",
        f"Test interval: condition={cond}, day={d0:g}-{d1:g}",
        f"Solver status: {sol.status}",
        f"Objective value: {sol.objective_value}",
        f"Flux source: {flux_source}",
        "",
        f"Applied exchange constraints: {n_applied}",
        f"Applied constraints excluding zero: {n_exclude_zero}",
        f"Nonzero constrained exchange fluxes in solution: {n_exchange_nonzero}",
        f"Nonzero model fluxes total: {n_model_nonzero}",
        f"Active reactions overlapping pathway set: {n_pathway_active}",
        "",
        "Interpretation guide:",
    ]

    if n_applied == 0:
        lines.append("PROBLEM: No exchange constraints were applied. Check exchange_rxn IDs and rates file.")
    elif n_exclude_zero == 0:
        lines.append("PROBLEM: Applied bounds still allow zero. Rates may be zero or bounds are too relaxed.")
    elif n_exchange_nonzero == 0:
        lines.append("PROBLEM: Constrained exchanges are not nonzero in solution. Check bounds/application.")
    elif n_model_nonzero > 0 and n_pathway_active == 0:
        lines.append("PROBLEM: Model has nonzero fluxes, but your pathway set does not overlap active reactions.")
        lines.append("ACTION: Use 06_nonzero_model_fluxes_top.csv to define pathway sets from active reactions.")
    elif n_model_nonzero == 0:
        lines.append("PROBLEM: The solution is all-zero despite constraints. Check whether rates are truly nonzero and model bounds.")
    else:
        lines.append("OK: Nonzero fluxes and pathway overlap exist. If 16 output is zero, the issue is in 16 summarization/pathway file choice.")

    summary = "\n".join(lines) + "\n"
    (outdir / "00_DIAGNOSIS_SUMMARY.txt").write_text(summary, encoding="utf-8")
    print(summary)
    print("[OUTPUT DIR]", outdir)


if __name__ == "__main__":
    main()
