
# Zero pathway flux diagnostic

## 왜 필요한가?

`16_batch_pathway_pfba_fva.py`를 strict mode로 돌려도 모든 pathway 값이 0이면, 원인은 보통 셋 중 하나입니다.

```text
1. exchange_rates_feed_corrected.csv의 rate가 실제로 거의 0이다.
2. exchange_rxn ID가 모델에 없어서 constraint가 적용되지 않았다.
3. 모델 flux는 nonzero인데 pathway_reaction_sets_core.csv가 active reaction과 겹치지 않는다.
```

## 설치

```text
C:\CHO_POC\scripts\19_diagnose_zero_flux.py
```

## 실행

```bat
cd C:\CHO_POC

python scripts\19_diagnose_zero_flux.py --base C:\CHO_POC --rates-file data\metabolomics\processed\exchange_rates_feed_corrected.csv --pathway-file results\tables\pathway_reaction_sets_core.csv --bound-buffer 0.5
```

특정 clone/interval만 보려면:

```bat
python scripts\19_diagnose_zero_flux.py --base C:\CHO_POC --condition 2 --day-start 3 --day-end 5
```

또는 clone 이름이 `Clone02`라면:

```bat
python scripts\19_diagnose_zero_flux.py --base C:\CHO_POC --condition Clone02 --day-start 3 --day-end 5
```

## 결과

```text
results\tables\debug_zero_flux\00_DIAGNOSIS_SUMMARY.txt
results\tables\debug_zero_flux\01_rates_qc.csv
results\tables\debug_zero_flux\02_missing_exchange_reactions.csv
results\tables\debug_zero_flux\03_applied_constraints_one_interval.csv
results\tables\debug_zero_flux\05_solution_exchange_fluxes.csv
results\tables\debug_zero_flux\06_nonzero_model_fluxes_top.csv
results\tables\debug_zero_flux\08_pathway_overlap_summary.csv
```

가장 먼저 `00_DIAGNOSIS_SUMMARY.txt`를 보면 됩니다.
