
# 20AA exchange rate v4

## 현재 문제

practice raw file에 20종 amino acid가 들어 있어도 기존 09/13 스크립트가 이를 모두 인식하지 못하면:

```text
converted_extracellular_metabolomics.csv count = 8
exchange_rates_feed_corrected.csv count = 5
```

처럼 나옵니다.

이 v4 스크립트는 raw Excel을 직접 읽어서 20종 amino acid + central metabolites를 long table과 exchange rate로 만듭니다.

## 설치

```text
C:\CHO_POC\scripts\13_recalculate_feed_corrected_rates_20aa_v4.py
```

## 실행

```bat
cd C:\CHO_POC

python scripts\13_recalculate_feed_corrected_rates_20aa_v4.py --base C:\CHO_POC --raw-excel "C:\CHO_POC\data\metabolomics\raw\CHO_raw_data_practice.xlsx" --volume 50
```

이 스크립트는 아래 파일을 직접 생성/덮어씁니다.

```text
data\metabolomics\processed\converted_process_data.csv
data\metabolomics\processed\converted_extracellular_metabolomics.csv
data\metabolomics\processed\exchange_rates_feed_corrected.csv
data\metabolomics\processed\exchange_rates_from_user_format.csv
data\metabolomics\processed\aa_feed_column_detection_debug.csv
```

## 성공 기준

실행 마지막에:

```text
METABOLITES IN CONVERTED DATA count = 20개 이상
METABOLITES IN EXCHANGE RATES count = 20개 이상
```

이 나오면 성공입니다.

그다음 기존 11/14/15/16/17을 돌리면 됩니다.

```bat
python scripts\11_batch_run_intervals.py --base C:\CHO_POC --rates-file data\metabolomics\processed\exchange_rates_feed_corrected.csv --mode strict_then_relaxed --fva-mode none

python scripts\14_make_clone_decision_summary.py --base C:\CHO_POC

python scripts\15_model_pathway_scout.py --base C:\CHO_POC
python scripts\18_make_core_pathway_reaction_sets.py --base C:\CHO_POC
python scripts\16_batch_pathway_pfba_fva.py --base C:\CHO_POC --rates-file data\metabolomics\processed\exchange_rates_feed_corrected.csv --pathway-file results\tables\pathway_reaction_sets_core.csv --mode strict --bound-buffer 0.5
python scripts\17_plot_pathway_results.py --base C:\CHO_POC
```
