# CHO metabolomics → FBA/FVA final Windows package

## 1. 폴더 준비
```bat
cd C:\CHO_POC
python scripts\00_setup_project.py --base C:\CHO_POC
```

## 2. 필요한 입력 파일
- iCHO3K 모델:
  `C:\CHO_POC\model\iCHO3K-main\iCHO3K\Model\iCHO3K_cho_prod_generic_unblocked.json`
- 실험 입력 Excel:
  `C:\CHO_POC\templates\CHO_FBA_final_input_template.xlsx`
- public POC용 Sowa 데이터:
  `C:\CHO_POC\data\metabolomics\raw\mmc1.xlsx`

## 3. 실험 Excel 입력 방식
주로 아래 시트를 채운다.

1. `Experiment_Design`
   - condition, clone_id, producer_class
2. `Process_Data`
   - day, VCD, viability, volume, titer
3. `Feed_Additions`
   - glucose shot, Feed4, pH base 등 추가 정보
4. `Feed_Composition_Measured`
   - proprietary feed라도 직접 측정한 조성값이 있으면 입력
5. `Extracellular_Metabolomics`
   - condition/day/metabolite/concentration/unit/platform
6. `Exchange_Map_iCHO3K`
   - metabolite와 iCHO3K exchange reaction ID mapping

## 4. 실험값 기반 rate 생성
```bat
python scripts\02_import_experiment_excel.py --base C:\CHO_POC --input templates\CHO_FBA_final_input_template.xlsx
```

출력:
`data\metabolomics\processed\exchange_rates_from_template.csv`

## 5. FBA/pFBA 실행
```bat
python scripts\03_run_fba_fva.py --base C:\CHO_POC --condition Clone_A --rates-file data\metabolomics\processed\exchange_rates_from_template.csv --skip-fva
```

FVA까지 하려면 `--skip-fva`를 빼면 된다. 처음에는 exchange FVA만 권장.

## 6. plot
```bat
python scripts\04_plot_summary.py --base C:\CHO_POC --conditions Clone_A Clone_B
```

## 7. Escher
먼저 map 생성:
```bat
python scripts\06_make_exchange_escher_map.py --base C:\CHO_POC
```

HTML 생성:
```bat
python scripts\05_make_escher_html.py --base C:\CHO_POC --condition Clone_A --model-file C:\CHO_POC\model\iCHO3K-main\iCHO3K\Model\iCHO3K_cho_prod_generic_unblocked.json --map-json C:\CHO_POC\maps\cho_exchange_flux_map.json
```

## 8. 해석 주의
- 현재 Excel template의 concentration-derived rate는 POC용이다.
- 최종 분석은 IVCD, feed addition, volume change, sampling removal을 반영해 absolute flux로 계산하는 것이 좋다.
- FBA 결과는 측정값이 아니라 constraint를 만족하는 모델 추정값이다.
- FVA range가 좁은 내부 reaction일수록 해석 신뢰도가 상대적으로 높다.
