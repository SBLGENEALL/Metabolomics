# 데이터 sheet 형식 요약

## Experiment_Design
| column | meaning |
|---|---|
| condition | FBA 조건명. 예: Clone_A |
| clone_id | clone ID |
| producer_class | High/Medium/Low |
| media/feed_strategy | 배지 및 feed 전략 |

## Process_Data
| column | meaning |
|---|---|
| condition | Experiment_Design과 동일 |
| day/time_h | sampling time |
| vcd_10e6_cells_mL | viable cell density |
| viability_pct | viability |
| culture_volume_mL | culture volume |
| sample_removed_mL | sampling volume |
| titer_g_L/qP | 생산성 지표 |

## Extracellular_Metabolomics
| column | meaning |
|---|---|
| condition | clone/condition |
| day/time_h | sampling time |
| replicate | R1/R2/R3 |
| metabolite | Glucose, Lactate 등 |
| concentration | measured concentration |
| unit | mM 권장 |
| platform | BioProfile, HPLC, LC-MS 등 |
| qc_flag | OK/Exclude 등 |

## Exchange_Map_iCHO3K
측정 metabolite를 iCHO3K exchange reaction으로 연결한다.

예:
- Glucose → EX_glc_e
- Lactate → EX_lac_L_e
- Glutamine → EX_gln_L_e
- Ammonia → EX_nh4_e

## FBA_Export / exchange_rates CSV
스크립트가 최종적으로 사용하는 형식:

| column | meaning |
|---|---|
| condition | condition name |
| metabolite | metabolite name |
| exchange_rxn | iCHO3K exchange reaction |
| rate | uptake/secretion rate |
| rate_type | uptake/secretion |
| lower_bound/upper_bound | FBA constraint bounds |
| day_start/day_end | interval |
