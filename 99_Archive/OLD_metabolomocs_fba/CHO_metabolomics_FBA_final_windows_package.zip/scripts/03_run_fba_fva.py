import argparse
from pathlib import Path
import cobra
from cobra.flux_analysis import pfba, flux_variability_analysis
import pandas as pd
import numpy as np

DEFAULT_OPEN = {
    "EX_h_e": (-1000, 1000), "EX_h2o_e": (-1000, 1000), "EX_o2_e": (-1000, 1000),
    "EX_hco3_e": (-1000, 1000), "EX_pi_e": (-1000, 1000), "EX_so4_e": (-1000, 1000),
}

def load_model(model_file):
    p = Path(model_file)
    if p.suffix.lower() == ".json":
        return cobra.io.load_json_model(str(p))
    return cobra.io.read_sbml_model(str(p))

def pick_model(base, model_file):
    if model_file:
        return Path(model_file)
    candidates = [
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.json",
        base / "model" / "iCHO3K-main" / "iCHO3K" / "Model" / "iCHO3K_cho_prod_generic_unblocked.xml",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError("Model file not found. Use --model-file")

def apply_rates(model, rates, condition, buffer=0.20):
    if "condition" in rates.columns:
        rates = rates[rates["condition"].astype(str) == str(condition)].copy()
    applied = []
    for rid, (lb, ub) in DEFAULT_OPEN.items():
        if rid in model.reactions:
            r = model.reactions.get_by_id(rid)
            r.lower_bound, r.upper_bound = lb, ub
    for _, row in rates.iterrows():
        rid = str(row.get("exchange_rxn", "")).strip()
        if not rid or rid not in model.reactions:
            continue
        r = model.reactions.get_by_id(rid)
        if "lower_bound" in row and pd.notna(row["lower_bound"]) and "upper_bound" in row and pd.notna(row["upper_bound"]):
            lb, ub = float(row["lower_bound"]), float(row["upper_bound"])
        else:
            rate = float(row["rate"])
            lb, ub = (rate*(1+buffer), rate*(1-buffer)) if rate < 0 else (rate*(1-buffer), rate*(1+buffer))
        if lb > ub:
            lb, ub = ub, lb
        # Clamp only lightly to model default broad range.
        r.lower_bound = max(lb, -1000)
        r.upper_bound = min(ub, 1000)
        applied.append({"reaction": rid, "lower_bound": r.lower_bound, "upper_bound": r.upper_bound})
    return pd.DataFrame(applied)

def save_fluxes(sol, path):
    df = sol.fluxes.reset_index()
    df.columns = ["reaction", "flux"]
    df.to_csv(path, index=False, encoding="utf-8-sig")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--condition", required=True)
    ap.add_argument("--rates-file", required=True)
    ap.add_argument("--model-file", default=None)
    ap.add_argument("--objective", default=None)
    ap.add_argument("--skip-fva", action="store_true")
    ap.add_argument("--fva-mode", choices=["exchange", "all"], default="exchange")
    ap.add_argument("--fraction", type=float, default=0.90)
    args = ap.parse_args()

    base = Path(args.base)
    model_file = pick_model(base, args.model_file)
    table_dir = base / "results" / "tables"
    table_dir.mkdir(parents=True, exist_ok=True)

    rates_path = Path(args.rates_file)
    if not rates_path.is_absolute():
        rates_path = base / rates_path
    rates = pd.read_csv(rates_path)
    model = load_model(model_file)

    if args.objective:
        if args.objective not in model.reactions:
            raise ValueError(f"Objective not found: {args.objective}")
        model.objective = args.objective

    applied = apply_rates(model, rates, args.condition)
    applied.to_csv(table_dir / f"{args.condition}_applied_constraints.csv", index=False, encoding="utf-8-sig")
    print(f"[INFO] Applied constraints: {len(applied)}")

    sol = model.optimize()
    print(f"[FBA] {args.condition}: status={sol.status}, objective={sol.objective_value}")
    if sol.status == "optimal":
        save_fluxes(sol, table_dir / f"{args.condition}_fba_fluxes.csv")

    try:
        psol = pfba(model)
        print(f"[pFBA] {args.condition}: objective={psol.objective_value}")
        save_fluxes(psol, table_dir / f"{args.condition}_pfba_fluxes.csv")
    except Exception as e:
        print("[WARN] pFBA failed:", e)

    if not args.skip_fva:
        try:
            rxn_list = list(model.exchanges) if args.fva_mode == "exchange" else None
            fva = flux_variability_analysis(model, reaction_list=rxn_list, fraction_of_optimum=args.fraction, processes=1)
            fva.to_csv(table_dir / f"{args.condition}_fva.csv", encoding="utf-8-sig")
            print(f"[FVA] {args.condition}: done")
        except Exception as e:
            print("[WARN] FVA failed:", e)

if __name__ == "__main__":
    main()
