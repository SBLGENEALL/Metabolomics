import argparse
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    args = ap.parse_args()
    base = Path(args.base)
    dirs = [
        "data/metabolomics/raw",
        "data/metabolomics/processed",
        "model",
        "results/tables",
        "results/figures",
        "results/figures_publication",
        "results/escher",
        "maps",
        "logs",
    ]
    for d in dirs:
        p = base / d
        p.mkdir(parents=True, exist_ok=True)
        print("[DIR]", p)
    print("[OK] project folders ready:", base)

if __name__ == "__main__":
    main()
