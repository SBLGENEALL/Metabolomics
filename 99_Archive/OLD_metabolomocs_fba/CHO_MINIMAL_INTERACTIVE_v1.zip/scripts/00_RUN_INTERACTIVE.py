
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from datetime import datetime
import pandas as pd


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default != "" else ""
    ans = input(f"{prompt}{suffix}: ").strip()
    return ans if ans else default


def ask_yes_no(prompt: str, default: bool = False) -> bool:
    d = "Y" if default else "N"
    ans = input(f"{prompt} [Y/N, default={d}]: ").strip().lower()
    if not ans:
        return default
    return ans in ["y", "yes", "1", "true", "t"]


def run(cmd: list[str], log_file: Path, required: bool = True) -> int:
    print("\n" + "=" * 90)
    print("[RUN]", " ".join([f'"{x}"' if " " in str(x) else str(x) for x in cmd]))
    print("=" * 90)

    p = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    print(p.stdout)
    with open(log_file, "a", encoding="utf-8") as f:
        f.write("\n" + "=" * 90 + "\n")
        f.write("[RUN] " + " ".join(map(str, cmd)) + "\n")
        f.write("=" * 90 + "\n")
        f.write(p.stdout)

    if p.returncode != 0 and required:
        raise RuntimeError(f"Command failed: {' '.join(map(str, cmd))}")
    return p.returncode


def sp(base: Path, name: str) -> Path:
    p = base / "scripts" / name
    if not p.exists():
        raise FileNotFoundError(f"필수 script가 없습니다: {p}")
    return p


def rates_file(base: Path, use_feed_corrected: bool = True) -> Path:
    feed = base / "data" / "metabolomics" / "processed" / "exchange_rates_feed_corrected.csv"
    raw = base / "data" / "metabolomics" / "processed" / "exchange_rates_from_user_format.csv"
    if use_feed_corrected and feed.exists():
        return feed
    if raw.exists():
        return raw
    if feed.exists():
        return feed
    raise FileNotFoundError("exchange rate 파일이 없습니다. 09/13 단계를 먼저 실행해야 합니다.")


def auto_select_objective(base: Path) -> str | None:
    cand = base / "results" / "tables" / "objective_candidates.csv"
    out = base / "results" / "tables" / "auto_objective_selection.csv"

    if not cand.exists():
        print("[AUTO OBJECTIVE] objective_candidates.csv 없음 → objective 미지정")
        return None

    df = pd.read_csv(cand)
    if df.empty or "reaction" not in df.columns:
        print("[AUTO OBJECTIVE] 후보 없음 → objective 미지정")
        return None

    if "objective_test_value" in df.columns:
        df["objective_test_value"] = pd.to_numeric(df["objective_test_value"], errors="coerce")
    else:
        df["objective_test_value"] = pd.NA

    if "keyword_score" in df.columns:
        df["keyword_score"] = pd.to_numeric(df["keyword_score"], errors="coerce").fillna(0)
    else:
        df["keyword_score"] = 0

    def row_text(r):
        cols = ["reaction", "reaction_name", "matched_keywords", "reaction_string"]
        return " ".join(str(r.get(c, "")) for c in cols).lower()

    def score(r):
        t = row_text(r)
        s = 0.0
        for kw, w in [
            ("igg", 100), ("antibody", 95), ("mab", 95),
            ("product", 70), ("biomass", 50), ("growth", 45),
            ("demand", 25), ("protein", 20), ("sink", 10),
        ]:
            if kw in t:
                s += w

        if "optimal" in str(r.get("objective_test_status", "")).lower():
            s += 30

        v = r.get("objective_test_value")
        if pd.notna(v) and abs(float(v)) > 1e-12:
            s += 60
        else:
            s -= 40

        s += float(r.get("keyword_score", 0))

        rid = str(r.get("reaction", ""))
        if rid.startswith("EX_"):
            s -= 50
        return s

    df["auto_score"] = df.apply(score, axis=1)
    df = df.sort_values(["auto_score", "objective_test_value"], ascending=[False, False])
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False, encoding="utf-8-sig")

    best = df.iloc[0]
    best_id = str(best["reaction"])
    best_score = float(best["auto_score"])
    best_value = best["objective_test_value"]

    if best_score < 40 or pd.isna(best_value) or abs(float(best_value)) <= 1e-12:
        print("[AUTO OBJECTIVE] nonzero objective를 확신할 수 없음 → objective 미지정")
        print("[AUTO OBJECTIVE] 후보 ranking:", out)
        return None

    print(f"[AUTO OBJECTIVE] 선택됨: {best_id} / score={best_score:.1f} / test_value={best_value}")
    print("[AUTO OBJECTIVE] 후보 ranking:", out)
    return best_id


def write_minimal_tree(base: Path):
    lines = [
        "Minimal recommended project tree",
        "",
        str(base),
        "├─ scripts/",
        "│  ├─ 00_RUN_INTERACTIVE.py",
        "│  ├─ 01_SUMMARIZE_RESULTS.py",
        "│  ├─ 09_convert_existing_excel_to_template.py",
        "│  ├─ 13_recalculate_feed_corrected_rates.py",
        "│  ├─ 11_batch_run_intervals.py",
        "│  ├─ 12_plot_batch_results.py",
        "│  ├─ 14_make_clone_decision_summary.py",
        "│  ├─ 15_model_pathway_scout.py",
        "│  ├─ 16_batch_pathway_pfba_fva.py",
        "│  ├─ 17_plot_pathway_results.py",
        "│  └─ 18_make_core_pathway_reaction_sets.py",
        "├─ templates/",
        "├─ model/",
        "├─ data/metabolomics/raw/",
        "│  └─ CHO_raw_data.xlsx",
        "├─ data/metabolomics/processed/",
        "├─ results/",
        "└─ logs/",
        "",
        "Optional/legacy scripts can be moved to scripts_legacy/ after the pipeline is stable.",
    ]
    out = base / "docs" / "MINIMAL_PROJECT_TREE.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("[OK] minimal tree guide:", out)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default=None)
    parser.add_argument("--raw-excel", default=None)
    parser.add_argument("--volume", type=float, default=None)
    parser.add_argument("--mode", choices=["full", "after_convert", "report_only"], default=None)
    parser.add_argument("--run-core-fva", action="store_true")
    parser.add_argument("--pathway-strict-buffer", type=float, default=0.5)
    parser.add_argument("--objective", default="auto", help="auto, none, or specific reaction ID")
    args = parser.parse_args()

    print("\nCHO Metabolomics FBA/FVA Interactive Runner")
    print("사용자 입장에서는 이 파일 하나만 실행하면 됩니다.\n")

    default_base = str(Path.cwd())
    base = Path(args.base or ask("Project base folder", default_base)).resolve()
    raw_excel = Path(args.raw_excel or ask("Raw Excel file", str(base / "data" / "metabolomics" / "raw" / "CHO_raw_data.xlsx"))).resolve()
    volume = args.volume if args.volume is not None else float(ask("Fallback culture volume mL", "50"))

    mode = args.mode or ask("Run mode: full / after_convert / report_only", "full").lower()
    if mode not in ["full", "after_convert", "report_only"]:
        raise ValueError("mode must be full, after_convert, or report_only")

    run_core_fva = args.run_core_fva or ask_yes_no("Run core FVA too? 처음에는 N 추천", False)

    logs = base / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    log_file = logs / f"interactive_pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

    print("\n[SETTINGS]")
    print("base:", base)
    print("raw_excel:", raw_excel)
    print("fallback volume:", volume)
    print("mode:", mode)
    print("run_core_fva:", run_core_fva)
    print("log:", log_file)

    write_minimal_tree(base)

    if mode == "report_only":
        run([sys.executable, str(sp(base, "01_SUMMARIZE_RESULTS.py")), "--base", str(base)], log_file, required=False)
        return

    if mode == "full":
        run([
            sys.executable, str(sp(base, "09_convert_existing_excel_to_template.py")),
            "--base", str(base),
            "--input", str(raw_excel),
            "--template", str(base / "templates" / "CHO_FBA_final_input_template.xlsx"),
            "--volume", str(volume),
            "--igg-unit", "mg/L",
        ], log_file)

        run([
            sys.executable, str(sp(base, "13_recalculate_feed_corrected_rates.py")),
            "--base", str(base),
            "--raw-excel", str(raw_excel),
            "--volume", str(volume),
        ], log_file)

    rfile = rates_file(base, use_feed_corrected=True)

    run([sys.executable, str(sp(base, "15_model_pathway_scout.py")), "--base", str(base)], log_file)

    objective = None
    if args.objective.lower() == "auto":
        objective = auto_select_objective(base)
    elif args.objective.lower() != "none":
        objective = args.objective

    # Batch FBA/pFBA
    cmd = [
        sys.executable, str(sp(base, "11_batch_run_intervals.py")),
        "--base", str(base),
        "--rates-file", str(rfile),
        "--mode", "strict_then_relaxed",
        "--fva-mode", "none",
    ]
    if objective:
        cmd += ["--objective", objective]
    run(cmd, log_file)

    run([sys.executable, str(sp(base, "12_plot_batch_results.py")), "--base", str(base)], log_file, required=False)

    run([sys.executable, str(sp(base, "14_make_clone_decision_summary.py")), "--base", str(base)], log_file)

    # Core pathway set
    if (base / "scripts" / "18_make_core_pathway_reaction_sets.py").exists():
        run([sys.executable, str(sp(base, "18_make_core_pathway_reaction_sets.py")), "--base", str(base)], log_file)
        pathway_file = base / "results" / "tables" / "pathway_reaction_sets_core.csv"
    else:
        print("[WARN] 18번이 없어서 full pathway set 사용. 속도가 느릴 수 있습니다.")
        pathway_file = base / "results" / "tables" / "pathway_reaction_sets.csv"

    # Pathway pFBA: strict + buffer to avoid relaxed zero-flux issue.
    cmd = [
        sys.executable, str(sp(base, "16_batch_pathway_pfba_fva.py")),
        "--base", str(base),
        "--rates-file", str(rfile),
        "--pathway-file", str(pathway_file),
        "--mode", "strict",
        "--bound-buffer", str(args.pathway_strict_buffer),
    ]
    if run_core_fva:
        cmd += ["--run-fva"]
    if objective:
        cmd += ["--objective", objective]
        if run_core_fva:
            cmd += ["--fraction", "0.9"]

    rc = run(cmd, log_file, required=False)

    if rc != 0:
        print("[WARN] pathway strict run failed. Retrying with larger buffer=1.0")
        cmd2 = [
            sys.executable, str(sp(base, "16_batch_pathway_pfba_fva.py")),
            "--base", str(base),
            "--rates-file", str(rfile),
            "--pathway-file", str(pathway_file),
            "--mode", "strict",
            "--bound-buffer", "1.0",
        ]
        if objective:
            cmd2 += ["--objective", objective]
        run(cmd2, log_file, required=False)

    run([sys.executable, str(sp(base, "17_plot_pathway_results.py")), "--base", str(base)], log_file, required=False)

    if (base / "scripts" / "01_SUMMARIZE_RESULTS.py").exists():
        run([sys.executable, str(sp(base, "01_SUMMARIZE_RESULTS.py")), "--base", str(base)], log_file, required=False)

    print("\n[DONE]")
    print("Main table:", base / "results" / "tables" / "clone_decision_summary.csv")
    print("Report:", base / "results" / "REPORT_INDEX.html")
    print("Log:", log_file)


if __name__ == "__main__":
    main()
