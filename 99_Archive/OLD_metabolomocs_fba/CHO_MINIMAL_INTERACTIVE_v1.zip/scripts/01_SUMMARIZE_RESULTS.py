
from __future__ import annotations

import argparse
from pathlib import Path
import html
import pandas as pd


def read_csv(path: Path):
    if path.exists():
        return pd.read_csv(path)
    return None


def df_to_html_table(df, max_rows=20, cols=None):
    if df is None or df.empty:
        return "<p><i>No data found.</i></p>"
    d = df.copy()
    if cols:
        d = d[[c for c in cols if c in d.columns]]
    d = d.head(max_rows)
    return d.to_html(index=False, escape=True, border=0, classes="data-table")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    args = ap.parse_args()

    base = Path(args.base).resolve()
    results = base / "results"
    tables = results / "tables"
    figs = results / "figures"

    clone = read_csv(tables / "clone_decision_summary.csv")
    objective = read_csv(tables / "auto_objective_selection.csv")
    pathway_clone = read_csv(tables / "pathway" / "pathway_clone_summary.csv")
    pathway_interval = read_csv(tables / "pathway" / "pathway_interval_summary.csv")

    # Compact CSV for review
    if clone is not None and not clone.empty:
        keep = [
            "rank", "condition", "recommendation", "decision_score_0to1",
            "final_titer_g_L", "mean_qP_pg_cell_day", "final_viability_pct",
            "mean_rate_Glucose", "mean_rate_Lactate", "mean_rate_Glutamine", "mean_rate_Ammonia",
        ]
        compact = clone[[c for c in keep if c in clone.columns]].copy()
        out_csv = tables / "FINAL_CLONE_SUMMARY_COMPACT.csv"
        compact.to_csv(out_csv, index=False, encoding="utf-8-sig")
        print("[OK] saved:", out_csv)

    img_tags = []
    if figs.exists():
        for p in sorted(figs.glob("*.png")):
            rel = p.relative_to(results).as_posix()
            img_tags.append(f"""
            <section class="figure">
              <h3>{html.escape(p.name)}</h3>
              <img src="{html.escape(rel)}" />
            </section>
            """)

    css = """
    body { font-family: Arial, sans-serif; margin: 28px; color: #1f2937; }
    h1 { color: #0f766e; }
    h2 { border-bottom: 2px solid #e5e7eb; padding-bottom: 6px; margin-top: 32px; }
    .note { background: #f3f4f6; border-left: 5px solid #0f766e; padding: 12px; margin: 16px 0; }
    .data-table { border-collapse: collapse; font-size: 13px; }
    .data-table th { background: #0f766e; color: white; padding: 6px; }
    .data-table td { border: 1px solid #ddd; padding: 5px; }
    img { max-width: 100%; border: 1px solid #e5e7eb; margin-bottom: 18px; }
    .figure { margin-top: 24px; }
    """

    top_cols = [
        "rank", "condition", "recommendation", "decision_score_0to1",
        "final_titer_g_L", "mean_qP_pg_cell_day", "final_viability_pct",
        "mean_rate_Glucose", "mean_rate_Lactate", "mean_rate_Ammonia",
    ]

    pathway_cols = [
        "condition", "pathway", "mean_pfba_sum_abs_flux", "mean_pfba_net_flux",
        "mean_pfba_nonzero_reactions", "mean_fva_sum_range",
    ]

    objective_cols = [
        "reaction", "reaction_name", "auto_score", "objective_test_status",
        "objective_test_value", "matched_keywords",
    ]

    html_doc = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CHO Metabolomics FBA/FVA Report</title>
<style>{css}</style>
</head>
<body>
<h1>CHO Metabolomics FBA/FVA Report</h1>

<div class="note">
<b>Interpretation note</b><br>
14번 결과는 productivity + extracellular metabolic burden 통합 요약입니다.<br>
16/17번 결과는 measured exchange constraints를 만족하는 model-inferred pathway phenotype입니다.<br>
objective가 명확하지 않거나 0이면 FBA/pFBA는 주로 feasibility/metabolic consistency check로 해석하세요.
</div>

<h2>1. Clone decision summary</h2>
{df_to_html_table(clone, max_rows=30, cols=top_cols)}

<h2>2. Auto objective candidates</h2>
{df_to_html_table(objective, max_rows=15, cols=objective_cols)}

<h2>3. Pathway clone summary</h2>
{df_to_html_table(pathway_clone, max_rows=80, cols=pathway_cols)}

<h2>4. Pathway interval summary preview</h2>
{df_to_html_table(pathway_interval, max_rows=40)}

<h2>5. Figures</h2>
{''.join(img_tags) if img_tags else '<p><i>No figures found.</i></p>'}
</body>
</html>
"""

    out_html = results / "REPORT_INDEX.html"
    out_html.write_text(html_doc, encoding="utf-8")
    print("[OK] saved:", out_html)


if __name__ == "__main__":
    main()
