@echo off
cd /d C:\CHO_POC
python scripts\00_RUN_INTERACTIVE.py
pause
