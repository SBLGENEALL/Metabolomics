
# CHO POC minimal interactive version

## 목표

기존에는 09, 13, 11, 12, 14, 15, 16, 17, 18을 각각 실행해야 해서 사용이 복잡했습니다.  
이 버전은 사용자가 실제로는 아래 하나만 실행하도록 정리합니다.

```bat
cd C:\CHO_POC
python scripts\00_RUN_INTERACTIVE.py
```

또는 더블클릭용:

```text
run_CHO_interactive.bat
```

## 필수 scripts

내부 엔진으로 아래 파일만 유지하면 됩니다.

```text
00_RUN_INTERACTIVE.py
01_SUMMARIZE_RESULTS.py
09_convert_existing_excel_to_template.py
13_recalculate_feed_corrected_rates.py
11_batch_run_intervals.py
12_plot_batch_results.py
14_make_clone_decision_summary.py
15_model_pathway_scout.py
16_batch_pathway_pfba_fva.py
17_plot_pathway_results.py
18_make_core_pathway_reaction_sets.py
```

나머지 예전 POC/시각화/디버그 스크립트는 필요할 때만 쓰고, 평소에는 `scripts_legacy`로 빼도 됩니다.

## 추천 폴더 구조

```text
C:\CHO_POC
├─ scripts
├─ templates
├─ model
├─ data
│  └─ metabolomics
│     ├─ raw
│     │  └─ CHO_raw_data.xlsx
│     └─ processed
├─ results
│  ├─ tables
│  └─ figures
├─ docs
└─ logs
```

## 실행 모드

### 처음부터 전체 실행

```bat
python scripts\00_RUN_INTERACTIVE.py
```

질문에 이렇게 답하면 됩니다.

```text
Project base folder: C:\CHO_POC
Raw Excel file: C:\CHO_POC\data\metabolomics\raw\CHO_raw_data.xlsx
Fallback culture volume mL: 50
Run mode: full
Run core FVA too?: N
```

### 09/13이 이미 끝난 상태에서 실행

```bat
python scripts\00_RUN_INTERACTIVE.py --base C:\CHO_POC --mode after_convert --volume 50
```

### 결과 report만 다시 만들기

```bat
python scripts\01_SUMMARIZE_RESULTS.py --base C:\CHO_POC
```

## 깔끔하게 볼 최종 결과

```text
results\REPORT_INDEX.html
results\tables\FINAL_CLONE_SUMMARY_COMPACT.csv
results\tables\clone_decision_summary.csv
results\tables\pathway\pathway_clone_summary.csv
results\figures
```

`REPORT_INDEX.html`을 브라우저로 열면 top clone, objective 후보, pathway 요약, 그림을 한 번에 볼 수 있습니다.

## 해석 기준

- 14번/clone decision summary: titer + qP + viability + extracellular metabolic burden 통합 요약
- 16/17번/pathway summary: measured exchange constraints를 만족하는 model-inferred pathway phenotype
- objective가 자동 선택되지 않으면 FBA/pFBA는 주로 feasibility/metabolic consistency check로 해석
