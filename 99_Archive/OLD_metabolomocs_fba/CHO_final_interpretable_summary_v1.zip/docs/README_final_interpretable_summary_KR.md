
# Final interpretable summary

16번 pathway pFBA가 대부분 0이고 일부 clone만 nonzero로 나오는 경우, 그 결과를 clone ranking 근거로 강하게 해석하기 어렵습니다.

이 스크립트는 최종 해석용으로 아래 지표를 요약합니다.

- final titer
- mean qP
- final viability
- glucose uptake burden
- lactate/glucose ratio
- glutamine uptake burden
- ammonia/glutamine ratio
- titer per glucose burden
- titer per glutamine burden
- pathway coverage QC

## 설치

```text
C:\CHO_POC\scripts\20_make_final_interpretable_summary.py
```

## 실행

```bat
cd C:\CHO_POC
python scripts\20_make_final_interpretable_summary.py --base C:\CHO_POC
```

## 출력

```text
results\tables\FINAL_INTERPRETABLE_CLONE_SUMMARY.csv
results\tables\FINAL_INTERPRETATION_GUIDE.md
```
