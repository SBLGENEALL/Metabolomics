"""
run_pipeline.py — CHO_METABOLOMICS 전체 파이프라인
사용: python run_pipeline.py --dataset practice_20aa --rate_days 7,10
"""
import subprocess, sys, os, time, argparse, glob

parser = argparse.ArgumentParser()
parser.add_argument("--dataset",   default="practice_20aa",
                    choices=["sowa2020","practice_20aa","own_experiment"])
parser.add_argument("--steps",     default="1,2,0,3,4,5,6,10",
                    help="실행 스텝 (0=objective, 1=로딩, ..., 10=Escher JSON)")
parser.add_argument("--rate_days", default="7,10",
                    help="Rate 구간 (7,10=전환기★ | 3,7=성장기 | 10,14=생산기)")
args = parser.parse_args()

ROOT      = os.path.dirname(os.path.abspath(__file__))
STEPS_DIR = os.path.join(ROOT, "scripts", "steps")
LOGS_DIR  = os.path.join(ROOT, "logs")
os.makedirs(LOGS_DIR, exist_ok=True)

STEP_MAP = {
    0: ("00_auto_objective.py",     "Objective Auto-Screening"),
    1: ("01_load_data.py",          "Data Load + Rate Calculation"),
    2: ("02_map_metabolites.py",    "Metabolite Mapping"),
    3: ("03_run_fba.py",            "FBA Run"),
    4: ("04_run_fva.py",            "FVA Run"),
    5: ("05_ko_screening.py",       "Reaction KO Screening"),
    6: ("06_figures.py",            "Publication Figures 1-8"),
    7: ("fig_qp_timeseries.py",     "qP Timeseries + Trade-off"),
    8: ("fig_pathway_flux_map.py",  "Detailed Flux Map"),
    9: ("multi_interval_fba.py",    "Multi-interval FBA"),
    10:("export_escher_flux.py",    "Escher Flux JSON (전체 반응 포함)"),
}

to_run = [int(x) for x in args.steps.split(",")]
env    = os.environ.copy()
env["PYTHONIOENCODING"] = "utf-8"

print("="*60)
print(f"  CHO_METABOLOMICS — {args.dataset}")
print(f"  Rate: Day {args.rate_days.replace(',','→')}  |  Steps: {args.steps}")
print("="*60)
t_total = time.time()

for num in to_run:
    if num not in STEP_MAP: continue
    script, desc = STEP_MAP[num]
    path = os.path.join(STEPS_DIR, script)
    if not os.path.exists(path):
        print(f"\n  [SKIP] {script} 없음"); continue
    print(f"\n  [{num}] {desc}")
    cmd = [sys.executable, path, "--dataset", args.dataset]
    if num == 1: cmd += ["--rate_days", args.rate_days]
    log = os.path.join(LOGS_DIR, f"{script.replace('.py','')}_{args.dataset}.log")
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True,
                       text=True, encoding="utf-8", errors="replace", env=env)
    with open(log, "w", encoding="utf-8") as lf:
        lf.write(r.stdout + "\n" + r.stderr)
    for line in r.stdout.split("\n"):
        if any(k in line for k in ["saved","obj=","optimal","OK","✔","✘","★","완료","Error"]) and line.strip():
            print(f"  {line.rstrip()}")
    if r.returncode == 0:
        print(f"  ✔ 완료")
    else:
        print(f"  ✘ 오류 → {log}")
        for l in (r.stdout+r.stderr).strip().split("\n")[-6:]:
            if l.strip(): print(f"    {l}")
        if input("  계속? (y/n): ").lower() != "y": break

elapsed = time.time()-t_total
print(f"\n{'='*60}\n  완료! {elapsed:.1f}초")
pngs = sorted(glob.glob(os.path.join(ROOT,"results",args.dataset,"figures","*.png")))
if pngs:
    print(f"\n  Figure ({len(pngs)}개):")
    for p in pngs:
        print(f"    {os.path.basename(p)}  ({os.path.getsize(p)//1024} KB)")
