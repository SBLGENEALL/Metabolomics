"""
04_run_fva.py — Flux Variability Analysis (배지 농도 기반 constraints)

핵심 수정:
  기존: AA lb=-1000 → FVA range ≈ -1000 (무의미)
  수정: 01_load_data에서 계산된 배지 농도 기반 bounds 사용
        → FVA range가 실제 생물학적 범위를 반영

분석 목적 (Mahadevan & Schilling 2003 Metab Eng 5:264):
  1. High vs Low의 flux 가능 범위 비교
     → 좁은 range = tight regulation = 해당 반응이 필수적
     → 넓은 range = 유연함 = 대안 경로 존재

  2. 반드시 흘러야 하는 반응 식별 (min == max)
     → Essential reactions for IgG production

사용: python scripts/steps/04_run_fva.py --dataset practice_20aa
"""
import sys, os, argparse, warnings, pickle
warnings.filterwarnings("ignore")

def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(6):
        if os.path.exists(os.path.join(cur, "src", "config.py")): return cur
        cur = os.path.dirname(cur)
    return cur
ROOT = _find_root()
if ROOT not in sys.path: sys.path.insert(0, ROOT)
from src.config import *
from src.fba_utils import (load_model, apply_bounds, open_amino_acid_exchanges,
                            save_table, save_figure)
from cobra.flux_analysis import flux_variability_analysis
import pandas as pd, numpy as np

parser = argparse.ArgumentParser()
parser.add_argument("--dataset",  default="practice_20aa")
parser.add_argument("--fraction", type=float, default=0.9,
                    help="FVA optimality fraction (기본 0.9 = 90%% of max)")
args = parser.parse_args()
DATASET  = args.dataset
FRACTION = args.fraction

print("="*65)
print(f"  04_run_fva.py — {DATASET}  fraction={FRACTION}")
print("="*65)
print("  Ref: Mahadevan & Schilling (2003) Metab Eng 5:264")
print("  Ref: Orth et al. (2010) Nat Biotechnol 28:245")

# ── 로딩 ──────────────────────────────────────────────
pkl_path = os.path.join(DATA_PROCESSED, f"rates_{DATASET}.pkl")
with open(pkl_path, "rb") as f:
    data = pickle.load(f)

all_constraints = data["all_constraints"]
high_clones     = data["high_clones"]
low_clones      = data["low_clones"]
clones          = data["clones"]
OBJ = data.get("selected_objective", OBJ_RXN)

model = load_model(verbose=True)
all_rxn_ids = {r.id for r in model.reactions}

# ── 평균 constraints 계산 ─────────────────────────────
def avg_cst(clone_list):
    cst_list = [all_constraints[c] for c in clone_list if c in all_constraints]
    if not cst_list: return {}
    ids = set()
    for c in cst_list: ids.update(c.keys())
    return {rid: (np.mean([c[rid][0] for c in cst_list if rid in c]),
                  np.mean([c[rid][1] for c in cst_list if rid in c]))
            for rid in ids}

high_cst = avg_cst(high_clones)
low_cst  = avg_cst(low_clones)

print(f"\n  High constraints: {len(high_cst)}개")
print(f"  Low  constraints: {len(low_cst)}개")

# ── 대표 constraints 확인 ─────────────────────────────
print(f"\n  [Constraint 확인] (배지 농도 기반)")
print(f"  {'Exchange':25s} {'High lb':>9s} {'High ub':>9s}  "
      f"{'Low lb':>9s} {'Low ub':>9s}")
print("  " + "─"*65)
KEY_EX = ["EX_glc_e","EX_lac_L_e","EX_gln_L_e","EX_nh4_e",
          "EX_ala_L_e","EX_leu_L_e","EX_glu_L_e"]
for eid in KEY_EX:
    hlb, hub = high_cst.get(eid, (0,0))
    llb, lub = low_cst.get(eid,  (0,0))
    ok = "✔" if abs(hlb) < 50 and abs(llb) < 50 else "⚠ range 큼"
    print(f"  {eid:25s} {hlb:9.4f} {hub:9.4f}  {llb:9.4f} {lub:9.4f}  {ok}")

# ── FVA 실행 ──────────────────────────────────────────
print(f"\n  [FVA 실행]")
print(f"  fraction_of_optimum={FRACTION} → {FRACTION*100:.0f}%% objective 달성 조건 하에서 flux 범위")
print(f"  Objective: {OBJ}")

fva_results = {}
for label, cst in [("High", high_cst), ("Low", low_cst)]:
    print(f"\n  → {label} producer ({len(cst)} constraints)...")
    with model:
        open_amino_acid_exchanges(model)   # Exchange 열기 (배지 설정)
        apply_bounds(model, cst)           # 측정값으로 덮어씌우기
        model.objective = OBJ

        pre = model.optimize()
        if pre.status != "optimal":
            print(f"    !! infeasible — FVA 건너뜀")
            continue
        print(f"    baseline obj = {pre.objective_value:.5f}")

        # FVA 대상: exchange + 핵심 내부 대사 반응
        # 내부 반응이 FVA의 진짜 가치 - 측정 안 된 flux 범위 추정
        # Ref: Mahadevan & Schilling (2003) Metab Eng 5:264
        INTERNAL_RXN_KEYWORDS = {
            # Glycolysis
            "HEX1":"Hexokinase", "PFK":"PFK", "PYK":"Pyruvate kinase",
            "PGI":"Phosphoglucose isomerase", "ENO":"Enolase",
            "GAPD":"GAPDH", "PGK":"PGK",
            # TCA cycle
            "CS":"Citrate synthase", "ACONT":"Aconitase",
            "ICDHy":"Isocitrate DH", "ICDHx":"Isocitrate DH (NAD)",
            "AKGDm":"alpha-KG DH", "SUCOAS":"Succinyl-CoA synthetase",
            "SUCD1m":"Succinate DH", "FUM":"Fumarase", "MDH":"Malate DH",
            "MDHm":"Malate DH (mito)",
            # Lactate / Pyruvate
            "LDH_L":"LDH", "PDHm":"PDH", "PYRt2m":"Pyruvate transport",
            # Glutaminolysis
            "GLUN":"Glutaminase", "GLUDxm":"Glutamate DH", "GLNS":"Glutamine synthetase",
            # PPP
            "G6PDH2r":"G6PDH (PPP)", "GND":"6-PG DH", "TKT1":"Transketolase",
            # Anaplerosis
            "PC":"Pyruvate carboxylase", "PCm":"Pyruvate carboxylase (mito)",
            "ME1m":"Malic enzyme", "ME2m":"Malic enzyme 2",
            "ACITL":"ATP-citrate lyase",
        }
        internal_rxns = []
        for rid in INTERNAL_RXN_KEYWORDS:
            matches = [r.id for r in model.reactions
                       if r.id == rid or r.id.startswith(rid)]
            internal_rxns.extend(matches[:1])  # 첫 매칭만

        fva_targets = list(model.exchanges) + \
                      [model.reactions.get_by_id(r) for r in internal_rxns
                       if r in {x.id for x in model.reactions}]
        print(f"    FVA 대상: exchange {len(list(model.exchanges))}개 + "
              f"내부반응 {len(internal_rxns)}개")

        try:
            fva = flux_variability_analysis(
                model,
                fraction_of_optimum=FRACTION,
                processes=FVA_PROCESSES,
                reaction_list=fva_targets,
            )
            # 내부반응 이름 매핑 저장
            fva.attrs = getattr(fva, "attrs", {})
            fva["mean"]  = (fva["minimum"] + fva["maximum"]) / 2
            fva["range"] = fva["maximum"] - fva["minimum"]
            fva["label"] = label
            fva_results[label] = fva
            print(f"    OK: {len(fva)} exchange reactions")

            # 주요 exchange 출력
            print(f"    {'Exchange':25s} {'min':>9s} {'max':>9s} {'range':>8s}  해석")
            print("    " + "─"*60)
            for eid in KEY_EX:
                if eid not in fva.index: continue
                mn = fva.loc[eid, "minimum"]
                mx = fva.loc[eid, "maximum"]
                rng = fva.loc[eid, "range"]
                names = {"EX_glc_e":"Glucose","EX_lac_L_e":"Lactate",
                         "EX_gln_L_e":"Glutamine","EX_nh4_e":"NH4+",
                         "EX_ala_L_e":"Alanine","EX_leu_L_e":"Leucine",
                         "EX_glu_L_e":"Glutamate"}
                nm = names.get(eid, eid)
                tight = "tight" if rng < 0.1 else ("medium" if rng < 1.0 else "wide")
                print(f"    {nm:25s} {mn:9.4f} {mx:9.4f} {rng:8.4f}  {tight}")

        except Exception as e:
            print(f"    !! FVA 오류: {e}")

# ── 비교 분석 ─────────────────────────────────────────
if len(fva_results) == 2:
    fva_h = fva_results["High"][["minimum","maximum","mean","range"]].rename(
        columns={c: f"{c}_High" for c in ["minimum","maximum","mean","range"]})
    fva_l = fva_results["Low"][["minimum","maximum","mean","range"]].rename(
        columns={c: f"{c}_Low" for c in ["minimum","maximum","mean","range"]})
    fva_cmp = fva_h.join(fva_l, how="outer")
    fva_cmp["delta_mean"]  = fva_cmp["mean_High"]  - fva_cmp["mean_Low"]
    fva_cmp["delta_range"] = fva_cmp["range_High"] - fva_cmp["range_Low"]
    fva_cmp["abs_delta"]   = fva_cmp["delta_mean"].abs()
    fva_cmp = fva_cmp.sort_values("abs_delta", ascending=False)

    print(f"\n  [High vs Low 주요 차이]")
    print(f"  {'Exchange':25s} {'H_mean':>9s} {'L_mean':>9s} {'Δmean':>9s} "
          f"{'H_range':>9s} {'L_range':>9s} {'Δrange':>9s}")
    print("  " + "─"*80)
    for eid in KEY_EX:
        if eid not in fva_cmp.index: continue
        row = fva_cmp.loc[eid]
        hm  = row.get("mean_High",  0); lm  = row.get("mean_Low",  0)
        hr  = row.get("range_High", 0); lr  = row.get("range_Low", 0)
        nm  = {"EX_glc_e":"Glucose","EX_lac_L_e":"Lactate",
               "EX_gln_L_e":"Glutamine","EX_nh4_e":"NH4+",
               "EX_ala_L_e":"Alanine","EX_leu_L_e":"Leucine",
               "EX_glu_L_e":"Glutamate"}.get(eid, eid)
        print(f"  {nm:25s} {hm:9.4f} {lm:9.4f} {hm-lm:+9.4f} "
              f"{hr:9.4f} {lr:9.4f} {hr-lr:+9.4f}")

    # FVA 생물학적 해석
    print(f"\n  [생물학적 해석]")
    print(f"  Ref: Mahadevan & Schilling (2003) — FVA interpretation")
    for eid, name, interpretation in [
        ("EX_glc_e",   "Glucose",   "range 좁음 = Glc 흡수량 tight하게 제어"),
        ("EX_lac_L_e", "Lactate",   "High에서 음수 mean = 재소비; range 좁음 = 일관성↑"),
        ("EX_gln_L_e", "Glutamine", "range 좁음 = TCA anaplerosis 필수"),
        ("EX_nh4_e",   "NH4+",      "High에서 낮음 = 세포독성 물질 적게 생성"),
    ]:
        if eid not in fva_cmp.index: continue
        row  = fva_cmp.loc[eid]
        hr   = row.get("range_High", 0); lr = row.get("range_Low", 0)
        tighter = "High가 더 tight" if hr < lr else "Low가 더 tight"
        print(f"  {name:12s}: {tighter} (H={hr:.3f}, L={lr:.3f})  → {interpretation}")

    # ── pFBA 기반 내부 반응 flux (High/Low 차이 추출) ────────
    # DM_igg_g FVA로는 내부 flux가 제약 안 받아 High=Low
    # → pFBA로 실제 flux 분포 계산 (constraint 차이 반영됨)
    # Ref: Lewis et al. (2010) Mol Syst Biol 6:390 (pFBA)
    from cobra.flux_analysis import pfba
    print(f"\n  [pFBA 기반 내부 반응 flux]")

    data["fva_results"]  = fva_results
    data["fva_fraction"] = FRACTION
    save_table(fva_cmp.reset_index(), "fva_comparison.csv", DATASET)

for label, fva in fva_results.items():
    save_table(fva.reset_index(), f"fva_{label.lower()}.csv", DATASET)

with open(pkl_path, "wb") as f:
    pickle.dump(data, f)

print(f"\n  OK  04_run_fva 완료")
print(f"  다음: python scripts/steps/05_ko_screening.py --dataset {DATASET}")
