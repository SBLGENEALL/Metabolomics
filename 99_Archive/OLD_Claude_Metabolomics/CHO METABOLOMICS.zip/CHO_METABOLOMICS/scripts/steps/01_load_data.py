"""
01_load_data.py
Feed-Corrected Rate + 배지 농도 기반 FBA Constraints 생성

Constraint 원칙:
  AA:     lb = -(배지 가용량 기반 max uptake × (1+buffer))  ← 이 이상은 못 흡수
          ub = 측정된 분비율 × (1+buffer)                   ← 이 이상은 못 분비
          → FBA가 AA 흡수 자유, but 배지 농도 이상은 불가

  Glc/Lac: lb = 측정 uptake rate × (1+buffer)              ← 단방향
           ub = 0 (uptake만)

  NH4+:   lb = 0, ub = 측정 secretion × (1+buffer)

Ref: Goudar et al. (2005) Biotechnol Prog 21:1193
Ref: Orth et al. (2010) Nat Biotechnol 28:245
Ref: Fouladiha et al. (2020) Bioprocess Biosyst Eng 44:1

사용: python scripts/steps/01_load_data.py --dataset practice_20aa --rate_days 7,10
"""
import sys, os, argparse, warnings, pickle
warnings.filterwarnings("ignore")

def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(6):
        if os.path.exists(os.path.join(cur, "src", "config.py")): return cur
        cur = os.path.dirname(cur)
    return cur
ROOT = _find_root()
if ROOT not in sys.path: sys.path.insert(0, ROOT)
from src.config import *
import pandas as pd, numpy as np

parser = argparse.ArgumentParser()
parser.add_argument("--dataset",   default="practice_20aa")
parser.add_argument("--rate_days", default="7,10")
parser.add_argument("--top_n",     type=int, default=3)
parser.add_argument("--buffer",    type=float, default=0.30,
                    help="Constraint buffer 비율 (기본 0.30 = ±30%%)")
args = parser.parse_args()
DATASET  = args.dataset
DAY_S, DAY_E = [int(x) for x in args.rate_days.split(",")]
TOP_N    = args.top_n
BUFFER   = args.buffer

print("="*65)
print(f"  01_load_data.py — {DATASET}  Day{DAY_S}→{DAY_E}  buffer={BUFFER:.0%}")
print("="*65)
print("  Ref: Goudar et al. (2005) Biotechnol Prog 21:1193")
print("  Ref: Orth et al. (2010) Nat Biotechnol 28:245")

EXCEL = {"practice_20aa": AA20_EXCEL, "sowa2020": SOWA_MMC1}.get(DATASET)
if not EXCEL:
    files = [f for f in os.listdir(OWN_DIR) if f.endswith(".xlsx")] \
            if os.path.exists(OWN_DIR) else []
    EXCEL = os.path.join(OWN_DIR, files[0]) if files else None
if not EXCEL or not os.path.exists(EXCEL):
    print(f"  !! 파일 없음: {EXCEL}"); sys.exit(1)
print(f"  파일: {os.path.basename(EXCEL)}")

if DATASET in ["practice_20aa", "own_experiment"]:
    df_raw = pd.read_excel(EXCEL, sheet_name="CHO_raw_data_practice_20AA")
    df_map = pd.read_excel(EXCEL, sheet_name="Metabolite_Map")
    try:
        fc_df    = pd.read_excel(EXCEL, sheet_name="Feed_Composition").set_index("Feed")
        has_feed = True
    except Exception:
        fc_df = pd.DataFrame(); has_feed = False
        print("  ⚠ Feed_Composition 없음")

    MET_COLS = df_map["Column"].tolist()
    COL2EX   = dict(zip(df_map["Column"], df_map["Exchange reaction expected by v4"]))
    COL2NAME = dict(zip(df_map["Column"], df_map["Canonical metabolite"]))
    FEED_COLS = {
        "FunctionMax":  "FunctionMax mL",
        "CellBoost 7A": "CellBoost 7A mL",
        "CellBoost 7B": "CellBoost 7B mL",
    }

    # AA Exchange IDs (흡수 방향 제한 완화)
    # 배지에 항상 존재 → 배지 농도 기반으로 상한 설정
    AA_EX_IDS = {
        "EX_ala_L_e","EX_arg_L_e","EX_asn_L_e","EX_asp_L_e","EX_cys_L_e",
        "EX_gln_L_e","EX_glu_L_e","EX_gly_e",  "EX_his_L_e","EX_ile_L_e",
        "EX_leu_L_e","EX_lys_L_e","EX_met_L_e","EX_phe_L_e","EX_pro_L_e",
        "EX_ser_L_e","EX_thr_L_e","EX_trp_L_e","EX_tyr_L_e","EX_val_L_e",
    }

    clones   = sorted(df_raw["Sample ID"].unique())
    days_all = sorted(df_raw["DAY"].unique())
    igG_last = df_raw[df_raw["DAY"]==max(days_all)].set_index("Sample ID")["IgG"].to_dict()
    sorted_c = sorted(igG_last, key=igG_last.get, reverse=True)
    HIGH_CLONES = sorted_c[:TOP_N]; LOW_CLONES = sorted_c[-TOP_N:]

    print(f"\n  Clones: {clones}")
    print(f"  Days  : {days_all}")
    print(f"  High  : {HIGH_CLONES}")
    print(f"  Low   : {LOW_CLONES}")

    def compute_rate_and_constraints(clone, d1, d2):
        sub  = df_raw[df_raw["Sample ID"]==clone].sort_values("DAY")
        rows = {int(r["DAY"]): r for _, r in sub.iterrows()}
        if d1 not in rows or d2 not in rows: return {}, {}
        r1, r2 = rows[d1], rows[d2]

        vcd1 = float(r1["Viable Density"]); vcd2 = float(r2["Viable Density"])
        v1   = float(r1.get("Culture Volume mL", 50))
        v2   = float(r2.get("Culture Volume mL", 50))
        v_avg = (v1+v2)/2
        dt_h  = (d2-d1)*24

        # IVCD [gDCW·h]  Ref: Goudar 2005
        ivcd = ((vcd1+vcd2)/2)*1e6*v_avg*dt_h*8e-12
        if ivcd <= 0: return {}, {}

        # Feed 부피 (cumulative → Δ)
        feed_vols = {}
        for fname, fcol in FEED_COLS.items():
            if fcol not in df_raw.columns: continue
            fv1 = float(r1.get(fcol,0)) if pd.notna(r1.get(fcol)) else 0
            fv2 = float(r2.get(fcol,0)) if pd.notna(r2.get(fcol)) else 0
            feed_vols[fname] = max(0.0, fv2-fv1)

        rates = {}
        cst   = {}
        for col in MET_COLS:
            if col not in df_raw.columns: continue
            c1 = float(r1[col]) if pd.notna(r1.get(col)) else 0.0
            c2 = float(r2[col]) if pd.notna(r2.get(col)) else 0.0

            # 배지 Day d1 농도 + Feed 추가량 = 이 구간에서 최대 이용 가능량 (µmol)
            feed_add = 0.0
            if has_feed:
                for fname, vol in feed_vols.items():
                    if fname in fc_df.index and col in fc_df.columns:
                        feed_add += vol * float(fc_df.loc[fname, col])

            total_avail_umol = c1 * v_avg + feed_add  # µmol (배지에 있는 전체량)

            # Feed-corrected net rate
            delta_obs = (c2-c1)*v_avg          # µmol 관측 변화
            net_mmol  = (delta_obs-feed_add)/1000
            q = net_mmol/ivcd                  # mmol/gDCW/h

            ex_id = COL2EX.get(col, "")
            if not ex_id: continue

            rates[col] = {
                "exchange_id":      ex_id,
                "metabolite_name":  COL2NAME.get(col, col),
                "c_start_mM":       c1,
                "c_end_mM":         c2,
                "delta_obs_umol":   delta_obs,
                "feed_add_umol":    feed_add,
                "net_mmol":         net_mmol,
                "ivcd_gDCWh":       ivcd,
                "rate_mmol_gDCWh":  q,
                "total_avail_umol": total_avail_umol,
            }

            if abs(q) < 1e-9 and total_avail_umol < 1:
                continue  # 거의 없고 변화도 없으면 제외

            if ex_id in AA_EX_IDS:
                # ── AA: 배지 농도 기반 ──────────────────────────
                # lb: 배지 전체량을 다 흡수한다고 가정한 최대 uptake에 buffer
                # ub: 측정된 분비율 상한 (or 0)
                # Ref: Orth et al. (2010) — medium constraints
                max_uptake_rate = -(total_avail_umol/1000/ivcd)  # 음수
                lb = max_uptake_rate * (1+BUFFER)   # 더 음수 (여유)
                ub = max(q, 0) * (1+BUFFER) if q > 0 else 0.0
                # 합리적 하한 (배지 농도가 0에 가까우면 제한 완화)
                lb = max(lb, -10.0)  # 최대 10 mmol/gDCW/h 이상은 비현실적

            elif q < 0:
                # ── 음수 (uptake): Glc, Lac ─────────────────────
                lb = q * (1+BUFFER)
                ub = 0.0

            else:
                # ── 양수 (secretion): NH4+ 등 ───────────────────
                lb = 0.0
                ub = q * (1+BUFFER)

            cst[ex_id] = (lb, ub)

        return rates, cst

    print(f"\n  {'Clone':12s} {'Glc_q':>9s} {'Lac_q':>9s} {'Lac/Glc':>9s}  IgG")
    print("  " + "─"*52)

    all_rates    = {}
    all_constraints = {}
    rate_records = []

    for clone in clones:
        rates, cst = compute_rate_and_constraints(clone, DAY_S, DAY_E)
        if not rates: continue
        all_rates[clone]       = rates
        all_constraints[clone] = cst

        gq = rates.get("Gluc", {}).get("rate_mmol_gDCWh", 0)
        lq = rates.get("Lac",  {}).get("rate_mmol_gDCWh", 0)
        ratio = lq/abs(gq) if abs(gq) > 1e-6 else 0
        tag = "★" if clone in HIGH_CLONES else ("▼" if clone in LOW_CLONES else " ")
        print(f"  {tag} {clone:10s} {gq:9.4f} {lq:9.4f} {ratio:9.3f}  {igG_last.get(clone,0):.0f}")
        for col, info in rates.items():
            rate_records.append({"clone": clone, "column": col, **info})

    # 대표 클론 constraints 출력
    if HIGH_CLONES and HIGH_CLONES[0] in all_constraints:
        hc = all_constraints[HIGH_CLONES[0]]
        print(f"\n  {HIGH_CLONES[0]} constraints 예시 (buffer={BUFFER:.0%}):")
        print(f"  {'Exchange':25s} {'lb':>10s} {'ub':>10s}  해석")
        print("  " + "─"*58)
        for ex_id, (lb, ub) in sorted(hc.items())[:8]:
            typ = "AA(배지기반)" if ex_id in AA_EX_IDS else \
                  "uptake" if ub==0 else "secretion"
            print(f"  {ex_id:25s} {lb:10.4f} {ub:10.4f}  {typ}")

    rate_df = pd.DataFrame(rate_records)
    n_total = sum(len(v) for v in all_constraints.values())
    print(f"\n  Constraints: 클론당 {n_total//len(all_constraints) if all_constraints else 0}개")

    os.makedirs(DATA_PROCESSED, exist_ok=True)
    pkl_path = os.path.join(DATA_PROCESSED, f"rates_{DATASET}.pkl")
    save_data = {
        "df_raw":           df_raw,
        "all_rates":        all_rates,
        "rate_df":          rate_df,
        "all_constraints":  all_constraints,
        "igG_day14":        igG_last,
        "high_clones":      HIGH_CLONES,
        "low_clones":       LOW_CLONES,
        "sorted_clones":    sorted_c,
        "clones":           clones,
        "MET_COLS":         MET_COLS,
        "COL2EX":           COL2EX,
        "COL2NAME":         COL2NAME,
        "day_interval":     (DAY_S, DAY_E),
        "dataset":          DATASET,
        "buffer":           BUFFER,
    }
    with open(pkl_path, "wb") as f:
        pickle.dump(save_data, f)
    out = results_dir(DATASET, "tables")
    rate_df.to_csv(os.path.join(out, "exchange_rates.csv"), index=False)
    df_raw.to_csv(os.path.join(out, "raw_timeseries.csv"),  index=False)
    print(f"  [saved] data/processed/rates_{DATASET}.pkl")
    print(f"  [saved] results/{DATASET}/tables/exchange_rates.csv")

print(f"\n  OK  완료")
