"""
06_figures.py — 논문 수준 Figure 생성 (8종 300 DPI)

Fig 1. IgG titer 시계열
Fig 2. Exchange rate 히트맵 (클론 × 대사물질)
Fig 3. Lac/Glc ratio 비교 + IgG 상관관계
Fig 4. FBA objective 클론별 + IgG 상관관계
Fig 5. High vs Low Exchange rate 비교
Fig 6. FVA Forest plot
Fig 7. Reaction KO 스크리닝
Fig 8. 종합 Summary Panel

사용:
  python scripts/steps/06_figures.py --dataset practice_20aa
"""
import sys, os, argparse, warnings, pickle
warnings.filterwarnings("ignore")

def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(5):
        if os.path.exists(os.path.join(cur, 'src', 'config.py')):
            return cur
        cur = os.path.dirname(cur)
    return cur
ROOT = _find_root()
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
from src.config import *
from src.fba_utils import save_figure

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
import seaborn as sns
from scipy import stats

parser = argparse.ArgumentParser()
parser.add_argument("--dataset", default="practice_20aa",
                    choices=["sowa2020", "practice_20aa", "own_experiment"])
args = parser.parse_args()
DATASET = args.dataset

print("=" * 60)
print(f"  06_figures.py — {DATASET}")
print("=" * 60)

# ── 스타일 설정 ───────────────────────────────────
plt.rcParams.update({
    "font.family":       "DejaVu Sans",
    "font.size":         9,
    "axes.labelsize":    10,
    "axes.titlesize":    10,
    "axes.titleweight":  "bold",
    "axes.linewidth":    0.8,
    "xtick.labelsize":   8.5,
    "ytick.labelsize":   8.5,
    "legend.fontsize":   8,
    "legend.framealpha": 0.85,
    "figure.dpi":        150,
    "savefig.dpi":       300,
    "savefig.bbox":      "tight",
    "lines.linewidth":   1.5,
    "patch.linewidth":   0.6,
})

P = PALETTE

# ── 데이터 로딩 ───────────────────────────────────
pkl_path = os.path.join(DATA_PROCESSED, f"rates_{DATASET}.pkl")
if not os.path.exists(pkl_path):
    print(f"  !! {pkl_path} 없음 — 05_ko_screening.py 먼저 실행")
    sys.exit(1)
with open(pkl_path, "rb") as f:
    data = pickle.load(f)

df_raw          = data["df_raw"]
all_rates       = data["all_rates"]
all_constraints = data["all_constraints"]
igG_day14       = data.get("igG_day14", {})
high_clones     = data["high_clones"]
low_clones      = data["low_clones"]
sorted_clones   = data["sorted_clones"]
clones          = data["clones"]
COL2NAME        = data.get("COL2NAME", {})
MET_COLS        = data.get("MET_COLS", [])
fba_df          = data.get("fba_df", pd.DataFrame())
lac_glc_df      = data.get("lac_glc_df", pd.DataFrame())
fva_results     = data.get("fva_results", {})
fva_internal    = data.get("fva_internal", pd.DataFrame())
FRACTION        = data.get("fva_fraction", 0.9)
OBJ             = data.get("selected_objective", OBJ_RXN)
fba_results     = data.get("fba_results", {})

# fva_results DataFrame index 복원 (pkl에서 로드 시 index가 reset될 수 있음)
for lbl, fdf in fva_results.items():
    if "reaction" in fdf.columns and fdf.index.dtype != object:
        fva_results[lbl] = fdf.set_index("reaction")
ko_df           = data.get("ko_df", pd.DataFrame())
impr_df         = data.get("impr_df", pd.DataFrame())
base_obj        = data.get("base_obj", 0)

# 클론별 색상
clone_colors = {}
for i, c in enumerate(clones):
    if c in high_clones:
        clone_colors[c] = P["high"]
    elif c in low_clones:
        clone_colors[c] = P["low"]
    else:
        clone_colors[c] = P["mid"][i % len(P["mid"])]

def ax_grid(ax):
    ax.xaxis.grid(True, ls=":", color="0.88")
    ax.yaxis.grid(True, ls=":", color="0.88")
    ax.set_axisbelow(True)

# ════════════════════════════════════════════════════
# FIG 1: IgG titer 시계열
# ════════════════════════════════════════════════════
print("  Fig 1: IgG timecourse...")
try:
    days = sorted(df_raw["DAY"].unique())
    fig, ax = plt.subplots(figsize=(9, 5))
    for clone in sorted_clones:
        sub = df_raw[df_raw["Sample ID"] == clone].sort_values("DAY")
        lw  = 2.5 if clone in high_clones else (1.0 if clone in low_clones else 1.5)
        ls  = "-"  if clone in high_clones else (":" if clone in low_clones else "--")
        ms  = 7    if clone in (high_clones + low_clones) else 5
        ax.plot(sub["DAY"], sub["IgG"], color=clone_colors[clone],
                lw=lw, ls=ls, marker="o", ms=ms, label=clone, zorder=3)
    ax.set_xlabel("Culture Day")
    ax.set_ylabel("IgG Titer (mg/L)")
    ax.set_title(f"Figure 1. IgG Production Time Course\n"
                 f"(Red=High producer top {len(high_clones)}, "
                 f"Blue=Low producer bottom {len(low_clones)})")
    ax_grid(ax)
    ax.legend(loc="upper left", ncol=2, fontsize=8)
    # 최종 titer 주석
    for clone in high_clones + low_clones:
        sub = df_raw[df_raw["Sample ID"] == clone]
        if len(sub) == 0: continue
        last = sub.loc[sub["DAY"].idxmax()]
        ax.annotate(f"{last['IgG']:.0f}",
                    xy=(last["DAY"], last["IgG"]),
                    xytext=(4, 0), textcoords="offset points",
                    fontsize=7.5, color=clone_colors[clone], va="center")
    plt.tight_layout()
    save_figure(fig, "Fig1_IgG_timecourse.png", DATASET)
except Exception as e:
    print(f"  !! Fig 1 오류: {e}")

# ════════════════════════════════════════════════════
# FIG 2: Exchange Rate 히트맵
# ════════════════════════════════════════════════════
print("  Fig 2: Exchange rate heatmap...")
try:
    rate_matrix = pd.DataFrame({
        clone: {COL2NAME.get(col, col): info["rate_mmol_gDCWh"]
                for col, info in rates.items()}
        for clone, rates in all_rates.items()
    }).T
    # IgG 기준 정렬
    rate_matrix = rate_matrix.loc[
        sorted(rate_matrix.index, key=lambda c: igG_day14.get(c, 0), reverse=True)
    ]
    fig, ax = plt.subplots(figsize=(max(12, len(MET_COLS) * 0.7), 5))
    sns.heatmap(rate_matrix, ax=ax, cmap="RdBu_r", center=0,
                annot=True, fmt=".3f", linewidths=0.4, linecolor="white",
                cbar_kws={"label": "Rate (mmol/gDCW/h)\nneg=uptake, pos=secretion",
                           "shrink": 0.7},
                annot_kws={"size": 7.5})
    ax.set_title(f"Figure 2. Exchange Rate Heatmap\n"
                 f"(Day {data['day_interval'][0]}→{data['day_interval'][1]}, "
                 f"feed-corrected, sorted by IgG titer)")
    ax.set_xlabel("Metabolite")
    ax.set_ylabel("Clone (sorted by IgG)")
    ax.tick_params(axis="x", rotation=45)
    ax.tick_params(axis="y", rotation=0)
    plt.tight_layout()
    save_figure(fig, "Fig2_rate_heatmap.png", DATASET)
except Exception as e:
    print(f"  !! Fig 2 오류: {e}")

# ════════════════════════════════════════════════════
# FIG 3: Lac/Glc ratio + IgG 상관관계
# ════════════════════════════════════════════════════
print("  Fig 3: Lac/Glc ratio...")
try:
    G = "EX_glc_e"; L = "EX_lac_L_e"
    lgc_rows = []
    for clone, cst in all_constraints.items():
        glc = abs(cst.get(G, (0, 0))[0])
        lac = cst.get(L, (0, 0))[0]
        # Fix: use all_rates for actual rate values (not constraints)
        # Negative ratio = lactate re-consumption (TCA active) - biologically valid
        # Ref: Zagari et al. (2013) New Biotechnology 30:238
        if clone in all_rates:
            rates_c = all_rates[clone]
            glc_col = next((c for c in rates_c if "gluc" in c.lower()), None)
            lac_col = next((c for c in rates_c if c.lower()=="lac" or "lactat" in c.lower()), None)
            if glc_col and lac_col:
                gq = rates_c[glc_col].get("rate_mmol_gDCWh", 0)
                lq = rates_c[lac_col].get("rate_mmol_gDCWh", 0)
                ratio = lq / abs(gq) if abs(gq) > 1e-6 else 0
            else:
                ratio = 0
        else:
            ratio = lac / glc if (glc > 0 and lac >= 0) else 0
        lgc_rows.append({"clone": clone, "lac_glc": ratio,
                          "igG": igG_day14.get(clone, 0)})
    lgdf = pd.DataFrame(lgc_rows).sort_values("igG", ascending=False)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

    ax = axes[0]
    cols_bar = [clone_colors[c] for c in lgdf["clone"]]
    bars = ax.bar(lgdf["clone"], lgdf["lac_glc"], color=cols_bar,
                  edgecolor="k", lw=0.5, zorder=3)
    ax.axhline(1.0, color="k", lw=1, ls="--", label="Ratio = 1.0")
    ax.set_ylabel("Lac/Glc Ratio (mmol/mmol)")
    ax.set_title("(A) Lac/Glc Ratio per Clone\n(<1.0 = efficient TCA)")
    ax.tick_params(axis="x", rotation=35)
    ax_grid(ax); ax.legend(fontsize=8)
    for bar, v in zip(bars, lgdf["lac_glc"]):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                f"{v:.2f}", ha="center", fontsize=7.5)

    ax = axes[1]
    sc_cols = [clone_colors[c] for c in lgdf["clone"]]
    ax.scatter(lgdf["lac_glc"], lgdf["igG"], c=sc_cols,
               s=80, edgecolors="k", lw=0.5, zorder=3)
    if len(lgdf) > 2:
        sl, ic, r, p, _ = stats.linregress(lgdf["lac_glc"], lgdf["igG"])
        x_line = np.linspace(lgdf["lac_glc"].min(), lgdf["lac_glc"].max(), 50)
        ax.plot(x_line, sl*x_line + ic, "k--", lw=1.2, alpha=0.7,
                label=f"r={r:.2f}, p={p:.3f}")
        ax.legend(fontsize=8)
    for _, row in lgdf.iterrows():
        ax.annotate(row["clone"], (row["lac_glc"], row["igG"]),
                    xytext=(4, 2), textcoords="offset points", fontsize=7.5)
    ax.set_xlabel("Lac/Glc Ratio")
    ax.set_ylabel("IgG Day 14 (mg/L)")
    ax.set_title("(B) Lac/Glc Ratio vs IgG Titer")
    ax_grid(ax)

    fig.suptitle("Figure 3. Lactate/Glucose Ratio — Metabolic Efficiency",
                 fontsize=11, fontweight="bold")
    plt.tight_layout()
    save_figure(fig, "Fig3_lac_glc_ratio.png", DATASET)
except Exception as e:
    print(f"  !! Fig 3 오류: {e}")

# ════════════════════════════════════════════════════
# FIG 4: Metabolic Flux 비교 (pFBA 기반 내부 반응)
# ════════════════════════════════════════════════════
# FBA obj가 모든 클론에서 동일(3.77) → 클론별 비교 불가
# 대신: 측정된 rates에서 핵심 대사 지표 비교
# Ref: Templeton et al. (2013) Biotechnol Bioeng 110:2508
print("  Fig 4: Metabolic indicators...")
try:
    import matplotlib.gridspec as gridspec

    # 측정 rates에서 metabolic indicator 계산
    met_rows = []
    for clone in sorted_clones:
        if clone not in all_rates: continue
        r = all_rates[clone]
        gq  = r.get("Gluc",{}).get("rate_mmol_gDCWh",0)
        lq  = r.get("Lac", {}).get("rate_mmol_gDCWh",0)
        nq  = r.get("NH4+",{}).get("rate_mmol_gDCWh",0)
        qq  = r.get("Gln", {}).get("rate_mmol_gDCWh",0)
        igG = igG_day14.get(clone, 0)
        lg  = lq/abs(gq) if abs(gq)>1e-6 else 0

        # TCA efficiency: Lac/Glc ratio 음수 = TCA 활성
        # Nitrogen efficiency: NH4+/Gln ratio = 암모니아 분비 효율
        nh4_gln = nq/abs(qq) if abs(qq)>1e-6 else 0

        met_rows.append({"clone":clone,"igG":igG,"glc_q":gq,"lac_q":lq,
                         "gln_q":qq,"nh4_q":nq,"lac_glc":lg,"nh4_gln":nh4_gln,
                         "group":"High" if clone in high_clones else
                                 ("Low" if clone in low_clones else "Mid")})

    met_df = pd.DataFrame(met_rows).sort_values("igG", ascending=False)
    cols4  = [P["high"] if c in high_clones else
              (P["low"] if c in low_clones else P["mid"][i%len(P["mid"])])
              for i,c in enumerate(met_df["clone"])]

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    # Panel A: Glucose uptake rate
    ax = axes[0]
    ax.bar(met_df["clone"], met_df["glc_q"].abs(), color=cols4,
           edgecolor="k", lw=0.5, zorder=3)
    ax.set_ylabel("|q_Glc| (mmol/gDCW/h)")
    ax.set_title("(A) Glucose Uptake Rate\n(효율적 High producer = 낮음)")
    ax.tick_params(axis="x", rotation=35)
    ax_grid(ax)
    for bar, v in zip(ax.patches, met_df["glc_q"].abs()):
        ax.text(bar.get_x()+bar.get_width()/2, v+0.005, f"{v:.3f}",
                ha="center", fontsize=7)

    # Panel B: Lac/Glc ratio
    ax = axes[1]
    bars = ax.bar(met_df["clone"], met_df["lac_glc"], color=cols4,
                  edgecolor="k", lw=0.5, zorder=3)
    ax.axhline(0, color="k", lw=0.8)
    ax.set_ylabel("Lac/Glc ratio (mmol/mmol)")
    ax.set_title("(B) Lac/Glc Ratio\n(음수 = Lactate 재소비 = TCA 활성)")
    ax.tick_params(axis="x", rotation=35)
    ax_grid(ax)

    # Panel C: NH4+ / Glutamine ratio
    ax = axes[2]
    ax.bar(met_df["clone"], met_df["nh4_gln"], color=cols4,
           edgecolor="k", lw=0.5, zorder=3)
    ax.set_ylabel("NH4+/Gln ratio")
    ax.set_title("(C) Ammonia/Glutamine Ratio\n(낮을수록 Gln 이용 효율적)")
    ax.tick_params(axis="x", rotation=35)
    ax_grid(ax)

    fig.suptitle(
        "Figure 4. Metabolic Efficiency Indicators\n"
        f"Day {interval[0]}→{interval[1]} feed-corrected rates | "
        "Ref: Templeton et al. (2013) Biotechnol Bioeng 110:2508",
        fontsize=11, fontweight="bold"
    )
    plt.tight_layout()
    save_figure(fig, "Fig4_metabolic_indicators.png", DATASET)
except Exception as e:
    print(f"  !! Fig 4 오류: {e}")
    import traceback; traceback.print_exc()

# FIG 5: High vs Low Exchange Rate 비교
# ════════════════════════════════════════════════════
print("  Fig 5: High vs Low exchange rates...")
try:
    high_avg = {col: np.mean([all_rates[c][col]["rate_mmol_gDCWh"]
                               for c in high_clones if c in all_rates and col in all_rates[c]])
                for col in MET_COLS}
    low_avg  = {col: np.mean([all_rates[c][col]["rate_mmol_gDCWh"]
                               for c in low_clones  if c in all_rates and col in all_rates[c]])
                for col in MET_COLS}
    diffs = {c: abs(high_avg.get(c, 0) - low_avg.get(c, 0)) for c in MET_COLS}
    sorted_mets = sorted(diffs, key=diffs.get, reverse=True)
    met_labels  = [COL2NAME.get(m, m) for m in sorted_mets]

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    y = np.arange(len(sorted_mets)); w = 0.36

    ax = axes[0]
    vh = [high_avg.get(m, 0) for m in sorted_mets]
    vl = [low_avg.get(m, 0)  for m in sorted_mets]
    ax.barh(y + w/2, vh, w, color=P["high"], label=f"High (n={len(high_clones)})",
            edgecolor="k", lw=0.4, zorder=3)
    ax.barh(y - w/2, vl, w, color=P["low"],  label=f"Low (n={len(low_clones)})",
            edgecolor="k", lw=0.4, zorder=3)
    ax.set_yticks(y); ax.set_yticklabels(met_labels, fontsize=8.5)
    ax.axvline(0, color="k", lw=0.8)
    ax.set_xlabel("Exchange Rate (mmol/gDCW/h)\n(neg=uptake, pos=secretion)")
    ax.set_title("(A) High vs Low Producer")
    ax.legend(); ax_grid(ax)

    ax = axes[1]
    delta = [high_avg.get(m, 0) - low_avg.get(m, 0) for m in sorted_mets]
    d_cols = [P["high"] if d > 0 else P["low"] for d in delta]
    ax.barh(y, delta, color=d_cols, edgecolor="k", lw=0.4, zorder=3)
    ax.axvline(0, color="k", lw=0.8)
    ax.set_yticks(y); ax.set_yticklabels(met_labels, fontsize=8.5)
    ax.set_xlabel("Delta Rate = High - Low (mmol/gDCW/h)\n"               "(>0: High secretes more or uptakes less  |  <0: High uptakes more)")
    ax.set_title("(B) Difference (High - Low)")
    patches = [mpatches.Patch(color=P["high"], label="Higher in High (more positive/less negative)"),
               mpatches.Patch(color=P["low"],  label="Lower in High (more negative)")]
    ax.legend(handles=patches, loc="lower right")
    ax_grid(ax)

    fig.suptitle(f"Figure 5. Exchange Rate Comparison: High vs Low Producer\n"
                 f"(High={high_clones}, Low={low_clones})",
                 fontsize=11, fontweight="bold")
    plt.tight_layout()
    save_figure(fig, "Fig5_high_vs_low_rates.png", DATASET)
except Exception as e:
    print(f"  !! Fig 5 오류: {e}")

# ════════════════════════════════════════════════════
# FIG 6: FVA - 의미있는 차이만 표시
# ════════════════════════════════════════════════════
print("  Fig 6: FVA forest plot...")
try:
    if len(fva_results) >= 1:
        # 실제 차이가 있는 반응만 선택 (Glc, Lac, NH4+, Gln)
        KEY_EX = {
            "EX_glc_e":   "Glucose",
            "EX_lac_L_e": "Lactate",
            "EX_nh4_e":   "NH4+",
            "EX_gln_L_e": "Glutamine",
        }

        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        # Panel A: Forest plot (4개 핵심 반응)
        ax = axes[0]
        y  = np.arange(len(KEY_EX))
        fva_cols = {"High": P["high"], "Low": P["low"]}

        for i, (label, fdf) in enumerate(fva_results.items()):
            color  = fva_cols.get(label, P["mid"][i])
            offset = (i - 0.5) * 0.3
            for j, (eid, name) in enumerate(KEY_EX.items()):
                if eid not in fdf.index: continue
                mn  = float(fdf.loc[eid, "minimum"])
                mx  = float(fdf.loc[eid, "maximum"])
                mid = float(fdf.loc[eid, "mean"])
                # range bar
                ax.barh(y[j]+offset, mx-mn, left=mn, height=0.22,
                        color=color, alpha=0.55, edgecolor=color, lw=0.5)
                # mean diamond
                ax.plot(mid, y[j]+offset, "D", color=color, ms=7, zorder=5,
                        label=label if j==0 else "")
                ax.text(mid, y[j]+offset+0.13, f"{mid:.3f}",
                        ha="center", fontsize=8, color=color, fontweight="bold")

        ax.set_yticks(y); ax.set_yticklabels(list(KEY_EX.values()), fontsize=11)
        ax.axvline(0, color="k", lw=1, ls="--")
        ax.set_xlabel("Flux (mmol/gDCW/h)")
        ax.set_title("(A) FVA Flux Ranges — Key Exchanges\n"
                     "diamond=mean | bar=feasible range (90% optimality)")
        ax.legend(fontsize=9); ax_grid(ax)

        # Panel B: 실측값 vs FVA mean 비교
        ax = axes[1]
        names = list(KEY_EX.values())
        eids  = list(KEY_EX.keys())
        x     = np.arange(len(names))
        bw    = 0.22

        # 실측 rates
        def mean_rate(clist, eid):
            vals = []
            for c in clist:
                if c not in all_rates: continue
                for col, info in all_rates[c].items():
                    if info.get("exchange_id","") == eid:
                        vals.append(info.get("rate_mmol_gDCWh",0))
            return np.mean(vals) if vals else 0

        meas_h = [mean_rate(high_clones, e) for e in eids]
        meas_l = [mean_rate(low_clones,  e) for e in eids]
        fva_h  = [float(fva_results["High"].loc[e,"mean"])
                  if "High" in fva_results and e in fva_results["High"].index else 0 for e in eids]
        fva_l  = [float(fva_results["Low"].loc[e,"mean"])
                  if "Low"  in fva_results and e in fva_results["Low"].index  else 0 for e in eids]

        ax.bar(x-1.5*bw, meas_h, bw, color=P["high"],   alpha=0.9, label="High (measured)", edgecolor="k", lw=0.5)
        ax.bar(x-0.5*bw, fva_h,  bw, color=P["high"],   alpha=0.4, label="High (FVA mean)", edgecolor=P["high"], lw=1, ls="--", hatch="//")
        ax.bar(x+0.5*bw, meas_l, bw, color=P["low"],    alpha=0.9, label="Low (measured)",  edgecolor="k", lw=0.5)
        ax.bar(x+1.5*bw, fva_l,  bw, color=P["low"],    alpha=0.4, label="Low (FVA mean)",  edgecolor=P["low"],  lw=1, ls="--", hatch="//")

        ax.axhline(0, color="k", lw=0.8)
        ax.set_xticks(x); ax.set_xticklabels(names, fontsize=11)
        ax.set_ylabel("Flux (mmol/gDCW/h)")
        ax.set_title("(B) Measured vs FVA Mean\n"
                     "Solid=measured | Hatched=FVA feasible mean")
        ax.legend(fontsize=8, ncol=2); ax_grid(ax)

        fig.suptitle(
            "Figure 6. FVA — High vs Low Producer\n"
            f"Medium-based constraints | 90% optimality | Obj={OBJ} | "
            "Ref: Mahadevan & Schilling (2003)",
            fontsize=11, fontweight="bold"
        )
        plt.tight_layout()
        save_figure(fig, "Fig6_fva_forest.png", DATASET)
    else:
        print("  -- FVA 결과 없음")
except Exception as e:
    print(f"  !! Fig 6 error: {e}")
    import traceback; traceback.print_exc()

# FIG 7: KO Screening (biomass_cho_prod 기반)
# ════════════════════════════════════════════════════
print("  Fig 7: KO screening...")
try:
    if len(ko_df) > 0 and "delta_pct" in ko_df.columns:
        valid = ko_df[ko_df["delta_pct"].notna() &
                      ko_df["n_rxns"].fillna(0).gt(0)].copy()

        # 결과 품질 체크 - 모두 -100%이면 summary figure로 대체
        if len(valid) == 0 or (valid["delta_pct"] < -99).all():
            raise ValueError("KO results invalid (all -100%), using alternative")

        valid = valid.sort_values("delta_pct")
        n     = len(valid)
        fig_h = max(5, n * 0.52)
        fig, ax = plt.subplots(figsize=(10, fig_h))

        cols = [P["impr"] if v > 0.5 else (P["danger"] if v < -5 else P["neutral"])
                for v in valid["delta_pct"]]
        ax.barh(range(n), valid["delta_pct"], color=cols, edgecolor="k", lw=0.4)
        ax.axvline(0, color="k", lw=1)
        ax.set_yticks(range(n))
        ax.set_yticklabels([t.replace("\n"," ") for t in valid["target"]], fontsize=8)
        ax.set_xlabel(f"Delta Objective (biomass_cho_prod) [%]")
        ax.set_title("Figure 7. Reaction KO In Silico Screening\n"
                     "(biomass_cho_prod | open medium baseline)\n"
                     "Ref: Lim et al. (2010) Metab Eng 12:614")
        for i, v in enumerate(valid["delta_pct"]):
            ax.text(v + (0.3 if v >= 0 else -0.3), i, f"{v:+.1f}%",
                    va="center", ha="left" if v >= 0 else "right", fontsize=8)
        handles = [mpatches.Patch(color=P["impr"],    label="Improved (>0.5%)"),
                   mpatches.Patch(color=P["neutral"],  label="Neutral"),
                   mpatches.Patch(color=P["danger"],   label="Reduced (<-5%)")]
        ax.legend(handles=handles, loc="lower right", fontsize=8)
        ax_grid(ax); plt.tight_layout()
        save_figure(fig, "Fig7_ko_screen.png", DATASET)

    else:
        raise ValueError("ko_df empty or no delta_pct")

except Exception as e:
    print(f"  ! KO figure error: {e} — using metabolic summary instead")
    # KO 결과 없으면: 클론별 대사 효율 종합 지표
    if all_rates and igG_day14:
        rows = []
        for clone in sorted(igG_day14, key=igG_day14.get, reverse=True):
            if clone not in all_rates: continue
            r = all_rates[clone]
            gq = r.get("Gluc",{}).get("rate_mmol_gDCWh",0)
            lq = r.get("Lac", {}).get("rate_mmol_gDCWh",0)
            nq = r.get("NH4+",{}).get("rate_mmol_gDCWh",0)
            qq = r.get("Gln", {}).get("rate_mmol_gDCWh",0)
            rows.append({"clone":clone,"igG":igG_day14[clone],
                         "glc_eff": abs(igG_day14[clone]/abs(gq)/1000) if gq else 0,
                         "lac_glc": lq/abs(gq) if abs(gq)>1e-6 else 0,
                         "nh4_gln": nq/abs(qq) if abs(qq)>1e-6 else 0})
        eff_df = pd.DataFrame(rows)

        fig, axes = plt.subplots(1, 3, figsize=(13, 4.5))
        cols = [P["high"] if c in high_clones else
                (P["low"] if c in low_clones else P["mid"][i%len(P["mid"])])
                for i,c in enumerate(eff_df["clone"])]

        for ax, col, title, ylabel in zip(
            axes,
            ["glc_eff","lac_glc","nh4_gln"],
            ["(A) IgG/Glucose Efficiency\n(higher = better)","(B) Lac/Glc Ratio\n(negative = TCA active)","(C) NH4+/Glutamine\n(lower = less waste)"],
            ["IgG [mg/L] / |q_Glc| [a.u.]","Lac/Glc (mmol/mmol)","NH4+/Gln ratio"]
        ):
            ax.bar(eff_df["clone"], eff_df[col], color=cols, edgecolor="k", lw=0.5, zorder=3)
            ax.axhline(0, color="k", lw=0.8)
            ax.set_ylabel(ylabel, fontsize=8)
            ax.set_title(title, fontsize=9)
            ax.tick_params(axis="x", rotation=35, labelsize=8)
            ax_grid(ax)

        fig.suptitle("Figure 7. Metabolic Efficiency — High vs Low Producer\n"
                     "Day 7→10 feed-corrected rates | Ref: Zagari et al. (2013)",
                     fontsize=11, fontweight="bold")
        plt.tight_layout()
        save_figure(fig, "Fig7_ko_screen.png", DATASET)

# FIG 8: Summary Panel (중복 없는 6패널)
# ════════════════════════════════════════════════════
print("  Fig 8: Summary panel...")
try:
    import matplotlib.gridspec as gridspec
    fig = plt.figure(figsize=(20, 12))
    gs  = gridspec.GridSpec(2, 3, figure=fig, hspace=0.42, wspace=0.32)

    # ── A: IgG time course ──────────────────────────
    ax8a = fig.add_subplot(gs[0, 0])
    if "df_raw" in data:
        df_raw = data["df_raw"]
        days_all = sorted(df_raw["DAY"].unique())
        for clone in sorted_clones:
            sub = df_raw[df_raw["Sample ID"]==clone].sort_values("DAY")
            ls  = "-"  if clone in high_clones else (":" if clone in low_clones else "--")
            lw  = 2.0  if clone in high_clones else (1.2 if clone in low_clones else 1.0)
            ax8a.plot(sub["DAY"], sub["IgG"], ls=ls, lw=lw,
                      color=clone_colors.get(clone,"gray"), label=clone, marker="o", ms=3)
    ax8a.set_xlabel("Day"); ax8a.set_ylabel("IgG (mg/L)")
    ax8a.set_title("(A) IgG Time Course"); ax_grid(ax8a)

    # ── B: Lac/Glc ratio (bar, sorted by IgG) ───────
    ax8b = fig.add_subplot(gs[0, 1])
    if all_rates:
        sc = sorted(igG_day14, key=igG_day14.get, reverse=True)
        ratios = []
        for c in sc:
            r  = all_rates.get(c,{})
            gq = r.get("Gluc",{}).get("rate_mmol_gDCWh",0)
            lq = r.get("Lac", {}).get("rate_mmol_gDCWh",0)
            ratios.append(lq/abs(gq) if abs(gq)>1e-6 else 0)
        cols8b = [clone_colors.get(c,"gray") for c in sc]
        ax8b.bar(sc, ratios, color=cols8b, edgecolor="k", lw=0.5, zorder=3)
        ax8b.axhline(0, color="k", lw=0.8)
        for bar,v in zip(ax8b.patches, ratios):
            ax8b.text(bar.get_x()+bar.get_width()/2,
                      v+(0.008 if v>=0 else -0.015),
                      f"{v:.2f}", ha="center", fontsize=7)
    ax8b.set_ylabel("Lac/Glc (mmol/mmol)")
    ax8b.set_title("(B) Lac/Glc Ratio\n(neg=TCA active)")
    ax8b.tick_params(axis="x", rotation=40, labelsize=7.5); ax_grid(ax8b)

    # ── C: Glucose uptake rate (sorted by IgG) ──────
    ax8c = fig.add_subplot(gs[0, 2])
    if all_rates:
        sc  = sorted(igG_day14, key=igG_day14.get, reverse=True)
        gqs = [abs(all_rates.get(c,{}).get("Gluc",{}).get("rate_mmol_gDCWh",0)) for c in sc]
        ax8c.bar(sc, gqs, color=[clone_colors.get(c,"gray") for c in sc],
                 edgecolor="k", lw=0.5, zorder=3)
    ax8c.set_ylabel("|q_Glc| (mmol/gDCW/h)")
    ax8c.set_title("(C) Glucose Uptake Rate\n(lower = more efficient)")
    ax8c.tick_params(axis="x", rotation=40, labelsize=7.5); ax_grid(ax8c)

    # ── D: Exchange rates High vs Low (Top 6) ───────
    ax8d = fig.add_subplot(gs[1, 0])
    if all_rates:
        top_mets = ["Glucose","Lactate","Glutamine","Ammonia","Alanine","Proline"]
        col2met  = {v:k for k,v in COL2NAME.items()}
        vals_h, vals_l, names_d = [], [], []
        for met in top_mets:
            col = col2met.get(met, met)
            vh  = np.mean([all_rates.get(c,{}).get(col,{}).get("rate_mmol_gDCWh",0)
                           for c in high_clones if c in all_rates])
            vl  = np.mean([all_rates.get(c,{}).get(col,{}).get("rate_mmol_gDCWh",0)
                           for c in low_clones if c in all_rates])
            vals_h.append(vh); vals_l.append(vl); names_d.append(met)
        y8d = np.arange(len(names_d))
        ax8d.barh(y8d+0.2, vals_h, 0.4, color=P["high"], alpha=0.85, label=f"High (n={len(high_clones)})", edgecolor="k", lw=0.4)
        ax8d.barh(y8d-0.2, vals_l, 0.4, color=P["low"],  alpha=0.85, label=f"Low (n={len(low_clones)})",  edgecolor="k", lw=0.4)
        ax8d.set_yticks(y8d); ax8d.set_yticklabels(names_d, fontsize=9)
        ax8d.axvline(0, color="k", lw=0.8)
        ax8d.legend(fontsize=8); ax_grid(ax8d)
    ax8d.set_xlabel("Rate (mmol/gDCW/h)")
    ax8d.set_title("(D) Exchange Rates — High vs Low")

    # ── E: FVA range 비교 ───────────────────────────
    ax8e = fig.add_subplot(gs[1, 1])
    if len(fva_results) >= 2:
        kex4 = {"EX_glc_e":"Glucose","EX_lac_L_e":"Lactate",
                "EX_nh4_e":"NH4+","EX_gln_L_e":"Glutamine"}
        names8e = list(kex4.values()); eids8e = list(kex4.keys())
        rh = [float(fva_results["High"].loc[e,"range"])
              if e in fva_results["High"].index else 0 for e in eids8e]
        rl = [float(fva_results["Low"].loc[e,"range"])
              if e in fva_results["Low"].index  else 0 for e in eids8e]
        y8e = np.arange(len(names8e))
        ax8e.barh(y8e+0.2, rh, 0.4, color=P["high"], alpha=0.85, label="High", edgecolor="k", lw=0.4)
        ax8e.barh(y8e-0.2, rl, 0.4, color=P["low"],  alpha=0.85, label="Low",  edgecolor="k", lw=0.4)
        ax8e.set_yticks(y8e); ax8e.set_yticklabels(names8e, fontsize=9)
        ax8e.legend(fontsize=8); ax_grid(ax8e)
    ax8e.set_xlabel("FVA Range (mmol/gDCW/h)")
    ax8e.set_title("(E) FVA Flux Range\n(smaller = tighter regulation)")

    # ── F: KO or Metabolic indicators ───────────────
    ax8f = fig.add_subplot(gs[1, 2])
    if len(ko_df) > 0 and "delta_pct" in ko_df.columns:
        vko = ko_df[ko_df["delta_pct"].notna() & ko_df["n_rxns"].fillna(0).gt(0)]
        if len(vko) > 0 and not (vko["delta_pct"] < -99).all():
            vko = vko.sort_values("delta_pct").tail(10)
            cols8f = [P["impr"] if v>0.5 else (P["danger"] if v<-5 else P["neutral"])
                      for v in vko["delta_pct"]]
            ax8f.barh(range(len(vko)), vko["delta_pct"], color=cols8f, edgecolor="k", lw=0.4)
            ax8f.set_yticks(range(len(vko)))
            ax8f.set_yticklabels([t.replace("\n"," ")[:15] for t in vko["target"]], fontsize=8)
            ax8f.axvline(0, color="k", lw=0.8); ax_grid(ax8f)
            ax8f.set_xlabel("Delta Obj (%)"); ax8f.set_title("(F) Reaction KO")
        else:
            # KO 불가 → NH4+/Gln ratio 대체
            if all_rates:
                sc2 = sorted(igG_day14, key=igG_day14.get, reverse=True)
                nh4_gln = []
                for c in sc2:
                    r  = all_rates.get(c,{})
                    nq = r.get("NH4+",{}).get("rate_mmol_gDCWh",0)
                    qq = r.get("Gln", {}).get("rate_mmol_gDCWh",0)
                    nh4_gln.append(nq/abs(qq) if abs(qq)>1e-6 else 0)
                ax8f.bar(sc2, nh4_gln, color=[clone_colors.get(c,"gray") for c in sc2],
                         edgecolor="k", lw=0.5, zorder=3)
                ax8f.set_ylabel("NH4+/Gln ratio")
                ax8f.set_title("(F) Ammonia/Glutamine\n(lower = efficient N use)")
                ax8f.tick_params(axis="x", rotation=40, labelsize=7.5); ax_grid(ax8f)

    fig.suptitle(
        f"CHO Fed-Batch FBA/FVA Summary — {DATASET}\n"
        f"iCHO3K prod model | Day {interval[0]}→{interval[1]} rates | "
        f"High={high_clones} | Low={low_clones}",
        fontsize=12, fontweight="bold"
    )
    save_figure(fig, "Fig8_summary_panel.png", DATASET)
except Exception as e:
    print(f"  !! Fig 8 error: {e}")
    import traceback; traceback.print_exc()

# FIG 9: Internal Metabolic Reaction Flux (pFBA)
# ════════════════════════════════════════════════════
# FVA의 진짜 가치 = 측정 불가 내부 flux 추정
# DM_igg_g FVA로는 내부 flux 제약 안 받아 High=Low
# → pFBA(biomass objective)로 실제 flux 계산
# Ref: Lewis et al. (2010) Mol Syst Biol 6:390
print("  Fig 9: Internal reaction flux (pFBA)...")
try:
    if len(fva_internal) > 0 and "flux_High" in fva_internal.columns:
        act = fva_internal[
            (fva_internal["flux_High"].abs() > 1e-4) |
            (fva_internal["flux_Low"].abs() > 1e-4)
        ].copy()
        if len(act) == 0:
            act = fva_internal.copy()
        act["abs_delta"] = act["delta"].abs()
        act = act.sort_values("abs_delta", ascending=True)

        fig, axes = plt.subplots(1, 2, figsize=(15, max(5, len(act)*0.5)))

        # Panel A: flux High vs Low
        ax = axes[0]
        y = np.arange(len(act))
        ax.barh(y+0.2, act["flux_High"], 0.4, color=P["high"], alpha=0.85,
                label=f"High (n={len(high_clones)})", edgecolor="k", lw=0.4)
        ax.barh(y-0.2, act["flux_Low"], 0.4, color=P["low"], alpha=0.85,
                label=f"Low (n={len(low_clones)})", edgecolor="k", lw=0.4)
        ax.axvline(0, color="k", lw=0.8)
        ax.set_yticks(y); ax.set_yticklabels(act["name"], fontsize=9)
        ax.set_xlabel("pFBA Flux (mmol/gDCW/h)")
        ax.set_title("(A) Internal Reaction Flux\n"
                     "(measured-impossible, estimated by pFBA)")
        ax.legend(fontsize=9); ax_grid(ax)

        # Panel B: High - Low difference
        ax = axes[1]
        cols = [P["high"] if d > 0 else P["low"] for d in act["delta"]]
        ax.barh(y, act["delta"], color=cols, edgecolor="k", lw=0.4)
        ax.axvline(0, color="k", lw=0.8)
        ax.set_yticks(y); ax.set_yticklabels(act["name"], fontsize=9)
        ax.set_xlabel("Flux Difference (High - Low)")
        ax.set_title("(B) High vs Low Difference\n"
                     "(red=higher in High, blue=higher in Low)")
        for i, d in enumerate(act["delta"]):
            ax.text(d + (0.002 if d>=0 else -0.002), i, f"{d:+.3f}",
                    va="center", ha="left" if d>=0 else "right", fontsize=7)
        ax_grid(ax)

        fig.suptitle(
            "Figure 9. Internal Metabolic Reaction Flux (pFBA)\n"
            "Glycolysis / TCA / Glutaminolysis — fluxes not directly measurable\n"
            "Ref: Lewis et al. (2010) Mol Syst Biol 6:390",
            fontsize=11, fontweight="bold"
        )
        plt.tight_layout()
        save_figure(fig, "Fig9_internal_fva.png", DATASET)
    else:
        print("  -- Internal flux data not available (rerun 04_run_fva.py)")
except Exception as e:
    print(f"  !! Fig 9 error: {e}")
    import traceback; traceback.print_exc()


