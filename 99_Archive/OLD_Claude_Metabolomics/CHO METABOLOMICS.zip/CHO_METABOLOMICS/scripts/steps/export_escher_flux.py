"""
export_escher_flux.py
Escher Flux Map JSON + HTML 생성
Ref: King et al. (2015) PLOS Comput Biol 11:e1004321
사용: python scripts/steps/export_escher_flux.py --dataset practice_20aa
"""
import sys, os, argparse, warnings, pickle, json, shutil
warnings.filterwarnings("ignore")

def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(6):
        if os.path.exists(os.path.join(cur, "src", "config.py")): return cur
        cur = os.path.dirname(cur)
    return cur
ROOT = _find_root()
if ROOT not in sys.path: sys.path.insert(0, ROOT)
from src.config import *
from src.fba_utils import (load_model, apply_bounds, open_amino_acid_exchanges, avg_constraints)
import numpy as np

def _apply_with_medium(model, constraints):
    """배지 아미노산 먼저 열고 constraint 적용"""
    open_amino_acid_exchanges(model)
    return apply_bounds(model, constraints)


parser = argparse.ArgumentParser()
parser.add_argument("--dataset", default="practice_20aa")
args   = parser.parse_args()
DATASET = args.dataset

print("="*65)
print(f"  export_escher_flux.py -- {DATASET}")
print("="*65)

pkl_path = os.path.join(DATA_PROCESSED, f"rates_{DATASET}.pkl")
if not os.path.exists(pkl_path):
    print(f"  !! pkl 없음: {pkl_path}"); import sys; sys.exit(1)
with open(pkl_path, "rb") as f:
    data = pickle.load(f)

all_constraints = data.get("all_constraints", {})
high_clones     = data["high_clones"]
low_clones      = data["low_clones"]
OBJ = data.get("selected_objective", OBJ_RXN)
out_dir = results_dir(DATASET, "tables")
fig_dir = results_dir(DATASET, "figures")

# ── FBA 전체 flux ──────────────────────────────────────
print(f"\n  [FBA]  objective={OBJ}")
model = load_model(verbose=True)

# Exchange ID 매핑 (iCHO3K → BiGG)
EX_MAP = {
    "EX_glc_e":"EX_glc__D_e","EX_lac_L_e":"EX_lac__L_e",
    "EX_gln_L_e":"EX_gln__L_e","EX_glu_L_e":"EX_glu__L_e",
    "EX_nh4_e":"EX_nh4_e","EX_pyr_e":"EX_pyr_e",
    "EX_o2_e":"EX_o2_e","EX_co2_e":"EX_co2_e",
    "EX_h2o_e":"EX_h2o_e","EX_h_e":"EX_h_e",
    "EX_atp_e":"EX_atp_e",
}

def safe_float(v):
    """numpy float 등을 Python float으로 안전하게 변환"""
    try: return float(v)
    except: return 0.0

results = {}
for label, cl in [("high", high_clones), ("low", low_clones)]:
    cst = avg_constraints(cl, all_constraints)
    with model:
        _apply_with_medium(model, cst)
        model.objective = OBJ
        sol = model.optimize()
        if sol.status == "optimal":
            # 모든 키를 str으로 보장, 값을 Python float으로 변환
            results[label] = {
                str(rxn_id): safe_float(flux)
                for rxn_id, flux in sol.fluxes.items()
            }
            nz = sum(1 for v in results[label].values() if abs(v) > 1e-6)
            print(f"  {label}: obj={sol.objective_value:.5f}  nonzero={nz}")
        else:
            print(f"  {label}: {sol.status} -- fallback to stored ex_flux")
            # fallback: fba_results에서 가져오기
            stored = data.get("fba_results", {})
            merged = {}
            for c in cl:
                for k, v in stored.get(c, {}).get("ex_flux", {}).items():
                    merged.setdefault(str(k), []).append(safe_float(v))
            results[label] = {k: float(np.mean(v)) for k, v in merged.items()}
            print(f"  {label}: fallback ({len(results[label])} rxns)")

if not results:
    print("  !! FBA 결과 없음"); import sys; sys.exit(1)

# ── JSON 저장 ──────────────────────────────────────────
print(f"\n  [JSON 저장]")
for label, fd in results.items():
    if not fd: continue

    # 전체 (0 포함) - str key, float value 보장
    full = {str(k): round(safe_float(v), 6) for k, v in fd.items()}

    # nonzero only
    nz   = {k: v for k, v in full.items() if abs(v) > 1e-6}

    # BiGG ID 변환 (str key 유지)
    bigg = {EX_MAP.get(str(k), str(k)): v for k, v in nz.items()}

    for name, d in [("full", full), ("nonzero", nz), ("bigg", bigg)]:
        p = os.path.join(out_dir, f"escher_flux_{label}_{name}.json")
        with open(p, "w") as f:
            json.dump(d, f, indent=2)
    print(f"  {label}: full={len(full)}, nonzero={len(nz)}")

# fold change
if len(results) == 2:
    fd_h = results.get("high", {}); fd_l = results.get("low", {})
    fc = {}
    for k in fd_h:
        fh = safe_float(fd_h[k])
        fl = safe_float(fd_l.get(k, 0))
        bigg_id = EX_MAP.get(str(k), str(k))  # 반드시 str
        if abs(fl) > 1e-6:
            fc[bigg_id] = round(fh/fl, 4)
        elif abs(fh) > 1e-6:
            fc[bigg_id] = 2.0
        else:
            fc[bigg_id] = 1.0
    with open(os.path.join(out_dir, "escher_flux_fold_change.json"), "w") as f:
        json.dump(fc, f, indent=2)
    print(f"  fold_change: {len(fc)} rxns")

# iCHO3K 모델 JSON 복사 (Escher Load Model용)
if MODEL_PATH and os.path.exists(MODEL_PATH):
    dst = os.path.join(out_dir, "iCHO3K_model_for_escher.json")
    shutil.copy2(MODEL_PATH, dst)
    print(f"  [saved] iCHO3K_model_for_escher.json  ({os.path.getsize(dst)//1024} KB)")

# ── Standalone HTML ────────────────────────────────────
print(f"\n  [HTML 생성]")
for label, fd in results.items():
    if not fd: continue
    nz_bigg = {
        EX_MAP.get(str(k), str(k)): round(safe_float(v), 6)
        for k, v in fd.items() if abs(safe_float(v)) > 1e-6
    }
    color = "#D62728" if label=="high" else "#1F77B4"

    html = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>CHO {lbl} Producer Flux -- {ds}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/5.16.0/d3.min.js"></script>
<script src="https://unpkg.com/escher@1.7.3/dist/escher.min.js"></script>
<style>
  body{{margin:0;font-family:Arial,sans-serif;}}
  #hdr{{padding:10px 18px;background:#2C3E50;color:#fff;}}
  #hdr h2{{margin:0;font-size:14px;}}
  #hdr p{{margin:3px 0 0;font-size:11px;opacity:.8;}}
  #app{{width:100vw;height:calc(100vh - 58px);}}
  #tip{{position:fixed;bottom:14px;right:14px;background:rgba(0,0,0,.75);
        color:#fff;padding:10px 14px;border-radius:8px;font-size:11px;line-height:1.6;max-width:260px;}}
</style>
</head>
<body>
<div id="hdr">
  <h2>CHO {lbl} Producer Flux Map &mdash; {ds}</h2>
  <p>Obj: {obj} | nonzero: {nz} rxns | Ref: King et al. 2015</p>
</div>
<div id="app"></div>
<div id="tip">
  <b>추천 사용 방법:</b><br>
  1. Load Map &rarr;<br>
  &nbsp;&nbsp;<b>Homo_sapiens.Core_metabolism</b><br>
  2. 또는 Load Model &rarr;<br>
  &nbsp;&nbsp;<b>iCHO3K_model_for_escher.json</b><br>
  &nbsp;&nbsp;(tables 폴더에 있음)<br>
  3. 반응 클릭 &rarr; flux 확인<br>
  <br>
  <span style="color:{col}">&#9632;</span> High flux
  <span style="color:#eee">&#9632;</span> flux=0
</div>
<script>
escher.Builder(null,null,null,d3.select('#app'),{{
  menu:'all',fill_screen:true,enable_editing:false,
  reaction_data:{rxn_data},
  reaction_scale:[
    {{type:'min',color:'#eeeeee',size:2}},
    {{type:'value',value:0,color:'#cccccc',size:2}},
    {{type:'max',color:'{col}',size:18}}
  ],
  reaction_no_data_color:'#eeeeee',
  reaction_no_data_size:2,
  identifiers_on_map:'bigg_id'
}});
</script>
</body>
</html>""".format(
        lbl=label.upper(), ds=DATASET, obj=OBJ,
        nz=len(nz_bigg), col=color,
        rxn_data=json.dumps(nz_bigg)
    )

    p = os.path.join(fig_dir, f"escher_flux_{label}.html")
    with open(p, "w", encoding="utf-8") as f: f.write(html)
    print(f"  [saved] escher_flux_{label}.html")

# 사용 가이드
guide = f"""
Escher Flux Map 사용 가이드 ({DATASET})
{'='*55}
생성 파일 위치: results/{DATASET}/

[figures/]
  escher_flux_high.html    <- 브라우저로 바로 열기
  escher_flux_low.html

[tables/]
  escher_flux_high_full.json      <- iCHO3K ID, 전체 반응
  escher_flux_high_nonzero.json   <- iCHO3K ID, flux>0만
  escher_flux_high_bigg.json      <- BiGG ID 변환본
  escher_flux_fold_change.json    <- High/Low 배율
  iCHO3K_model_for_escher.json    <- 모델 구조 (중요!)

[가장 많은 반응 보는 법]
  1. https://escher.github.io
  2. Load Map -> 아무거나
  3. Load Model -> iCHO3K_model_for_escher.json  <- 핵심
  4. Load Data -> Reaction data -> escher_flux_high_full.json
  -> iCHO3K 전체 반응에 flux 색상 표시

[비교 보는 법]
  Load Data -> escher_flux_fold_change.json
  -> 초록: High에서 높음, 빨강: Low에서 높음
"""
with open(os.path.join(out_dir,"escher_guide.txt"),"w",encoding="utf-8") as f:
    f.write(guide)
print(guide)
print("  OK  완료")
