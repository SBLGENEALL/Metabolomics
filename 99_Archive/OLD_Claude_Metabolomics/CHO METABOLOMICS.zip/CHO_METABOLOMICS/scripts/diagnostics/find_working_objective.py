"""
find_working_objective.py
이 모델에서 실제로 작동하는 objective를 찾아서 의미를 분석

python scripts/diagnostics/find_working_objective.py
"""
import sys, os, warnings
warnings.filterwarnings("ignore")

def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(6):
        if os.path.exists(os.path.join(cur, "src", "config.py")): return cur
        cur = os.path.dirname(cur)
    return cur
ROOT = _find_root()
if ROOT not in sys.path: sys.path.insert(0, ROOT)
from src.config import MODEL_PATH

import cobra

print("="*65)
print("  find_working_objective.py")
print("="*65)

model = cobra.io.load_json_model(MODEL_PATH)
all_ids = {r.id for r in model.reactions}
print(f"  모델: {os.path.basename(MODEL_PATH)}")
print(f"  반응: {len(model.reactions)}개")

# ── 1. 현재 default objective 확인 ─────────────────────
print(f"\n[1] 모델 default objective:")
try:
    default_obj = str(model.objective.expression)
    print(f"  {default_obj[:100]}")
    # objective reaction ID 추출
    obj_rxns = [r.id for r in model.reactions
                if abs(model.objective.get_linear_coefficients([r]).get(r,0)) > 0]
    print(f"  → Reaction IDs: {obj_rxns}")
except:
    print("  확인 불가")

# ── 2. biomass 관련 반응 전수 확인 ─────────────────────
print(f"\n[2] biomass 관련 반응 (constraint 없이):")
biomass_candidates = []
for r in model.reactions:
    s = f"{r.id} {r.name or ''}".lower()
    if "biomass" in s or "growth" in s:
        with model:
            model.objective = r.id
            sol = model.optimize()
            obj = sol.objective_value if sol.status=="optimal" else 0
        flag = "★" if obj > 1e-8 else "✘"
        print(f"  {flag} {r.id:40s} obj={obj:.5f}  [{r.name or ''}]")
        if obj > 1e-8:
            biomass_candidates.append((r.id, obj))

# ── 3. BiGGRxn 실제 내용 확인 ──────────────────────────
print(f"\n[3] 작동하는 BiGGRxn 반응 상세:")
target_rxns = ["BiGGRxn56","BiGGRxn81","BiGGRxn72","BiGGRxn71",
               "BiGGRxn05","GALT","BiGGEx08","BiGGEx09"]
for rxn_id in target_rxns:
    if rxn_id not in all_ids: continue
    r = model.reactions.get_by_id(rxn_id)
    # 반응식 출력
    rxn_str = r.reaction[:80]
    subsys   = getattr(r, 'subsystem', '') or ''
    with model:
        model.objective = rxn_id
        sol = model.optimize()
        obj = sol.objective_value if sol.status=="optimal" else 0
    print(f"\n  {rxn_id}  [{r.name or 'unnamed'}]")
    print(f"    subsystem: {subsys}")
    print(f"    reaction : {rxn_str}")
    print(f"    obj      : {obj:.5f}")

# ── 4. 실제 default objective로 FBA ───────────────────
print(f"\n[4] 모델 default objective로 FBA (수정 없이):")
with model:
    sol = model.optimize()
    print(f"  status: {sol.status}  obj: {sol.objective_value if sol.status=='optimal' else 0:.5f}")
    if sol.status == "optimal":
        # 주요 exchange flux
        print("  주요 exchange flux:")
        for r in model.exchanges:
            v = sol.fluxes.get(r.id, 0)
            if abs(v) > 0.001:
                print(f"    {r.id:30s} {v:8.4f}")

# ── 5. 권고 ────────────────────────────────────────────
print(f"\n{'='*65}")
print("  결론 및 권고:")
print("="*65)
if biomass_candidates:
    best = max(biomass_candidates, key=lambda x: x[1])
    print(f"  ★ 사용 가능한 biomass objective: {best[0]}  obj={best[1]:.5f}")
else:
    print("  !! biomass 관련 반응 중 obj>0인 것 없음")
    print("  → BiGGRxn56, GALT 등의 실제 의미 확인 필요")
    print("  → 위 [3] 섹션에서 reaction 내용 확인")

print(f"\n  결과를 붙여넣으시면 올바른 objective 설정해드립니다.")
