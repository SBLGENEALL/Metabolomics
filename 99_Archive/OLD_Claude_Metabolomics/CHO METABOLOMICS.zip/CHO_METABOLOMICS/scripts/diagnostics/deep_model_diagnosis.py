"""
deep_model_diagnosis.py
biomass=0 근본 원인 + 작동하는 objective 확정

python scripts/diagnostics/deep_model_diagnosis.py
"""
import sys, os, warnings
warnings.filterwarnings("ignore")

def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(6):
        if os.path.exists(os.path.join(cur, "src", "config.py")): return cur
        cur = os.path.dirname(cur)
    return cur
ROOT = _find_root()
if ROOT not in sys.path: sys.path.insert(0, ROOT)
from src.config import MODEL_PATH

import cobra, numpy as np

print("="*65)
print("  deep_model_diagnosis.py")
print("="*65)

model = cobra.io.load_json_model(MODEL_PATH)
all_ids = {r.id for r in model.reactions}

# ── 1. PROTsyn_prod 전체 반응식 확인 ──────────────────
print("\n[1] PROTsyn_prod 전체 반응식:")
ps = model.reactions.get_by_id("PROTsyn_prod")
print(f"  lb={ps.lower_bound}, ub={ps.upper_bound}")
print("  Reactants (aa_L_c 포함):")
for met, coef in sorted(ps.metabolites.items(), key=lambda x: x[1]):
    if coef < 0:
        print(f"    {coef:8.5f}  {met.id:30s}  [{met.name}]")

# ── 2. 아미노산 transport 경로 확인 ───────────────────
print("\n[2] 대표 아미노산(Ala) 의 transport 경로:")
ala_c_met = None
for m in model.metabolites:
    if m.id in ['ala_L_c','ala__L_c']:
        ala_c_met = m; break

if ala_c_met:
    print(f"  {ala_c_met.id} 관련 반응:")
    for r in ala_c_met.reactions:
        coef = r.metabolites[ala_c_met]
        print(f"    {'생산' if coef>0 else '소비'} {r.id:35s} lb={r.lower_bound:.1f} ub={r.upper_bound:.1f}")
        print(f"         {r.reaction[:60]}")

# ── 3. 점진적으로 exchange 열면서 biomass 테스트 ────────
print("\n[3] 단계별 exchange 열기 테스트:")

def test_biomass(m, label):
    with m:
        m.objective = "biomass_cho_prod"
        sol = m.optimize()
        obj = sol.objective_value if sol.status=="optimal" else 0
        print(f"  {label:50s} obj={obj:.5f}")
        return obj

# 기본
test_biomass(model, "기본 (아무것도 열지 않음)")

# Exchange만 열기
with model:
    n = 0
    for r in model.reactions:
        if r.id.startswith('EX_') and r.lower_bound == 0:
            r.lower_bound = -1000; n += 1
    test_biomass(model, f"Exchange 전부 열기 ({n}개)")

# Exchange + Transport 열기
with model:
    n = 0
    for r in model.reactions:
        if r.lower_bound == 0:
            # transport: 두 구획 사이 반응
            mets = list(r.metabolites.keys())
            compartments = {m.id.split('_')[-1] for m in mets}
            if len(compartments) > 1 or r.id.startswith('EX_'):
                r.lower_bound = -1000; n += 1
    test_biomass(model, f"Exchange+Transport 전부 열기 ({n}개)")

# 모든 반응 열기
with model:
    n = 0
    for r in model.reactions:
        if r.lower_bound == 0:
            r.lower_bound = -1000; n += 1
    test_biomass(model, f"모든 반응 열기 ({n}개)")

# ── 4. DM_igg_g 테스트 ────────────────────────────────
print("\n[4] DM_igg_g 테스트:")
if "DM_igg_g" in all_ids:
    r_igg = model.reactions.get_by_id("DM_igg_g")
    print(f"  반응식: {r_igg.reaction}")
    print(f"  lb={r_igg.lower_bound}, ub={r_igg.upper_bound}")

    for label, setup in [
        ("기본",          {}),
        ("Exchange 전부", "all_ex"),
        ("모든 반응",     "all"),
    ]:
        with model:
            if setup == "all_ex":
                for r in model.reactions:
                    if r.id.startswith('EX_') and r.lower_bound==0:
                        r.lower_bound = -1000
            elif setup == "all":
                for r in model.reactions:
                    if r.lower_bound == 0: r.lower_bound = -1000
            model.objective = "DM_igg_g"
            sol = model.optimize()
            obj = sol.objective_value if sol.status=="optimal" else 0
            print(f"  {label:20s}: {sol.status:10s}  obj={obj:.5f}")

# ── 5. biomass_cho (비생산) 테스트 ────────────────────
print("\n[5] biomass_cho (비생산 버전) 테스트:")
if "biomass_cho" in all_ids:
    bc = model.reactions.get_by_id("biomass_cho")
    print(f"  lb={bc.lower_bound}, ub={bc.upper_bound}")
    print("  반응물:")
    for met,coef in sorted(bc.metabolites.items(), key=lambda x:x[1]):
        if coef<0: print(f"    {coef:8.5f}  {met.id:30s}")

    for label, setup in [("기본", {}), ("Exchange 전부", "all_ex")]:
        with model:
            if setup == "all_ex":
                for r in model.reactions:
                    if r.id.startswith('EX_') and r.lower_bound==0:
                        r.lower_bound = -1000
            model.objective = "biomass_cho"
            sol = model.optimize()
            obj = sol.objective_value if sol.status=="optimal" else 0
            print(f"  {label:20s}: {sol.status:10s}  obj={obj:.5f}")

# ── 6. 최종 권고 ──────────────────────────────────────
print("\n" + "="*65)
print("  [결론]")
print("="*65)
print("""
  위 결과에서:
  - "모든 반응 열기" 에서 biomass>0 이면
    → 특정 반응이 막혀있는 것 (모델 설계 문제)
    → config.py에 open_all_reactions=True 설정 필요

  - DM_igg_g>0 이면
    → DM_igg_g를 objective로 사용 가능 (IgG 직접)

  - 모두 0이면
    → 이 모델 파일 자체가 손상됐거나 잘못된 버전
    → iCHO3K GitHub에서 재다운로드 필요
      https://github.com/LewisLabUCSD/iCHO3K

  결과를 공유해주시면 바로 수정하겠습니다.
""")
