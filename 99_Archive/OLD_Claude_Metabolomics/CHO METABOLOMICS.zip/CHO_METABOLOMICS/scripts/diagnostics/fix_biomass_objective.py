"""
fix_biomass_objective.py
biomass_cho_prod가 obj=0인 원인을 찾고 수정

python scripts/diagnostics/fix_biomass_objective.py
"""
import sys, os, warnings
warnings.filterwarnings("ignore")

def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(6):
        if os.path.exists(os.path.join(cur, "src", "config.py")): return cur
        cur = os.path.dirname(cur)
    return cur
ROOT = _find_root()
if ROOT not in sys.path: sys.path.insert(0, ROOT)
from src.config import MODEL_PATH, EXCHANGE_IDS, LITERATURE_HIGH

import cobra

print("="*65)
print("  fix_biomass_objective.py")
print("="*65)

model = cobra.io.load_json_model(MODEL_PATH)
all_ids = {r.id for r in model.reactions}

# ── 1. biomass_cho_prod 반응식 확인 ───────────────────
print("\n[1] biomass_cho_prod 반응식 (reactants):")
bm = model.reactions.get_by_id("biomass_cho_prod")
print(f"  lb={bm.lower_bound}, ub={bm.upper_bound}")
print("\n  반응물 (음수 계수):")
for met, coef in sorted(bm.metabolites.items(), key=lambda x: x[1]):
    if coef < 0:
        print(f"    {coef:8.4f}  {met.id:30s} [{met.name}]")

# ── 2. 생산물 확인 ────────────────────────────────────
print("\n  생산물 (양수 계수):")
for met, coef in sorted(bm.metabolites.items(), key=lambda x: x[1], reverse=True):
    if coef > 0:
        print(f"    {coef:8.4f}  {met.id:30s} [{met.name}]")

# ── 3. 각 반응물이 생산 가능한지 확인 ────────────────
print("\n[2] 각 반응물의 생산 가능성 (glucose 열고 테스트):")

# glucose 열기
def apply_glc(m):
    if "EX_glc_e" in {r.id for r in m.reactions}:
        r = m.reactions.get_by_id("EX_glc_e")
        r.lower_bound = -0.5; r.upper_bound = 0

with model:
    apply_glc(model)
    # Fouladiha constraints 적용
    for rid, (lb, ub) in LITERATURE_HIGH.items():
        if rid in all_ids:
            r = model.reactions.get_by_id(rid)
            if lb > r.upper_bound: r.upper_bound=ub; r.lower_bound=lb
            elif ub < r.lower_bound: r.lower_bound=lb; r.upper_bound=ub
            else: r.lower_bound=lb; r.upper_bound=ub

    model.objective = "biomass_cho_prod"
    sol = model.optimize()
    print(f"  Fouladiha constraints 적용 후: {sol.status}  obj={sol.objective_value if sol.status=='optimal' else 0:.5f}")

    # 각 반응물을 demand reaction으로 테스트
    blocked = []
    for met, coef in bm.metabolites.items():
        if coef < 0:
            # demand reaction 추가 (이 대사물질 소모 가능한지)
            with model:
                demand = cobra.Reaction(f"test_demand_{met.id}")
                demand.add_metabolites({met: -1})
                demand.lower_bound = 0; demand.upper_bound = 1000
                model.add_reactions([demand])
                model.objective = demand.id
                sol2 = model.optimize()
                obj2 = sol2.objective_value if sol2.status=="optimal" else 0
                if obj2 < 1e-8:
                    blocked.append(met.id)
                    print(f"  !! 차단: {met.id:30s} ({met.name})")
                # else:
                #     print(f"  OK  {met.id:30s} obj={obj2:.4f}")

if blocked:
    print(f"\n  → 차단된 반응물 {len(blocked)}개 발견")
    # prot_prod_c 추가 분석
    if any('prot_prod' in b for b in blocked):
        print("\n[2b] prot_prod_c 생산 경로 분석:")
        if 'prot_prod_c' in {m.id for m in model.metabolites}:
            prot = model.metabolites.get_by_id('prot_prod_c')
            print(f"  prot_prod_c 관련 반응:")
            for r in prot.reactions:
                coef = r.metabolites[prot]
                direction = "생산" if coef > 0 else "소비"
                print(f"    {direction} {r.id:35s} lb={r.lower_bound:.1f} ub={r.upper_bound:.1f}")
                print(f"    반응식: {r.reaction[:60]}")
else:
    print(f"\n  → 모든 반응물 생산 가능")
    print("  → biomass_cho_prod가 0인 다른 원인 있음")

# ── 4. IgG exchange 확인 ──────────────────────────────
print("\n[3] IgG/antibody exchange 반응:")
for r in model.reactions:
    s = f"{r.id} {r.name or ''}".lower()
    if any(k in s for k in ['igg','antibody','igG','mab']) and \
       (r.id.startswith('EX_') or r.id.startswith('DM_') or r.id.startswith('sink')):
        print(f"  {r.id:35s} lb={r.lower_bound:6.1f} ub={r.upper_bound:8.1f}  [{r.name or ''}]")

# ── 5. biomass의 IgG 관련 metabolite 확인 ─────────────
print("\n[4] biomass에서 IgG 관련 metabolite:")
for met, coef in bm.metabolites.items():
    if any(k in met.id.lower() for k in ['igg','antibody','hc','lc','chain','secreted']):
        print(f"  {coef:8.4f}  {met.id:35s} [{met.name}]")
        # 이 metabolite의 exchange 반응 있는지 확인
        ex_rxns = [r for r in met.reactions if r.id.startswith('EX_') or r.id.startswith('DM_')]
        for ex in ex_rxns:
            print(f"           → exchange: {ex.id}  lb={ex.lower_bound}  ub={ex.upper_bound}")

# ── 6. 최종 권고 ──────────────────────────────────────
print("\n" + "="*65)
print("  [최종 권고]")
print("="*65)

# glucose 열고 biomass 다시 테스트
with model:
    apply_glc(model)
    model.objective = "biomass_cho_prod"
    sol_glc = model.optimize()
    obj_glc = sol_glc.objective_value if sol_glc.status=="optimal" else 0

if obj_glc > 1e-8:
    print(f"  ★ glucose lb=-0.5 시 biomass_cho_prod = {obj_glc:.5f}")
    print("  → glucose exchange를 항상 열어줘야 함")
    print("  → 수정: apply_bounds 전에 EX_glc_e lb=-10 설정")
else:
    print(f"  biomass_cho_prod = {obj_glc:.5f} (glucose 열어도 0)")
    if blocked:
        print(f"  → 차단된 metabolite: {blocked[:3]}")
        print("  → 이 metabolite들의 exchange 열기 필요")
    else:
        print("  → biomass 반응 자체 문제 — biomass_cho 사용 권고")
        # biomass_cho 테스트
        with model:
            apply_glc(model)
            model.objective = "biomass_cho"
            sol_bc = model.optimize()
            obj_bc = sol_bc.objective_value if sol_bc.status=="optimal" else 0
        print(f"  biomass_cho     = {obj_bc:.5f}")
        with model:
            apply_glc(model)
            model.objective = "biomass_cho_s"
            sol_bs = model.optimize()
            obj_bs = sol_bs.objective_value if sol_bs.status=="optimal" else 0
        print(f"  biomass_cho_s   = {obj_bs:.5f}")
