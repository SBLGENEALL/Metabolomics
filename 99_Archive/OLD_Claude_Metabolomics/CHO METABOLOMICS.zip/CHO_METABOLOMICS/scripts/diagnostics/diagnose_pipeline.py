"""
diagnose_pipeline.py
현재 pkl 상태를 완전히 진단합니다.

python scripts/diagnostics/diagnose_pipeline.py --dataset practice_20aa
"""
import sys, os, argparse, warnings, pickle
warnings.filterwarnings("ignore")

def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(6):
        if os.path.exists(os.path.join(cur, "src", "config.py")): return cur
        cur = os.path.dirname(cur)
    return cur
ROOT = _find_root()
if ROOT not in sys.path: sys.path.insert(0, ROOT)
from src.config import *

import numpy as np, pandas as pd

parser = argparse.ArgumentParser()
parser.add_argument("--dataset", default="practice_20aa")
args = parser.parse_args()
DATASET = args.dataset

pkl = os.path.join(DATA_PROCESSED, f"rates_{DATASET}.pkl")
if not os.path.exists(pkl):
    print(f"!! pkl 없음: {pkl}")
    print("   python run_pipeline.py --steps 1 먼저 실행")
    sys.exit(1)

with open(pkl, "rb") as f:
    data = pickle.load(f)

print("="*65)
print(f"  진단: {DATASET}")
print("="*65)

# 1. all_rates 확인
print("\n[1] all_rates — Glc/Lac rate 값")
all_rates = data.get("all_rates", {})
if not all_rates:
    print("  !! all_rates 비어있음 → 01_load_data.py 재실행 필요")
else:
    print(f"  {'Clone':10s} {'Glc_q':>10s} {'Lac_q':>10s} {'Lac/Glc':>9s}")
    print("  " + "─"*43)
    for c in sorted(all_rates):
        r = all_rates[c]
        gq = r.get("Gluc", {}).get("rate_mmol_gDCWh", r.get("Glucose", {}).get("rate_mmol_gDCWh", 0))
        lq = r.get("Lac",  {}).get("rate_mmol_gDCWh", r.get("Lactate",  {}).get("rate_mmol_gDCWh", 0))
        ratio = lq/abs(gq) if abs(gq) > 1e-6 else None
        rs = f"{ratio:9.3f}" if ratio is not None else "     None"
        ok = "OK" if abs(gq) > 0.01 else "!! rate≈0"
        print(f"  {c:10s} {gq:10.4f} {lq:10.4f} {rs}  {ok}")

# 2. all_constraints 확인
print("\n[2] all_constraints — FBA에 실제 적용되는 값")
all_cst = data.get("all_constraints", {})
if not all_cst:
    print("  !! constraints 비어있음")
else:
    hc = data.get("high_clones", [])
    sample = hc[0] if hc else list(all_cst.keys())[0]
    cst = all_cst.get(sample, {})
    print(f"  {sample} constraints ({len(cst)}개):")
    for k, (lb, ub) in sorted(cst.items())[:8]:
        direction = "uptake" if ub == 0 else "secretion" if lb == 0 else "both"
        ok = "OK" if abs(lb) > 0.001 or abs(ub) > 0.001 else "!! ~0"
        print(f"    {k:30s} lb={lb:8.4f} ub={ub:8.4f}  {direction} {ok}")
    if not cst:
        print("  !! constraints 없음 → Glc rate가 0일 가능성")

# 3. fba_results 확인
print("\n[3] fba_results — Step 3 결과")
fba = data.get("fba_results", {})
if not fba:
    print("  !! fba_results 없음 → Step 3 재실행 필요")
else:
    for c in sorted(fba):
        r = fba[c]
        print(f"  {c:10s} {r.get('status','?'):10s} obj={r.get('obj',0):.5f}")

# 4. ko_df 확인
print("\n[4] ko_df — Step 5 KO 결과")
ko_df = data.get("ko_df", pd.DataFrame())
if len(ko_df) == 0:
    print("  !! ko_df 없음 → Step 5 재실행 필요")
else:
    for _, row in ko_df.iterrows():
        dp = row.get("delta_pct")
        st = row.get("status","?")
        if dp is None:
            print(f"  {row['target']:25s} status={st}")
        else:
            print(f"  {row['target']:25s} delta={dp:+6.1f}%  status={st}")

# 5. 결론
print("\n[결론]")
issues = []
if not all_rates or all(abs(r.get("Gluc",{}).get("rate_mmol_gDCWh",0)) < 0.01
                        for r in all_rates.values()):
    issues.append("CRITICAL: Glc rate≈0 → 01_load_data.py가 구버전")
if not all_cst or all(not cst for cst in all_cst.values()):
    issues.append("CRITICAL: constraints 비어있음 → Step 1,2 재실행")
if not fba or all(r.get("obj",0)==0 for r in fba.values()):
    issues.append("CRITICAL: FBA obj=0 → Step 3 재실행 필요")

if issues:
    for i in issues: print(f"  !! {i}")
    print("\n  해결:")
    print(f"  python run_pipeline.py --dataset {DATASET} --steps 1,2,0,3,4,5,6,10")
else:
    print("  데이터 정상 — Figure 스크립트 문제")
    print(f"  python run_pipeline.py --dataset {DATASET} --steps 6,10")
