"""
export_escher_flux.py
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Escher 호환 flux JSON 생성

핵심 수정사항 (2026-05)
  1. sol.fluxes 순회 버그 수정
     - 기존: for v in sol.fluxes 후 sol.fluxes[v] 접근 → pandas Series에서 KeyError 발생
     - 수정: sol.fluxes.to_dict() / sol.fluxes.values 사용
  2. strict constraint로 high/low 평균 FBA가 infeasible 또는 all-zero일 때
     Escher 시각화용 relaxed policy를 자동 재시도
  3. 결과가 비어 있어도 조용히 skip하지 않고 status report 저장
  4. Escher용 JSON + 실행 메타데이터를 항상 명확한 위치에 저장

사용 예:
  python scripts/steps/export_escher_flux.py --dataset practice_20aa
  python scripts/steps/export_escher_flux.py --dataset practice_20aa --policy strict
  python scripts/steps/export_escher_flux.py --dataset practice_20aa --policy visualization

저장 위치:
  results/{dataset}/tables/escher_flux_high_full.json              # BiGG/E. coli alias version
  results/{dataset}/tables/escher_flux_high_nonzero.json           # BiGG/E. coli alias version
  results/{dataset}/tables/escher_flux_high_cho_full.json          # iCHO3K original ID version
  results/{dataset}/tables/escher_flux_high_cho_nonzero.json       # iCHO3K original ID version
  results/{dataset}/tables/escher_flux_low_cho_nonzero.json
  results/{dataset}/tables/escher_flux_high_minus_low_cho.json
  results/{dataset}/tables/escher_flux_status.csv
"""
import sys, os, argparse, warnings, pickle, json
warnings.filterwarnings("ignore")


def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(6):
        if os.path.exists(os.path.join(cur, "src", "config.py")):
            return cur
        cur = os.path.dirname(cur)
    return cur


ROOT = _find_root()
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from src.config import *
from src.fba_utils import load_model, apply_bounds, avg_constraints
import pandas as pd
import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("--dataset", default="practice_20aa")
parser.add_argument(
    "--policy",
    default="auto",
    choices=["auto", "strict", "visualization", "none"],
    help=(
        "strict=측정 constraint 그대로 적용, "
        "visualization=Escher 표시용으로 uptake/secretion 방향을 완화, "
        "none=constraint 없이 모델만, auto=strict 실패 또는 all-zero 시 visualization 재시도"
    ),
)
parser.add_argument("--objective", default=None, help="강제로 사용할 objective reaction id")
parser.add_argument("--tol", type=float, default=1e-9)
args = parser.parse_args()
DATASET = args.dataset
TOL = args.tol

print("=" * 65)
print(f"  export_escher_flux.py — {DATASET}")
print("=" * 65)

# ── 로딩 ──────────────────────────────────────────────
pkl_path = os.path.join(DATA_PROCESSED, f"rates_{DATASET}.pkl")
if not os.path.exists(pkl_path):
    raise FileNotFoundError(
        f"{pkl_path} 없음 — 먼저 01_load_data.py 및 02_map_metabolites.py를 실행하세요."
    )

with open(pkl_path, "rb") as f:
    data = pickle.load(f)

all_constraints = data.get("all_constraints", {})
high_clones = data.get("high_clones", [])
low_clones = data.get("low_clones", [])
OBJ = args.objective or data.get("selected_objective", OBJ_RXN)

if not all_constraints:
    raise ValueError("all_constraints가 비어 있습니다 — 02_map_metabolites.py를 먼저 실행하세요.")
if not high_clones or not low_clones:
    raise ValueError("high_clones/low_clones 정보가 없습니다 — 01_load_data.py를 먼저 실행하세요.")

model = load_model(verbose=True)
all_rxn_ids = {r.id for r in model.reactions}
if OBJ not in all_rxn_ids:
    raise ValueError(f"Objective reaction이 모델에 없습니다: {OBJ}")

out_dir = results_dir(DATASET, "tables")

# ── BiGG ID 매핑 ──────────────────────────────────────
# iCHO3K는 일부 reaction id가 Escher/BiGG map과 다를 수 있음.
ICHOK_TO_BIGG = {
    # Glycolysis
    "HEX1": "HEX1", "PGI": "PGI", "PFK": "PFK", "FBA": "FBA", "TPI": "TPI",
    "GAPD": "GAPD", "PGK": "PGK", "PGM": "PGM", "ENO": "ENO", "PYK": "PYK",
    # LDH / transport
    "LDH_L": "LDH_L", "L_LACt2": "L_LACt2",
    # TCA, mitochondrial ids in iCHO3K → common BiGG ids
    "PDHm": "PDHm", "CSm": "CS", "ACONTm": "ACONT", "ICDHyrm": "ICDHyr",
    "AKGDm": "AKGD", "SUCOASm": "SUCOAS", "SUCD1m": "SUCD1", "FUMm": "FUM", "MDHm": "MDH",
    # PPP
    "G6PDH2r": "G6PDH2r", "PGL": "PGL", "GND": "GND", "RPE": "RPE", "RPI": "RPI",
    "TKT1": "TKT1", "TKT2": "TKT2",
    # Gln/Glu
    "GLNt1": "GLNt1", "GLNS": "GLNS", "GLUL": "GLUL", "GLUDym": "GLUDy", "ASPTA": "ASPTA",
    # Exchange
    "EX_glc_e": "EX_glc__D_e", "EX_lac_L_e": "EX_lac__L_e", "EX_gln_L_e": "EX_gln__L_e",
    "EX_glu_L_e": "EX_glu__L_e", "EX_nh4_e": "EX_nh4_e",
}


def to_bigg(rxn_id: str) -> str:
    return ICHOK_TO_BIGG.get(rxn_id, rxn_id)


def apply_visualization_bounds(model, constraints: dict) -> int:
    """
    Escher 시각화용 relaxed bound.

    strict mode는 측정값을 그대로 lb/ub로 넣기 때문에, feed correction 오차나
    미측정 배지 성분 때문에 모델이 infeasible 또는 all-zero가 될 수 있다.

    visualization mode는 측정값을 '방향 강제'가 아니라 'flux capacity 힌트'로 사용한다.
      - 관측 uptake(q<0): lower bound는 관측 uptake 크기까지 허용, secretion은 막지 않음
      - 관측 secretion(q>0): upper bound는 관측 secretion 크기까지 허용, uptake는 막지 않음

    이 모드는 정량 FBA 결론용이 아니라 Escher flux map을 그리기 위한 fallback이다.
    """
    n = 0
    rxn_ids = {r.id for r in model.reactions}
    for key, (lb, ub) in constraints.items():
        rxn_id = EXCHANGE_IDS.get(key, key)
        if rxn_id not in rxn_ids:
            continue
        rxn = model.reactions.get_by_id(rxn_id)
        lb_f, ub_f = float(lb), float(ub)
        lo, hi = min(lb_f, ub_f), max(lb_f, ub_f)

        if hi <= 0:          # observed uptake only
            rxn.lower_bound = lo
            rxn.upper_bound = max(rxn.upper_bound, 1000.0)
        elif lo >= 0:        # observed secretion only
            rxn.lower_bound = min(rxn.lower_bound, -1000.0)
            rxn.upper_bound = hi
        else:                # already crosses zero
            rxn.lower_bound = lo
            rxn.upper_bound = hi
        n += 1
    return n


def optimize_group(label: str, clone_list: list, policy: str) -> dict:
    constraints = avg_constraints(clone_list, all_constraints)
    with model:
        if policy == "strict":
            n = apply_bounds(model, constraints)
        elif policy == "visualization":
            n = apply_visualization_bounds(model, constraints)
        elif policy == "none":
            n = 0
        else:
            raise ValueError(f"unknown policy: {policy}")

        model.objective = OBJ
        sol = model.optimize()

        if sol.status == "optimal":
            fluxes = sol.fluxes.to_dict()
            obj = float(sol.objective_value) if sol.objective_value is not None else 0.0
            nonzero = int(np.sum(np.abs(sol.fluxes.values) > TOL))
        else:
            fluxes = {}
            obj = 0.0
            nonzero = 0

    return {
        "label": label,
        "policy": policy,
        "status": sol.status,
        "objective": OBJ,
        "objective_value": obj,
        "nonzero_fluxes": nonzero,
        "n_constraints": n,
        "n_clones": len(clone_list),
        "clones": ",".join(clone_list),
        "fluxes": fluxes,
    }


def run_policy(policy: str) -> dict:
    return {
        "high": optimize_group("high", high_clones, policy),
        "low": optimize_group("low", low_clones, policy),
    }


def acceptable(res: dict) -> bool:
    # Escher용으로는 high/low 모두 optimal이고, 적어도 하나 이상 nonzero flux가 있어야 의미가 있음.
    return all(v["status"] == "optimal" and v["nonzero_fluxes"] > 0 for v in res.values())


# ── FBA 실행 ──────────────────────────────────────────
print(f"\n  [FBA — Escher용 전체 reaction flux 계산]")
print(f"  Objective : {OBJ}")
print(f"  Policy    : {args.policy}")

tried = []
if args.policy == "auto":
    for p in ["strict", "visualization", "none"]:
        res = run_policy(p)
        tried.append(res)
        for label, r in res.items():
            print(
                f"  {label:6s} / {p:13s}: {r['status']:10s} "
                f"obj={r['objective_value']:.6g}  nonzero={r['nonzero_fluxes']}  n_cst={r['n_constraints']}"
            )
        if acceptable(res):
            results = res
            chosen_policy = p
            break
    else:
        # 모두 실패하면 마지막 결과를 저장하고 status report에 남김
        results = tried[-1]
        chosen_policy = "none"
else:
    results = run_policy(args.policy)
    chosen_policy = args.policy
    for label, r in results.items():
        print(
            f"  {label:6s} / {chosen_policy:13s}: {r['status']:10s} "
            f"obj={r['objective_value']:.6g}  nonzero={r['nonzero_fluxes']}  n_cst={r['n_constraints']}"
        )

if args.policy == "auto" and chosen_policy != "strict":
    print(
        f"\n  ⚠ strict constraint로는 Escher에 쓸 nonzero flux가 부족해서 "
        f"'{chosen_policy}' policy 결과를 저장합니다."
    )

# ── JSON 생성 및 저장 ─────────────────────────────────
def make_escher_dict(flux_dict: dict) -> dict:
    """BiGG/E. coli alias version for built-in Escher maps."""
    escher_data = {}
    for rxn_id, v in flux_dict.items():
        bigg_id = to_bigg(rxn_id)
        # mapping으로 id가 합쳐지는 경우 flux를 합산
        escher_data[bigg_id] = escher_data.get(bigg_id, 0.0) + float(v)
    return {k: round(float(v), 6) for k, v in escher_data.items()}


def make_cho_dict(flux_dict: dict) -> dict:
    """iCHO3K original reaction ID version for custom CHO Escher maps."""
    return {str(k): round(float(v), 6) for k, v in flux_dict.items()}


def save_flux_pair(label: str, data: dict, suffix: str = "") -> list:
    """Save full and nonzero JSON. suffix='' keeps old filenames; suffix='_cho' makes CHO-ID files."""
    saved = []
    full_path = os.path.join(out_dir, f"escher_flux_{label}{suffix}_full.json")
    with open(full_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    saved.append(full_path)
    print(f"  [saved] results/{DATASET}/tables/escher_flux_{label}{suffix}_full.json  ({len(data)} reactions)")

    nz_data = {k: v for k, v in data.items() if abs(v) > TOL}
    nz_path = os.path.join(out_dir, f"escher_flux_{label}{suffix}_nonzero.json")
    with open(nz_path, "w", encoding="utf-8") as f:
        json.dump(nz_data, f, indent=2, ensure_ascii=False)
    saved.append(nz_path)
    print(f"  [saved] results/{DATASET}/tables/escher_flux_{label}{suffix}_nonzero.json  ({len(nz_data)} reactions)")
    return saved


saved_jsons = []
for label, r in results.items():
    flux_dict = r.get("fluxes", {})

    # 1) 기존 호환성: E. coli/BiGG alias 파일
    saved_jsons.extend(save_flux_pair(label, make_escher_dict(flux_dict), suffix=""))

    # 2) CHO custom map용: iCHO3K 원래 reaction ID 파일
    saved_jsons.extend(save_flux_pair(label, make_cho_dict(flux_dict), suffix="_cho"))

# High/Low difference
def save_delta(high_flux: dict, low_flux: dict, filename: str):
    all_ids = sorted(set(high_flux) | set(low_flux))
    delta_data = {}
    for rid in all_ids:
        fh = high_flux.get(rid, 0.0)
        fl = low_flux.get(rid, 0.0)
        if abs(fh) <= TOL and abs(fl) <= TOL:
            continue
        # signed flux라 단순 fold-change가 불안정할 수 있어 high-low delta를 저장한다.
        delta_data[rid] = round(float(fh - fl), 6)
    path = os.path.join(out_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(delta_data, f, indent=2, ensure_ascii=False)
    saved_jsons.append(path)
    print(f"  [saved] results/{DATASET}/tables/{filename}  ({len(delta_data)} reactions)")


if results.get("high", {}).get("fluxes") and results.get("low", {}).get("fluxes"):
    # 기존 호환성: E. coli/BiGG alias 버전
    save_delta(
        make_escher_dict(results["high"]["fluxes"]),
        make_escher_dict(results["low"]["fluxes"]),
        "escher_flux_high_minus_low.json",
    )
    # CHO custom map용: iCHO3K 원래 reaction ID 버전
    save_delta(
        make_cho_dict(results["high"]["fluxes"]),
        make_cho_dict(results["low"]["fluxes"]),
        "escher_flux_high_minus_low_cho.json",
    )

# status report
status_rows = []
for label, r in results.items():
    row = {k: v for k, v in r.items() if k != "fluxes"}
    row["chosen_policy"] = chosen_policy
    status_rows.append(row)
status_df = pd.DataFrame(status_rows)
status_path = os.path.join(out_dir, "escher_flux_status.csv")
status_df.to_csv(status_path, index=False)
print(f"  [saved] results/{DATASET}/tables/escher_flux_status.csv")

# guide
files_text = "\n".join(f"  - {os.path.basename(p)}" for p in saved_jsons)
guide = f"""
Escher Flux Map 사용 방법
══════════════════════════════════════════════════════

생성 정보
  Dataset          : {DATASET}
  Objective        : {OBJ}
  Saved policy     : {chosen_policy}
  High clones      : {', '.join(high_clones)}
  Low clones       : {', '.join(low_clones)}

생성된 JSON
{files_text}

권장 업로드 파일
  A) Escher 기본 E. coli/BiGG map에 올릴 때:
     - escher_flux_high_nonzero.json
     - escher_flux_low_nonzero.json
     - escher_flux_high_minus_low.json

  B) scripts/steps/11_auto_escher_map.py로 만든 CHO/iCHO3K custom map에 올릴 때:
     - escher_flux_high_cho_nonzero.json
     - escher_flux_low_cho_nonzero.json
     - escher_flux_high_minus_low_cho.json

Escher에서 여는 법
  1. https://escher.github.io 접속
  2. Load Map 선택
  3. Load Data → Reaction data 선택
  4. 위 JSON 파일 업로드

주의
  - iCHO3K는 CHO genome-scale model이고, Escher 기본 map은 주로 BiGG/E. coli/Human map 기반이라
    reaction id가 완전히 일치하지 않을 수 있습니다.
  - policy가 visualization이면 정량 FBA 결론용이 아니라 flux map 표시용 fallback입니다.
    정량 비교에는 fba_results.csv, fva_comparison.csv와 함께 해석하세요.
"""

guide_path = os.path.join(out_dir, "escher_guide.txt")
with open(guide_path, "w", encoding="utf-8") as f:
    f.write(guide)
print(f"  [saved] results/{DATASET}/tables/escher_guide.txt")

print("\n  완료: Escher JSON export")
