"""
11_auto_escher_map.py
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Generate an Escher-compatible draft CHO central metabolism map from iCHO3K.

What this does
  - Reads the COBRA JSON model directly; cobra/escher Python packages are NOT required.
  - Builds a CHO/iCHO3K reaction-ID map for central carbon + glutamine metabolism.
  - Saves a map JSON that can be loaded in https://escher.github.io as a custom map.

Why this is useful
  Escher's built-in E. coli maps do not share IDs with CHO/iCHO3K. This map uses
  iCHO3K reaction IDs directly, so files such as escher_flux_high_nonzero.json
  should match much better.

Usage
  python scripts/steps/11_auto_escher_map.py --dataset practice_20aa

Outputs
  results/{dataset}/escher_maps/iCHO3K_CHO_central_metabolism_auto_map.json
  results/{dataset}/escher_maps/iCHO3K_CHO_central_metabolism_auto_map_guide.txt

Notes
  - This is an automated draft map, not a publication-quality hand-curated map.
  - You can load it in Escher and then polish positions/labels manually if desired.
"""
import argparse
import json
import os
import sys
from typing import Dict, Tuple, List, Optional


def _find_root():
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(7):
        if os.path.exists(os.path.join(cur, "src", "config.py")):
            return cur
        cur = os.path.dirname(cur)
    return cur


ROOT = _find_root()
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from src.config import MODEL_PATH, results_dir


parser = argparse.ArgumentParser()
parser.add_argument("--dataset", default="practice_20aa")
parser.add_argument("--model", default=None, help="Optional COBRA JSON model path")
parser.add_argument("--map-name", default="iCHO3K_CHO_central_metabolism_auto_map")
args = parser.parse_args()

DATASET = args.dataset
MODEL_JSON = args.model or MODEL_PATH
if not MODEL_JSON or not os.path.exists(MODEL_JSON):
    raise FileNotFoundError(f"Model JSON not found: {MODEL_JSON}")

with open(MODEL_JSON, "r", encoding="utf-8") as f:
    model = json.load(f)

rxns: Dict[str, dict] = {r["id"]: r for r in model.get("reactions", [])}
mets: Dict[str, dict] = {m["id"]: m for m in model.get("metabolites", [])}

# ---------------------------------------------------------------------
# Pathway template
# ---------------------------------------------------------------------
# Each entry: (reaction_id, start_metabolite, end_metabolite)
# Coordinates are assigned from MET_COORDS below. Reaction IDs are iCHO3K IDs.
PATHWAY_REACTIONS: List[Tuple[str, str, str]] = [
    # Glucose uptake and glycolysis
    ("EX_glc_e", "glc_D_boundary", "glc_D_e"),
    ("GLCt1r", "glc_D_e", "glc_D_c"),
    ("HEX1", "glc_D_c", "g6p_c"),
    ("PGI", "g6p_c", "f6p_c"),
    ("PFK", "f6p_c", "fdp_c"),
    ("FBA", "fdp_c", "g3p_c"),
    ("TPI", "dhap_c", "g3p_c"),
    ("GAPD", "g3p_c", "13dpg_c"),
    ("PGK", "13dpg_c", "3pg_c"),
    ("PGM", "3pg_c", "2pg_c"),
    ("ENO", "2pg_c", "pep_c"),
    ("PYK", "pep_c", "pyr_c"),
    ("LDH_L", "pyr_c", "lac_L_c"),
    ("L_LACt2r", "lac_L_c", "lac_L_e"),
    ("EX_lac_L_e", "lac_L_e", "lac_L_boundary"),
    # Pyruvate to mitochondria / anaplerosis
    ("PYRt2m", "pyr_c", "pyr_m"),
    ("PCm", "pyr_m", "oaa_m"),
    # TCA cycle, mitochondrial
    ("CSm", "oaa_m", "cit_m"),
    ("ACONTam", "cit_m", "acon_C_m"),
    ("ACONTbm", "acon_C_m", "icit_m"),
    ("ICDHyrm", "icit_m", "akg_m"),
    ("AKGDm", "akg_m", "succoa_m"),
    ("SUCOASm", "succoa_m", "succ_m"),
    ("SUCD1m", "succ_m", "fum_m"),
    ("FUMm", "fum_m", "mal_L_m"),
    ("MDHm", "mal_L_m", "oaa_m"),
    # Oxidative PPP and non-oxidative PPP
    ("G6PDH2r", "g6p_c", "6pgl_c"),
    ("PGL", "6pgl_c", "6pgc_c"),
    ("GND", "6pgc_c", "ru5p_D_c"),
    ("RPI", "ru5p_D_c", "r5p_c"),
    ("RPE", "ru5p_D_c", "xu5p_D_c"),
    ("TKT1", "r5p_c", "sdhpt7p_c"),
    ("TALA", "sdhpt7p_c", "f6p_c"),
    ("TKT2", "xu5p_D_c", "g3p_c"),
    # Glutamine / glutamate / ammonia
    ("EX_gln_L_e", "gln_L_boundary", "gln_L_e"),
    ("GLNt4rev", "gln_L_e", "gln_L_c"),
    ("GLNtm", "gln_L_c", "gln_L_m"),
    ("GLUNm", "gln_L_m", "glu_L_m"),
    ("GLUDym", "glu_L_m", "akg_m"),
    ("GLUDxm", "glu_L_m", "akg_m"),
    ("EX_glu_L_e", "glu_L_boundary", "glu_L_e"),
    ("GLUt6", "glu_L_e", "glu_L_c"),
    ("NH4t3r", "nh4_c", "nh4_e"),
    ("EX_nh4_e", "nh4_e", "nh4_boundary"),
]

# Fixed schematic coordinates. These are deliberately simple and editable.
MET_COORDS: Dict[str, Tuple[float, float]] = {
    # Glycolysis vertical lane
    "glc_D_boundary": (260, 80),
    "glc_D_e": (260, 160),
    "glc_D_c": (260, 250),
    "g6p_c": (260, 340),
    "f6p_c": (260, 460),
    "fdp_c": (260, 580),
    "dhap_c": (90, 690),
    "g3p_c": (260, 700),
    "13dpg_c": (260, 820),
    "3pg_c": (260, 940),
    "2pg_c": (260, 1060),
    "pep_c": (260, 1180),
    "pyr_c": (260, 1300),
    "lac_L_c": (80, 1380),
    "lac_L_e": (80, 1480),
    "lac_L_boundary": (80, 1580),
    # Mitochondrial pyruvate/TCA
    "pyr_m": (520, 1320),
    "oaa_m": (820, 1250),
    "cit_m": (1020, 1030),
    "acon_C_m": (1180, 1120),
    "icit_m": (1260, 1320),
    "akg_m": (1080, 1520),
    "succoa_m": (820, 1600),
    "succ_m": (620, 1500),
    "fum_m": (560, 1280),
    "mal_L_m": (650, 1120),
    # PPP to the right of upper glycolysis
    "6pgl_c": (560, 340),
    "6pgc_c": (760, 340),
    "ru5p_D_c": (960, 340),
    "r5p_c": (1120, 260),
    "xu5p_D_c": (1120, 450),
    "sdhpt7p_c": (760, 560),
    "e4p_c": (960, 590),
    # Gln/Glu left and lower-left
    "gln_L_boundary": (-240, 160),
    "gln_L_e": (-240, 260),
    "gln_L_c": (-240, 380),
    "gln_L_m": (500, 1540),
    "glu_L_m": (760, 1480),
    "glu_L_boundary": (-520, 520),
    "glu_L_e": (-520, 620),
    "glu_L_c": (-360, 700),
    "nh4_c": (-240, 900),
    "nh4_e": (-240, 1020),
    "nh4_boundary": (-240, 1140),
}

TEXT_LABELS = {
    "1": {"x": 210, "y": 20, "text": "Glucose uptake / Glycolysis"},
    "2": {"x": 760, "y": 940, "text": "TCA cycle (mitochondrial)"},
    "3": {"x": 650, "y": 250, "text": "Pentose phosphate pathway"},
    "4": {"x": -430, "y": 100, "text": "Glutamine / Glutamate / NH4"},
}

BOUNDARY_NAMES = {
    "glc_D_boundary": "glucose boundary",
    "lac_L_boundary": "lactate boundary",
    "gln_L_boundary": "glutamine boundary",
    "glu_L_boundary": "glutamate boundary",
    "nh4_boundary": "ammonia boundary",
}


class EscherDraftMap:
    def __init__(self):
        self.next_id = 1
        self.nodes: Dict[str, dict] = {}
        self.reactions: Dict[str, dict] = {}
        self.met_node_id: Dict[str, str] = {}
        self.skipped: List[str] = []

    def _id(self) -> str:
        out = str(self.next_id)
        self.next_id += 1
        return out

    def met_name(self, met_id: str) -> str:
        if met_id in BOUNDARY_NAMES:
            return BOUNDARY_NAMES[met_id]
        return mets.get(met_id, {}).get("name") or met_id

    def add_metabolite_node(self, met_id: str, x: float, y: float, primary=True) -> str:
        # One node per metabolite ID keeps shared metabolites connected across pathways.
        if met_id in self.met_node_id:
            return self.met_node_id[met_id]
        node_id = self._id()
        self.nodes[node_id] = {
            "node_type": "metabolite",
            "x": x,
            "y": y,
            "bigg_id": met_id,
            "name": self.met_name(met_id),
            "label_x": x + 18,
            "label_y": y - 28,
            "node_is_primary": bool(primary),
        }
        self.met_node_id[met_id] = node_id
        return node_id

    def add_marker(self, node_type: str, x: float, y: float) -> str:
        node_id = self._id()
        self.nodes[node_id] = {"node_type": node_type, "x": x, "y": y}
        return node_id

    def _segment(self, from_id: str, to_id: str) -> dict:
        return {"from_node_id": from_id, "to_node_id": to_id, "b1": None, "b2": None}

    def add_reaction(self, rxn_id: str, start_met: str, end_met: str):
        if rxn_id not in rxns:
            self.skipped.append(rxn_id)
            return
        if start_met not in MET_COORDS or end_met not in MET_COORDS:
            self.skipped.append(rxn_id + " (missing coordinates)")
            return

        rxn = rxns[rxn_id]
        x1, y1 = MET_COORDS[start_met]
        x2, y2 = MET_COORDS[end_met]
        sx = self.add_metabolite_node(start_met, x1, y1)
        tx = self.add_metabolite_node(end_met, x2, y2)

        # Markers on the reaction line. Escher uses midmarker/multimarker nodes
        # to orient reactions and arrows.
        m1 = self.add_marker("multimarker", x1 + 0.33 * (x2 - x1), y1 + 0.33 * (y2 - y1))
        mid = self.add_marker("midmarker", x1 + 0.50 * (x2 - x1), y1 + 0.50 * (y2 - y1))
        m2 = self.add_marker("multimarker", x1 + 0.67 * (x2 - x1), y1 + 0.67 * (y2 - y1))

        segments = {}
        for a, b in [(sx, m1), (m1, mid), (mid, m2), (m2, tx)]:
            segments[self._id()] = self._segment(a, b)

        rid = self._id()
        lower = float(rxn.get("lower_bound", 0.0))
        upper = float(rxn.get("upper_bound", 0.0))
        self.reactions[rid] = {
            "name": rxn.get("name") or rxn_id,
            "bigg_id": rxn_id,
            "reversibility": bool(lower < 0 and upper > 0),
            "label_x": (x1 + x2) / 2 + 12,
            "label_y": (y1 + y2) / 2 - 12,
            "gene_reaction_rule": rxn.get("gene_reaction_rule", ""),
            "metabolites": [
                {"bigg_id": met_id, "coefficient": float(coeff)}
                for met_id, coeff in rxn.get("metabolites", {}).items()
            ],
            "segments": segments,
        }

    def build(self) -> list:
        for rxn_id, start, end in PATHWAY_REACTIONS:
            self.add_reaction(rxn_id, start, end)

        map_info = {
            "map_name": args.map_name,
            "map_id": args.map_name,
            "map_description": (
                "Automated draft CHO central carbon / glutamine metabolism map "
                "generated from iCHO3K reaction IDs."
            ),
            "homepage": "https://escher.github.io/",
            "schema": "https://escher.github.io/escher/jsonschema/1-0-0#",
        }
        map_body = {
            "reactions": self.reactions,
            "nodes": self.nodes,
            "text_labels": TEXT_LABELS,
            "canvas": {"x": -650, "y": -50, "width": 2050, "height": 1750},
        }
        return [map_info, map_body]


def main():
    out_dir = results_dir(DATASET, "escher_maps")
    draft = EscherDraftMap()
    map_json = draft.build()
    out_path = os.path.join(out_dir, f"{args.map_name}.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(map_json, f, indent=2, ensure_ascii=False)

    guide_path = os.path.join(out_dir, f"{args.map_name}_guide.txt")
    with open(guide_path, "w", encoding="utf-8") as f:
        f.write(f"""CHO/iCHO3K Escher Auto Map Guide
══════════════════════════════════════════════════════

Map JSON
  {out_path}

How to use in Escher
  1. Open https://escher.github.io
  2. Load Map → Browse → select {os.path.basename(out_path)}
  3. Load Data → Reaction data → select one of:
       results/{DATASET}/tables/escher_flux_high_nonzero.json
       results/{DATASET}/tables/escher_flux_low_nonzero.json
       results/{DATASET}/tables/escher_flux_high_minus_low.json

Why this should work better than E. coli core map
  - This map uses iCHO3K reaction IDs directly: HEX1, GLCt1r, CSm, ACONTam, GLUDym, etc.
  - E. coli core maps use different IDs and bacterial-specific reactions, so many CHO fluxes appear as no data.

Scope
  - Automated draft map covering glucose uptake, glycolysis, PPP, lactate, pyruvate/TCA, glutamine/glutamate/NH4.
  - Not a hand-curated publication-quality layout; use it as a starting template.

Included reactions
""")
        for rxn_id, start, end in PATHWAY_REACTIONS:
            status = "OK" if rxn_id in rxns else "MISSING"
            f.write(f"  {status:7s} {rxn_id:12s} {start} -> {end}\n")
        if draft.skipped:
            f.write("\nSkipped\n")
            for s in draft.skipped:
                f.write(f"  - {s}\n")

    print("=" * 65)
    print("  11_auto_escher_map.py")
    print("=" * 65)
    print(f"  Model      : {MODEL_JSON}")
    print(f"  Reactions  : {len(draft.reactions)} drawn")
    print(f"  Nodes      : {len(draft.nodes)}")
    if draft.skipped:
        print(f"  Skipped    : {len(draft.skipped)} -> {', '.join(draft.skipped)}")
    print(f"  [saved] {out_path}")
    print(f"  [saved] {guide_path}")


if __name__ == "__main__":
    main()
