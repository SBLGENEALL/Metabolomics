#!/usr/bin/env python3
"""
Annotate CHO/iCHO3K Escher flux JSONs onto prettier official Escher RECON1 maps.

What this does
--------------
1) Downloads official Escher Homo sapiens / RECON1 map JSON files from
   escher/escher.github.io, if internet is available.
2) Converts CHO/iCHO3K reaction IDs to RECON1/BiGG-style IDs that the maps use.
3) Writes Escher reaction-data JSON files and coverage/mapping reports.

Run from the CHO_METABOLOMICS project root:
    python scripts/steps/12_annotate_flux_to_recon1_maps.py --dataset practice_20aa
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Dict, Iterable, List, Tuple, Any

REPO_RAW_ROOT = "https://raw.githubusercontent.com/escher/escher.github.io/master/1-0-0/6/maps/Homo%20sapiens"

OFFICIAL_RECON1_MAPS = {
    "glycolysis_tca_ppp": "RECON1.Glycolysis TCA PPP",
    "carbohydrate": "RECON1.Carbohydrate metabolism",
    "amino_acid_partial": "RECON1.Amino acid metabolism (partial)",
}

# Core aliases from iCHO3K/CHO IDs to the IDs used in RECON1 Escher maps.
# For split reactions, the script can sum multiple source IDs into one target ID.
ALIAS_GROUPS: Dict[str, List[str]] = {
    # Exchange IDs: iCHO3K uses single underscore for L/D amino acids in several EX IDs;
    # BiGG/Escher maps commonly use double underscores.
    "EX_glc__D_e": ["EX_glc_e", "EX_glc__D_e"],
    "EX_lac__L_e": ["EX_lac_L_e", "EX_lac__L_e"],
    "EX_gln__L_e": ["EX_gln_L_e", "EX_gln__L_e"],
    "EX_glu__L_e": ["EX_glu_L_e", "EX_glu__L_e"],
    "EX_ala__L_e": ["EX_ala_L_e", "EX_ala__L_e"],
    "EX_arg__L_e": ["EX_arg_L_e", "EX_arg__L_e"],
    "EX_asn__L_e": ["EX_asn_L_e", "EX_asn__L_e"],
    "EX_asp__L_e": ["EX_asp_L_e", "EX_asp__L_e"],
    "EX_cys__L_e": ["EX_cys_L_e", "EX_cys__L_e"],
    "EX_his__L_e": ["EX_his_L_e", "EX_his__L_e"],
    "EX_ile__L_e": ["EX_ile_L_e", "EX_ile__L_e"],
    "EX_leu__L_e": ["EX_leu_L_e", "EX_leu__L_e"],
    "EX_lys__L_e": ["EX_lys_L_e", "EX_lys__L_e"],
    "EX_met__L_e": ["EX_met_L_e", "EX_met__L_e"],
    "EX_phe__L_e": ["EX_phe_L_e", "EX_phe__L_e"],
    "EX_pro__L_e": ["EX_pro_L_e", "EX_pro__L_e"],
    "EX_ser__L_e": ["EX_ser_L_e", "EX_ser__L_e"],
    "EX_thr__L_e": ["EX_thr_L_e", "EX_thr__L_e"],
    "EX_trp__L_e": ["EX_trp_L_e", "EX_trp__L_e"],
    "EX_tyr__L_e": ["EX_tyr_L_e", "EX_tyr__L_e"],
    "EX_val__L_e": ["EX_val_L_e", "EX_val__L_e"],

    # Glycolysis / lactate transport.
    "GLCt1r": ["GLCt1r"],
    "GLCter": ["GLCter"],
    "HEX1": ["HEX1"],
    "PGI": ["PGI"],
    "PFK": ["PFK"],
    "FBA": ["FBA"],
    "TPI": ["TPI"],
    "GAPD": ["GAPD"],
    "PGK": ["PGK"],
    "PGM": ["PGM"],
    "ENO": ["ENO"],
    "PYK": ["PYK"],
    "LDH_L": ["LDH_L"],
    "L_LACt2r": ["L_LACt2r", "L_LACt2"],
    "L_LACtm": ["L_LACtm"],
    "PYRt2m": ["PYRt2m"],
    "PYRtm": ["PYRtm"],

    # TCA: iCHO3K has split aconitase mitochondrial steps; RECON1 map may use ACONTm.
    "CSm": ["CSm"],
    "ACONTm": ["ACONTam", "ACONTbm", "ACONTm"],
    "ACONTam": ["ACONTam"],
    "ACONTbm": ["ACONTbm"],
    "ICDHyrm": ["ICDHyrm"],
    "AKGDm": ["AKGDm"],
    "SUCOASm": ["SUCOASm", "SUCOAS1m"],
    "SUCOAS1m": ["SUCOAS1m", "SUCOASm"],
    "SUCD1m": ["SUCD1m"],
    "FUMm": ["FUMm"],
    "MDHm": ["MDHm"],
    "PCm": ["PCm"],
    "PEPCKm": ["PEPCKm"],

    # PPP.
    "G6PDH2r": ["G6PDH2r"],
    "PGL": ["PGL"],
    "GND": ["GND"],
    "RPE": ["RPE"],
    "RPI": ["RPI"],
    "TKT1": ["TKT1"],
    "TKT2": ["TKT2"],
    "TALA": ["TALA"],

    # Glutamine / glutamate / nitrogen.
    "GLNS": ["GLNS"],
    "GLNtm": ["GLNtm"],
    "GLNt4": ["GLNt4"],
    "GLNt4rev": ["GLNt4rev"],
    "GLUN": ["GLUN"],
    "GLUNm": ["GLUNm"],
    "GLUDxm": ["GLUDxm"],
    "GLUDym": ["GLUDym", "GLUDy"],
    "NH4t3r": ["NH4t3r"],
    "NH4tr": ["NH4tr"],
    "EX_nh4_e": ["EX_nh4_e"],
    "ASPTA": ["ASPTA"],
    "ASPTAm": ["ASPTAm"],
    "ALATA_L": ["ALATA_L"],
}


def project_root() -> Path:
    return Path.cwd().resolve()


def results_tables(root: Path, dataset: str) -> Path:
    return root / "results" / dataset / "tables"


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, obj: Any) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)


def safe_map_filename(map_name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", map_name).strip("_") + ".json"


def map_download_url(map_name: str) -> str:
    return f"{REPO_RAW_ROOT}/{urllib.parse.quote(map_name + '.json')}"


def download_map(map_name: str, out_path: Path, timeout: int = 30) -> Tuple[bool, str]:
    url = map_download_url(map_name)
    if out_path.exists() and out_path.stat().st_size > 1000:
        return True, "already_exists"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            data = resp.read()
        out_path.write_bytes(data)
        return True, "downloaded"
    except Exception as e:
        return False, f"download_failed: {type(e).__name__}: {e}"


def extract_map_reaction_ids(map_path: Path) -> List[str]:
    if not map_path.exists():
        return []
    try:
        data = read_json(map_path)
        canvas = data[1]
        rxns = canvas.get("reactions", {})
        ids = sorted({r.get("bigg_id") for r in rxns.values() if r.get("bigg_id")})
        return ids
    except Exception:
        return []


def choose_flux_file(tables: Path, label: str) -> Path:
    # Prefer CHO-original IDs, because we need to map to RECON1 correctly.
    candidates = [
        tables / f"escher_flux_{label}_cho_full.json",
        tables / f"escher_flux_{label}_full.json",
        tables / f"escher_flux_{label}_cho.json",
        tables / f"escher_flux_{label}.json",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError(f"No flux JSON found for label={label}; looked for {candidates}")


SUM_TARGETS = {"ACONTm"}

def sum_sources(flux: Dict[str, float], sources: Iterable[str], target: str | None = None) -> Tuple[float | None, List[str]]:
    present = [s for s in sources if s in flux]
    if not present:
        return None, []
    # Some iCHO3K reactions are split steps that should be summed for a one-reaction RECON1 map.
    if target in SUM_TARGETS:
        return round(sum(float(flux[s]) for s in present), 6), present
    # Otherwise, treat the sources as ID aliases/alternatives, not parallel fluxes to add.
    # Prefer exact target if available; otherwise use the source with the largest absolute flux.
    if target and target in present:
        return round(float(flux[target]), 6), [target]
    chosen = max(present, key=lambda s: abs(float(flux[s])))
    return round(float(flux[chosen]), 6), [chosen]


def convert_flux_to_recon1(flux: Dict[str, float], target_ids: Iterable[str] | None = None) -> Tuple[Dict[str, float], List[Dict[str, Any]]]:
    """Return RECON1-friendly reaction-data JSON and mapping rows."""
    out: Dict[str, float] = {}
    rows: List[Dict[str, Any]] = []

    # Keep exact IDs too. Escher will ignore reaction-data keys not present in the loaded map.
    for rid, val in flux.items():
        out[rid] = round(float(val), 6)
        rows.append({
            "target_reaction_id": rid,
            "source_reaction_ids": rid,
            "match_method": "exact_or_passthrough",
            "flux_value": out[rid],
        })

    for target, sources in ALIAS_GROUPS.items():
        val, present = sum_sources(flux, sources, target=target)
        if val is None:
            continue
        # If target already exists, prefer alias-combined value only when source differs or target missing.
        out[target] = val
        rows.append({
            "target_reaction_id": target,
            "source_reaction_ids": ";".join(present),
            "match_method": "manual_alias_sum" if len(present) > 1 or present[0] != target else "manual_alias_exact",
            "flux_value": val,
        })

    if target_ids:
        target_set = set(target_ids)
        for rid in sorted(target_set):
            if rid not in out:
                rows.append({
                    "target_reaction_id": rid,
                    "source_reaction_ids": "",
                    "match_method": "target_map_unmatched",
                    "flux_value": "",
                })

    return out, rows


def write_mapping_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    fieldnames = ["target_reaction_id", "source_reaction_ids", "match_method", "flux_value"]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="practice_20aa")
    parser.add_argument("--no-download", action="store_true", help="Do not download official Escher map JSON files")
    parser.add_argument("--labels", default="high,low,high_minus_low", help="Comma-separated labels to convert")
    args = parser.parse_args()

    root = project_root()
    tables = results_tables(root, args.dataset)
    if not tables.exists():
        raise FileNotFoundError(f"Tables folder not found: {tables}")

    map_dir = ensure_dir(root / "results" / args.dataset / "escher_maps" / "recon1_official")
    out_dir = ensure_dir(tables / "recon1_pretty_map")

    manifest_rows = []
    all_target_ids: Dict[str, List[str]] = {}
    for short, map_name in OFFICIAL_RECON1_MAPS.items():
        fname = safe_map_filename(map_name)
        out_path = map_dir / fname
        ok, status = (False, "download_skipped") if args.no_download else download_map(map_name, out_path)
        ids = extract_map_reaction_ids(out_path)
        all_target_ids[short] = ids
        manifest_rows.append({
            "short_name": short,
            "map_name": map_name,
            "download_url": map_download_url(map_name),
            "local_path": str(out_path.relative_to(root)),
            "status": status,
            "n_reactions_in_map": len(ids),
        })

    # Manifest
    with (map_dir / "recon1_map_download_manifest.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = ["short_name", "map_name", "download_url", "local_path", "status", "n_reactions_in_map"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(manifest_rows)

    labels = [x.strip() for x in args.labels.split(",") if x.strip()]
    summary = []
    for label in labels:
        flux_file = choose_flux_file(tables, label)
        flux = read_json(flux_file)
        # A broad file that works with any of the official RECON1 maps.
        recon_flux, recon_rows = convert_flux_to_recon1(flux, target_ids=None)
        out_json = out_dir / f"escher_flux_{label}_recon1_all_maps.json"
        write_json(out_json, recon_flux)
        write_mapping_csv(out_dir / f"mapping_{label}_recon1_all_maps.csv", recon_rows)

        # Map-specific trimmed files, if the actual map was downloaded and IDs were extracted.
        for short, ids in all_target_ids.items():
            if ids:
                trimmed = {rid: recon_flux[rid] for rid in ids if rid in recon_flux}
                write_json(out_dir / f"escher_flux_{label}_{short}.json", trimmed)
                coverage = len(trimmed) / len(ids) if ids else 0.0
                summary.append({
                    "label": label,
                    "map_short": short,
                    "input_flux_file": str(flux_file.relative_to(root)),
                    "output_json": str((out_dir / f"escher_flux_{label}_{short}.json").relative_to(root)),
                    "matched_reactions": len(trimmed),
                    "map_reactions": len(ids),
                    "coverage_pct": round(coverage * 100, 2),
                })
            else:
                summary.append({
                    "label": label,
                    "map_short": short,
                    "input_flux_file": str(flux_file.relative_to(root)),
                    "output_json": str(out_json.relative_to(root)),
                    "matched_reactions": "map_not_downloaded",
                    "map_reactions": "map_not_downloaded",
                    "coverage_pct": "map_not_downloaded",
                })

    with (out_dir / "recon1_pretty_map_summary.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fieldnames = ["label", "map_short", "input_flux_file", "output_json", "matched_reactions", "map_reactions", "coverage_pct"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summary)

    guide = f"""# RECON1 pretty Escher map annotation guide

This folder converts CHO/iCHO3K flux JSONs to reaction-data JSONs that work better with official Escher Homo sapiens / RECON1 maps.

Recommended map first:
- RECON1.Glycolysis TCA PPP

How to use in Escher:
1. Open https://escher.github.io
2. Load Map -> choose built-in Homo sapiens / RECON1.Glycolysis TCA PPP, or upload:
   results/{args.dataset}/escher_maps/recon1_official/RECON1.Glycolysis_TCA_PPP.json
3. Load Data -> Reaction data -> upload:
   results/{args.dataset}/tables/recon1_pretty_map/escher_flux_high_recon1_all_maps.json

If the script downloaded maps successfully, map-specific trimmed files were also written, for example:
- escher_flux_high_glycolysis_tca_ppp.json

Notes:
- The broad *_recon1_all_maps.json contains many reaction IDs. Escher safely ignores IDs not present in the selected map.
- For iCHO3K split reactions such as ACONTam/ACONTbm, the alias ACONTm is generated by summing available split-step fluxes.
- This is best for visualization. For strict quantitative interpretation, continue using fba_results.csv and fva_comparison.csv.
"""
    (out_dir / "README_RECON1_PRETTY_MAP.md").write_text(guide, encoding="utf-8")

    print(f"[saved] {map_dir / 'recon1_map_download_manifest.csv'}")
    print(f"[saved] {out_dir / 'recon1_pretty_map_summary.csv'}")
    print(f"[saved] {out_dir / 'README_RECON1_PRETTY_MAP.md'}")
    print("Done.")


if __name__ == "__main__":
    main()
