# -*- coding: utf-8 -*-
"""
CHOmpact Fig3-style group summary pipeline

Input:
  results/practice_20aa/chompact_fig3_style/central_flux_proxy_from_exchange_rates.csv

Outputs:
  group_summary_mean.csv
  group_summary_sem.csv
  clone_flux_ranked.csv
  interpretation_flags_by_group.csv
  escher_absolute_flux_input.csv
  escher_efficiency_burden_input.csv
  plain_language_summary.txt

Run:
  cd /home/MCET03/06_Metabolomics/CHO_METABOLOMICS_workstation
  python run_chompact_group_summary.py
"""

from pathlib import Path
import pandas as pd
import numpy as np

BASE = Path("/home/MCET03/06_Metabolomics/CHO_METABOLOMICS_workstation")

INPUT = BASE / "results/practice_20aa/chompact_fig3_style/central_flux_proxy_from_exchange_rates.csv"
OUTDIR = BASE / "results/practice_20aa/chompact_fig3_style/group_summary"
OUTDIR.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(INPUT)

print("Loaded:", INPUT)
print("Columns:", df.columns.tolist())

# ------------------------------------------------------------
# 1. Group assignment
# ------------------------------------------------------------
# If Group column exists, use it.
# If not, define manually here based on your clone names.
#
# Example:
# GROUP_MAP = {
#     "1": "Mother",
#     "2": "High",
#     "8": "High",
#     "9": "High",
#     "3": "Low",
#     "4": "Low",
# }

GROUP_MAP = {
    # EDIT HERE IF NEEDED
}

if "Group" not in df.columns or df["Group"].isna().all():
    if not GROUP_MAP:
        raise ValueError(
            "No Group column found and GROUP_MAP is empty. "
            "Please edit GROUP_MAP in this script to assign clone groups."
        )
    df["Group"] = df["Clone"].astype(str).map(GROUP_MAP)

if df["Group"].isna().any():
    print("\nWARNING: Some clones do not have Group assignment:")
    print(df.loc[df["Group"].isna(), ["Clone"]])
    df["Group"] = df["Group"].fillna("Unassigned")

GROUP_ORDER = ["High", "Mother", "Low", "Unassigned"]
existing_groups = [g for g in GROUP_ORDER if g in df["Group"].unique()]
other_groups = [g for g in df["Group"].unique() if g not in existing_groups]
GROUP_ORDER = existing_groups + other_groups

# ------------------------------------------------------------
# 2. Core metrics
# ------------------------------------------------------------
core_metrics = [
    "GLC_uptake",
    "Glycolysis_to_PYR_proxy",
    "Lactate_branch",
    "Alanine_branch",
    "PYR_to_TCA_proxy",
    "GLN_uptake",
    "GLU_secretion",
    "Glutaminolysis_to_TCA_proxy",
    "TCA_input_proxy",
    "TCA_fraction_proxy",
    "Redox_overflow_ratio",
    "Glucose_to_lactate_ratio",
    "AA_uptake_sum_proxy",
    "NH4_burden",
    "Asp_Mal_shuttle_proxy",
    "Glutamine_fraction_proxy",
]

core_metrics = [c for c in core_metrics if c in df.columns]

for c in core_metrics:
    df[c] = pd.to_numeric(df[c], errors="coerce")

# ------------------------------------------------------------
# 3. Clone-level ranked table
# ------------------------------------------------------------
rank_cols = ["Clone", "Group"] + core_metrics
clone_ranked = df[rank_cols].copy()

if "TCA_fraction_proxy" in clone_ranked.columns:
    clone_ranked["rank_TCA_fraction_high"] = clone_ranked["TCA_fraction_proxy"].rank(ascending=False)

if "AA_uptake_sum_proxy" in clone_ranked.columns:
    clone_ranked["rank_AA_uptake_high"] = clone_ranked["AA_uptake_sum_proxy"].rank(ascending=False)

if "Redox_overflow_ratio" in clone_ranked.columns:
    clone_ranked["rank_redox_overflow_low"] = clone_ranked["Redox_overflow_ratio"].rank(ascending=True)

if "NH4_burden" in clone_ranked.columns:
    clone_ranked["rank_NH4_burden_low"] = clone_ranked["NH4_burden"].rank(ascending=True)

rank_metric_cols = [c for c in clone_ranked.columns if c.startswith("rank_")]
if rank_metric_cols:
    clone_ranked["overall_efficiency_rank_score"] = clone_ranked[rank_metric_cols].mean(axis=1)
    clone_ranked = clone_ranked.sort_values("overall_efficiency_rank_score", ascending=True)

clone_ranked.to_csv(OUTDIR / "clone_flux_ranked.csv", index=False)

# ------------------------------------------------------------
# 4. Group summary
# ------------------------------------------------------------
grouped = df.groupby("Group", dropna=False)[core_metrics]

group_mean = grouped.mean().reindex(GROUP_ORDER)
group_std = grouped.std().reindex(GROUP_ORDER)
group_count = grouped.count().reindex(GROUP_ORDER)
group_sem = group_std / np.sqrt(group_count)

group_mean.to_csv(OUTDIR / "group_summary_mean.csv")
group_std.to_csv(OUTDIR / "group_summary_std.csv")
group_sem.to_csv(OUTDIR / "group_summary_sem.csv")
group_count.to_csv(OUTDIR / "group_summary_count.csv")

group_mean_long = group_mean.reset_index().melt(id_vars="Group", var_name="Metric", value_name="Mean")
group_sem_long = group_sem.reset_index().melt(id_vars="Group", var_name="Metric", value_name="SEM")
group_long = group_mean_long.merge(group_sem_long, on=["Group", "Metric"], how="left")
group_long.to_csv(OUTDIR / "group_summary_long_for_plotting.csv", index=False)

# ------------------------------------------------------------
# 5. Interpretation flags
# ------------------------------------------------------------
def get_mean(group, metric):
    try:
        return float(group_mean.loc[group, metric])
    except Exception:
        return np.nan

def compare_order(metric, expected_order, high_good=True):
    vals = [(g, get_mean(g, metric)) for g in expected_order if g in group_mean.index]
    vals = [(g, v) for g, v in vals if not np.isnan(v)]
    if len(vals) < 2:
        return "Not enough groups"
    sorted_groups = [g for g, _ in sorted(vals, key=lambda x: x[1], reverse=high_good)]
    return " > ".join(sorted_groups)

checks = [
    ("TCA_input_proxy", "Absolute central flux amount", "Large value means larger total central flux proxy, but not necessarily better productivity."),
    ("TCA_fraction_proxy", "Carbon efficiency / oxidative fraction", "High > Mother > Low supports efficient carbon routing in high producers."),
    ("Redox_overflow_ratio", "Lactate overflow burden", "Low value is desirable; Low > Mother > High suggests low producers waste more carbon as lactate."),
    ("AA_uptake_sum_proxy", "Amino acid utilization", "High > Mother > Low supports stronger building-block usage in high producers."),
    ("NH4_burden", "Nitrogen waste burden", "Low value is desirable; Low > Mother > High suggests stronger amino acid catabolism/waste in low producers."),
]

interpret_rows = []
for metric, meaning, note in checks:
    if metric not in group_mean.columns:
        continue
    interpret_rows.append({
        "Metric": metric,
        "Meaning": meaning,
        "Observed_order_high_to_low": compare_order(metric, GROUP_ORDER, high_good=True),
        "Observed_order_low_to_high": compare_order(metric, GROUP_ORDER, high_good=False),
        "Interpretation_note": note,
    })

interpret = pd.DataFrame(interpret_rows)
interpret.to_csv(OUTDIR / "interpretation_flags_by_group.csv", index=False)

# ------------------------------------------------------------
# 6. Escher-style map input
# ------------------------------------------------------------
absolute_rows = [
    ("GLCtex_or_EX_glc", "Glucose uptake", "GLC_uptake"),
    ("PYR_from_glycolysis", "Glycolysis to pyruvate proxy", "Glycolysis_to_PYR_proxy"),
    ("LDH_L_or_lactate_branch", "Lactate branch", "Lactate_branch"),
    ("PYR_to_TCA", "Pyruvate to TCA proxy", "PYR_to_TCA_proxy"),
    ("GLNtex_or_EX_gln", "Glutamine uptake", "GLN_uptake"),
    ("GLN_to_TCA", "Glutaminolysis to TCA proxy", "Glutaminolysis_to_TCA_proxy"),
    ("TCA_input", "Total TCA input proxy", "TCA_input_proxy"),
]

absolute_map = []
for rid, display, metric in absolute_rows:
    if metric not in group_mean.columns:
        continue
    absolute_map.append({
        "reaction_id": rid,
        "display_name": display,
        "source_metric": metric,
        "High": get_mean("High", metric),
        "Mother": get_mean("Mother", metric),
        "Low": get_mean("Low", metric),
        "map_type": "absolute_flux_proxy",
    })

absolute_map = pd.DataFrame(absolute_map)

eff_rows = [
    ("TCA_efficiency", "TCA fraction proxy", "TCA_fraction_proxy", "higher"),
    ("Lactate_overflow_burden", "Redox overflow ratio", "Redox_overflow_ratio", "lower"),
    ("AA_utilization", "Amino acid uptake sum proxy", "AA_uptake_sum_proxy", "higher"),
    ("NH4_burden", "Ammonia burden", "NH4_burden", "lower"),
]

efficiency_map = []
for rid, display, metric, direction in eff_rows:
    if metric not in group_mean.columns:
        continue
    efficiency_map.append({
        "reaction_id": rid,
        "display_name": display,
        "source_metric": metric,
        "High": get_mean("High", metric),
        "Mother": get_mean("Mother", metric),
        "Low": get_mean("Low", metric),
        "map_type": "efficiency_burden_proxy",
        "desirable_direction": direction,
    })

efficiency_map = pd.DataFrame(efficiency_map)

absolute_map.to_csv(OUTDIR / "escher_absolute_flux_input.csv", index=False)
efficiency_map.to_csv(OUTDIR / "escher_efficiency_burden_input.csv", index=False)

# ------------------------------------------------------------
# 7. Summary text
# ------------------------------------------------------------
summary_txt = OUTDIR / "plain_language_summary.txt"

lines = []
lines.append("CHOmpact Fig3-style group summary\n\n")
lines.append("Core interpretation framework:\n")
lines.append("- TCA_input_proxy: absolute central flux proxy. Larger does not always mean better productivity.\n")
lines.append("- TCA_fraction_proxy: carbon routing efficiency toward oxidative metabolism.\n")
lines.append("- Redox_overflow_ratio: lactate overflow burden. Lower is better.\n")
lines.append("- AA_uptake_sum_proxy: amino acid utilization/building block proxy.\n")
lines.append("- NH4_burden: nitrogen waste burden. Lower is better.\n\n")

for _, row in interpret.iterrows():
    lines.append(f"{row['Metric']}\n")
    lines.append(f"  Meaning: {row['Meaning']}\n")
    lines.append(f"  Observed high-to-low: {row['Observed_order_high_to_low']}\n")
    lines.append(f"  Note: {row['Interpretation_note']}\n\n")

lines.append("Suggested biological story if observed orders match your current result:\n")
lines.append("- TCA_fraction_proxy: High > Mother > Low\n")
lines.append("- Redox_overflow_ratio: Low > Mother > High\n")
lines.append("- AA_uptake_sum_proxy: High > Mother > Low\n")
lines.append("- NH4_burden: Low > Mother > High\n\n")
lines.append("High-producing clones likely show reduced lactate overflow, higher carbon routing efficiency, stronger amino acid utilization, and lower nitrogen waste burden.\n")
lines.append("Low-producing clones may have larger absolute flux but less efficient carbon/nitrogen utilization.\n")

summary_txt.write_text("".join(lines), encoding="utf-8")

print("\nSaved output files to:")
print(OUTDIR)

print("\nKey outputs:")
for f in [
    "group_summary_mean.csv",
    "group_summary_sem.csv",
    "clone_flux_ranked.csv",
    "interpretation_flags_by_group.csv",
    "escher_absolute_flux_input.csv",
    "escher_efficiency_burden_input.csv",
    "plain_language_summary.txt",
]:
    print(" -", OUTDIR / f)

print("\nGroup mean preview:")
print(group_mean)

print("\nInterpretation preview:")
print(interpret)
