# CHOmpact Fig3-style Group Summary Pipeline

## Purpose
This script takes `central_flux_proxy_from_exchange_rates.csv` and generates:
1. Group summary tables
2. Clone-level ranking
3. Interpretation flags
4. Escher-style map input files
5. Plain-language biological summary

## Expected input
`/home/MCET03/06_Metabolomics/CHO_METABOLOMICS_workstation/results/practice_20aa/chompact_fig3_style/central_flux_proxy_from_exchange_rates.csv`

## Run
```bash
cd /home/MCET03/06_Metabolomics/CHO_METABOLOMICS_workstation
python run_chompact_group_summary.py
```

## Important
If your input file does not have a `Group` column, edit `GROUP_MAP` in the script.

Example:
```python
GROUP_MAP = {
    "1": "Mother",
    "2": "High",
    "8": "High",
    "9": "High",
    "3": "Low",
    "4": "Low",
}
```

## Outputs
Saved in:
`results/practice_20aa/chompact_fig3_style/group_summary/`

- `group_summary_mean.csv`
- `group_summary_sem.csv`
- `clone_flux_ranked.csv`
- `interpretation_flags_by_group.csv`
- `escher_absolute_flux_input.csv`
- `escher_efficiency_burden_input.csv`
- `plain_language_summary.txt`
