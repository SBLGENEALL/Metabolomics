# CHO_METABOLOMICS — final clean workflow

## 목적

이 최종본은 **iCHO3K production model을 이용해 CHO clone 간 central metabolism / mAb-production-related flux 차이를 비교하는 FBA/FVA 분석 파이프라인**입니다.

중요한 해석 기준:

- 이 파이프라인은 `DM_igg_g` objective 값으로 IgG titer 순위를 직접 맞히는 모델이 아닙니다.
- `DM_igg_g` direct maximization이 flat/capped로 나올 수 있으므로, objective value 자체를 productivity prediction으로 해석하지 않습니다.
- 핵심 결과는 measured exchange-rate constraint를 넣었을 때의 **pFBA flux state, FVA range, High-vs-Low flux difference, focused Escher map**입니다.
- Product-sequence AA requirement, KO screening, RECON1 large-map annotation, direct-objective ranking figure는 최종 메인 워크플로우에서 제외했습니다.

---

## 포함 파일

```text
CHO_METABOLOMICS/
├─ run_pipeline.py
├─ requirements.txt
├─ README_FINAL.md
├─ src/
│  ├─ config.py
│  └─ fba_utils.py
├─ scripts/steps/
│  ├─ 01_load_data.py
│  ├─ 02_map_metabolites.py
│  ├─ 03_run_fba.py
│  ├─ 06_figures.py
│  ├─ export_escher_flux.py
│  ├─ 14_central_mab_fva_report.py
│  └─ 16_focused_escher_maps.py
├─ data/raw/practice_20aa/
│  └─ CHO_raw_data_practice_20AA.xlsx
└─ model/iCHO3K/
   └─ iCHO3K_cho_prod_generic_unblocked.json
```

불필요한 이전 README, patch note, KO script, product-sequence script, RECON1 annotation script, old result files은 제외했습니다.

---

## 권장 실행 명령어

Windows Anaconda Prompt 기준:

```bat
cd C:\CHO_METABOLOMICS

rmdir /s /q data\processed
rmdir /s /q results
rmdir /s /q logs

python run_pipeline.py --dataset practice_20aa --rate_days 7,10 --analysis_mode both --constraint_policy production_relaxed --feed_volume_mode interval --demand_scale auto --steps 1,2,3,10,14,16,6
```

---

## Step 의미

| Step | 의미 |
|---:|---|
| 1 | raw culture data에서 feed-corrected exchange rate 계산 |
| 2 | metabolite를 iCHO3K exchange reaction으로 매핑 |
| 3 | FBA/pFBA 실행. `predict`는 IgG input 없음, `explain`은 measured qIgG demand 고정 |
| 10 | Escher reaction-data JSON 생성 |
| 14 | central metabolism + mAb pathway flux/FVA report 생성 |
| 16 | focused Escher map, focused flux/FVA JSON, Fig12 생성 |
| 6 | Fig1/2/3/5/8 summary figure 생성 |

---

## 주요 결과 파일

### Figures

```text
results/practice_20aa/figures/Fig1_IgG_timecourse.png
results/practice_20aa/figures/Fig2_rate_heatmap.png
results/practice_20aa/figures/Fig3_lac_glc_ratio.png
results/practice_20aa/figures/Fig5_high_vs_low_rates.png
results/practice_20aa/figures/Fig8_summary_panel.png
results/practice_20aa/figures/Fig10_central_mab_flux_heatmap.png
results/practice_20aa/figures/Fig10B_central_mab_flux_zscore.png
results/practice_20aa/figures/Fig11_central_mab_flux_delta.png
results/practice_20aa/figures/Fig12_focused_core_fva_range.png
results/practice_20aa/figures/Fig12B_focused_core_fva_range_zscore.png
results/practice_20aa/figures/Fig12C_focused_fva_high_low_delta.png
```

### Tables

```text
results/practice_20aa/tables/exchange_rates.csv
results/practice_20aa/tables/fba_results.csv
results/practice_20aa/tables/prediction_fba_results.csv
results/practice_20aa/tables/central_mab_flux_state.csv
results/practice_20aa/tables/central_mab_flux_state_zscore_matrix.csv
results/practice_20aa/tables/central_mab_fva_report.csv
results/practice_20aa/tables/central_mab_flux_delta_high_low_measured_demand.csv
```

### Focused Escher maps

```text
results/practice_20aa/escher_maps/focused/CHO_focus_core_carbon_map.json
results/practice_20aa/escher_maps/focused/CHO_focus_glycolysis_lactate_map.json
results/practice_20aa/escher_maps/focused/CHO_focus_ppp_map.json
results/practice_20aa/escher_maps/focused/CHO_focus_tca_gln_map.json
```

### Focused Escher data

가장 먼저 볼 조합:

```text
Map:
results/practice_20aa/escher_maps/focused/CHO_focus_core_carbon_map.json

Data:
results/practice_20aa/tables/focused_escher/focused_escher_flux_high_minus_low_cho.json
```

해석:

```text
positive = HighAvg에서 더 큰 flux
negative = LowAvg에서 더 큰 flux
```

FVA range 차이를 Escher에 올리고 싶으면:

```text
results/practice_20aa/tables/focused_escher/focused_fva_measured_demand_high_minus_low_range_cho.json
```

---

## Practice 9-clone demo 데이터

최종 practice data는 발표/시연용으로 group 차이가 잘 보이도록 일부러 분리했습니다.

```text
Low01, Low02, Low03
Mother01, Mother02, Mother03
High01, High02, High03
```

설계 의도:

- High: 높은 IgG, 낮은 glucose burden, lactate consumption/low overflow, 낮은 NH4, 높은 mAb-supportive flux
- Mother: 중간 phenotype
- Low: 낮은 IgG, 높은 glucose uptake, lactate secretion, 높은 glutamine/NH4 burden

이 데이터는 실제 생물학적 결론용이 아니라 **FBA/FVA/Escher pipeline 설명용 synthetic demo**입니다.

---

## 발표용 한 줄 메시지

> 이 파이프라인은 IgG titer를 직접 맞히는 예측기가 아니라, measured metabolite exchange를 iCHO3K production model에 constraint로 적용해 High/Mother/Low producer의 central metabolism, lactate handling, glutamine/nitrogen metabolism, mAb-related flux state와 FVA flexibility를 비교하는 mechanistic analysis framework입니다.


## 2026-05-24 improvement set

The final workflow now includes additional robustness modules that do not require genomics/transcriptomics:

- Step 17: raw data / rate-calculation QC
- Step 18: interval-wise focused pFBA/FVA
- Step 19: pathway-level scores, FVA overlap/separation, and constraint sensitivity
- Step 20: automatic Markdown report

Recommended command:

```bat
python run_pipeline.py --dataset practice_20aa --rate_days 7,10 --analysis_mode both --constraint_policy production_relaxed --feed_volume_mode interval --demand_scale auto --steps 17,1,2,3,10,14,16,18,19,20,6
```

Important scope note: without spent-media/time-course metabolite data, exchange-constrained FBA/FVA is weakly constrained. FLEX2-only or clone metadata-only data can be used for grouping/QC and later omics integration, but it should not be over-interpreted as a flux analysis.
