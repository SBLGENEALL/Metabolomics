# CHO_METABOLOMICS final package

이 패키지는 기존 script, 수정된 Escher export script, CHO/iCHO3K 모델, practice_20aa raw data, Escher 결과 JSON, RECON1 pretty map annotation 결과를 모두 포함합니다.

## 1. 권장 실행 위치

터미널/Anaconda Prompt에서 `CHO_METABOLOMICS` 폴더로 이동한 뒤 실행하세요.

```bash
cd CHO_METABOLOMICS
```

## 2. 환경 설치

```bash
pip install -r requirements.txt
```

이미 cobra/swiglpk/optlang/openpyxl/pandas가 설치된 conda 환경이면 생략 가능합니다.

## 3. 전체 기본 실행

```bash
python run_pipeline.py --dataset practice_20aa --rate_days 7,10 --steps 1,2,3,10
```

- Step 1: raw Excel load + rate 계산
- Step 2: metabolite mapping + constraints 생성
- Step 3: FBA 실행
- Step 10: Escher용 flux JSON 생성

## 4. Escher용 주요 결과 위치

```text
results/practice_20aa/tables/escher_flux_high_cho_full.json
results/practice_20aa/tables/escher_flux_high_cho_nonzero.json
results/practice_20aa/tables/escher_flux_low_cho_full.json
results/practice_20aa/tables/escher_flux_low_cho_nonzero.json
results/practice_20aa/tables/escher_flux_high_minus_low_cho.json
```

## 5. RECON1 pretty map에 올릴 파일

Escher 웹에서 built-in map으로 `Homo sapiens → RECON1.Glycolysis TCA PPP`를 선택한 뒤 아래 파일을 `Load Data → Reaction data`로 올리세요.

```text
results/practice_20aa/tables/recon1_pretty_map/escher_flux_high_recon1_all_maps.json
results/practice_20aa/tables/recon1_pretty_map/escher_flux_low_recon1_all_maps.json
results/practice_20aa/tables/recon1_pretty_map/escher_flux_high_minus_low_recon1_all_maps.json
```

## 6. RECON1 annotation 재생성

인터넷이 되는 PC에서는 공식 Escher map manifest를 바탕으로 annotation 결과를 다시 만들 수 있습니다.

```bash
python scripts/steps/12_annotate_flux_to_recon1_maps.py --dataset practice_20aa
```

## 7. 포함된 데이터/모델

```text
data/raw/practice_20aa/CHO_raw_data_practice_20AA.xlsx
model/iCHO3K/iCHO3K_cho_prod_generic_unblocked.json
model/iCHO3K/iCHO3K_cho_generic_unblocked.json
model/iCHO3K/reference_dataset/iCHO3K.xlsx
```
