# CHOmpact Figure 3-style Reduced Flux Pipeline

Files:
- CHOmpact_Fig3_style_flux_template.xlsx
- example_input_timecourse.csv
- run_reduced_flux_pipeline.py

Run:
```bash
python run_reduced_flux_pipeline.py --input example_input_timecourse.csv --outdir output
```

Interpretation:
- This pipeline produces relative central flux proxies from spent-media changes.
- It is useful for clone-to-clone comparison and Figure 3-style visualization.
- It is not a direct intracellular flux quantification or full CHOmpact reproduction.
