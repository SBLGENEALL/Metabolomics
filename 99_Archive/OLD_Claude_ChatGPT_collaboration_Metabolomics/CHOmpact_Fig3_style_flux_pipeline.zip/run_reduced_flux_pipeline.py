import argparse
from pathlib import Path
import numpy as np
import pandas as pd

METABOLITES = {
    "Glucose": "uptake", "Lactate": "secretion",
    "Glutamine": "uptake", "Glutamate": "secretion",
    "Alanine": "secretion", "Asparagine": "uptake",
    "Aspartate": "uptake", "Serine": "uptake",
    "Glycine": "uptake", "Leucine": "uptake",
    "Isoleucine": "uptake", "Ammonia": "secretion",
    "Malate": "secretion", "Citrate": "secretion", "Succinate": "secretion",
}

def calc_exchange_flux(df):
    out = df[["Sample_ID", "Clone", "Group", "Phase"]].copy()
    out["delta_t_day"] = (df["t_end_h"] - df["t_start_h"]) / 24.0
    out["avg_VCD_1e6_cells_mL"] = df[["VCD_start_1e6_cells_mL", "VCD_end_1e6_cells_mL"]].mean(axis=1)
    for met, mode in METABOLITES.items():
        s, e = f"{met}_start_mM", f"{met}_end_mM"
        if s not in df.columns or e not in df.columns:
            continue
        if mode == "uptake":
            out[f"{met}_uptake"] = (df[s] - df[e]) / out["delta_t_day"] / out["avg_VCD_1e6_cells_mL"]
        else:
            out[f"{met}_secretion"] = (df[e] - df[s]) / out["delta_t_day"] / out["avg_VCD_1e6_cells_mL"]
    out["QC_flag"] = np.where((out["delta_t_day"] <= 0) | (out["avg_VCD_1e6_cells_mL"] <= 0), "Check time/VCD", "OK")
    return out

def calc_central_proxy(ex):
    out = ex[["Sample_ID", "Clone", "Group", "Phase"]].copy()
    def get(col):
        return ex[col] if col in ex.columns else 0.0
    out["GLC_uptake"] = get("Glucose_uptake")
    out["Glycolysis_to_PYR_proxy"] = out["GLC_uptake"] * 2.0
    out["Lactate_branch"] = get("Lactate_secretion")
    out["Alanine_branch"] = get("Alanine_secretion")
    out["PYR_to_TCA_proxy"] = (out["Glycolysis_to_PYR_proxy"] - out["Lactate_branch"] - out["Alanine_branch"]).clip(lower=0)
    out["GLN_uptake"] = get("Glutamine_uptake")
    out["GLU_secretion"] = get("Glutamate_secretion")
    out["Glutaminolysis_to_TCA_proxy"] = (out["GLN_uptake"] - out["GLU_secretion"]).clip(lower=0)
    out["TCA_input_proxy"] = out["PYR_to_TCA_proxy"] + out["Glutaminolysis_to_TCA_proxy"]
    aa_cols = [c for c in ["Asparagine_uptake","Aspartate_uptake","Serine_uptake","Glycine_uptake","Leucine_uptake","Isoleucine_uptake"] if c in ex.columns]
    out["AA_uptake_sum_proxy"] = ex[aa_cols].sum(axis=1) if aa_cols else 0.0
    out["Asp_Mal_shuttle_proxy"] = np.abs(get("Aspartate_uptake")) + np.abs(get("Malate_secretion"))
    out["NH4_burden"] = get("Ammonia_secretion")
    out["Redox_overflow_ratio"] = out["Lactate_branch"] / out["Glycolysis_to_PYR_proxy"].replace(0, np.nan)
    out["Interpretation_flag"] = np.where(out["Redox_overflow_ratio"] > 0.7, "High lactate overflow",
        np.where(out["TCA_input_proxy"] > out["Glutaminolysis_to_TCA_proxy"], "TCA-biased proxy", "Balanced/Review"))
    return out

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--outdir", default="reduced_flux_output")
    args = parser.parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.input)
    exchange = calc_exchange_flux(df)
    central = calc_central_proxy(exchange)
    exchange.to_csv(outdir / "01_exchange_flux_by_clone.csv", index=False)
    central.to_csv(outdir / "02_central_flux_proxy_by_clone.csv", index=False)
    print("Saved outputs to", outdir)

if __name__ == "__main__":
    main()