# CHO_METABOLOMICS patch notes

## 수정 파일

1. `scripts/steps/export_escher_flux.py`
   - `sol.fluxes` 순회 버그 수정
     - 기존 코드는 pandas Series를 값으로 순회한 뒤 `sol.fluxes[v]`로 접근해서 `KeyError: 0.0`가 발생했습니다.
   - `--policy auto|strict|visualization|none` 옵션 추가
   - strict constraint가 infeasible 또는 all-zero이면 Escher 시각화용 `visualization` policy로 자동 재시도합니다.
   - JSON이 생성되지 않는 경우를 방지하기 위해 status report를 항상 저장합니다.
   - 생성 파일:
     - `escher_flux_high_full.json`
     - `escher_flux_high_nonzero.json`
     - `escher_flux_low_full.json`
     - `escher_flux_low_nonzero.json`
     - `escher_flux_high_minus_low.json`
     - `escher_flux_status.csv`
     - `escher_guide.txt`

2. `scripts/steps/02_map_metabolites.py`
   - 측정 rate를 양/음수 좁은 구간으로 강제하던 부분을 directional bound로 수정했습니다.
   - uptake(q<0): `(q * 1.2, 0.0)`
   - secretion(q>0): `(0.0, q * 1.2)`
   - 이 수정으로 high/low 평균 constraint가 쉽게 infeasible이 되는 문제를 줄였습니다.

3. `run_pipeline.py`
   - `--top_n` 옵션을 추가하고 01 step으로 전달하도록 수정했습니다.
   - 예: `python run_pipeline.py --dataset practice_20aa --rate_days 7,10 --top_n 9 --steps 1,2,3,10`

## 권장 실행 명령어

빠르게 Escher JSON까지 만들려면:

```bash
python run_pipeline.py --dataset practice_20aa --rate_days 7,10 --steps 1,2,3,10
```

High/Low clone을 각각 9개로 잡고 싶으면:

```bash
python run_pipeline.py --dataset practice_20aa --rate_days 7,10 --top_n 9 --steps 1,2,3,10
```

Escher JSON만 다시 만들려면:

```bash
python scripts/steps/export_escher_flux.py --dataset practice_20aa
```

strict constraint만 사용하고 싶으면:

```bash
python scripts/steps/export_escher_flux.py --dataset practice_20aa --policy strict
```

## 테스트 결과

업로드된 `CHO_raw_data_practice_20AA.xlsx`와 `iCHO3K` 모델로 다음 명령어를 테스트했습니다.

```bash
python run_pipeline.py --dataset practice_20aa --rate_days 7,10 --steps 1,2,3,10
```

결과적으로 Escher JSON이 정상 생성되었습니다.

- `escher_flux_high_nonzero.json`: 520 reactions
- `escher_flux_low_nonzero.json`: 739 reactions
- `escher_flux_high_minus_low.json`: 852 reactions

주의: `visualization` policy는 Escher 그림을 만들기 위한 fallback입니다. 정량 FBA/FVA 결론은 `fba_results.csv`, `fva_comparison.csv`와 함께 해석하세요.
