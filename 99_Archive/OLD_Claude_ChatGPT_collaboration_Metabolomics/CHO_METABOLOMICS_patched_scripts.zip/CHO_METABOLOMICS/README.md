# CHO_METABOLOMICS — FBA/FVA Pipeline

항체 고생산 CHO 세포주 대사 분석 + 개선 타겟 탐색

## 빠른 시작

```bash
conda create -n cho python=3.10 -y && conda activate cho
pip install -r requirements.txt
python setup_env.py   # iCHO3K 모델 자동 다운로드

# 데이터 배치
data/raw/practice_20aa/CHO_raw_data_practice_20AA.xlsx
data/raw/sowa2020/mmc1.xlsx   (직접 추가)
model/iCHO3K/*.json           (setup_env.py 자동 다운로드)

# 전체 파이프라인 실행
python run_pipeline.py --dataset practice_20aa --rate_days 7,10

# 추가 Figure
python scripts/steps/fig_qp_timeseries.py --dataset practice_20aa
python scripts/steps/fig_pathway_flux_map.py --dataset practice_20aa
python scripts/steps/multi_interval_fba.py --dataset practice_20aa
python scripts/steps/export_escher_flux.py --dataset practice_20aa
```

## 파이프라인 단계

| Step | 파일 | 내용 | 근거 논문 |
|------|------|------|-----------|
| 0 | 00_auto_objective.py | Objective 자동 선택 (IgG r 기반) | Feist & Palsson 2010 |
| 1 | 01_load_data.py | 데이터 로딩 + Feed-corrected rate | Goudar et al. 2005 |
| 2 | 02_map_metabolites.py | 대사물질 → Exchange ID 매핑 | — |
| 3 | 03_run_fba.py | FBA 클론별 실행 | Orth et al. 2010 |
| 4 | 04_run_fva.py | FVA High vs Low | Mahadevan & Schilling 2003 |
| 5 | 05_ko_screening.py | Reaction KO 스크리닝 | Lim et al. 2010 |
| 6 | 06_figures.py | 논문 Figure 1~8 | — |
| + | fig_qp_timeseries.py | qP + Growth-Production trade-off | Templeton 2013 |
| + | fig_pathway_flux_map.py | 상세 Flux pathway map (40+ nodes) | King et al. 2015 |
| + | multi_interval_fba.py | 구간별 FBA → 최적 구간 탐색 | Mulukutla 2012 |
| + | export_escher_flux.py | Escher JSON export (전체 flux) | King et al. 2015 |

## Escher Flux Map 사용

```bash
python scripts/steps/export_escher_flux.py --dataset practice_20aa
```
→ results/practice_20aa/tables/escher_flux_high_nonzero.json  
→ https://escher.github.io 에서 업로드

**비어있는 반응이 많은 이유:**  
이전에는 exchange reactions만 저장. 이제 전체 반응 포함.  
iCHO3K ID와 BiGG ID가 다른 반응은 자동 변환 테이블 적용.

## 핵심 수정사항

- `apply_bounds`: cobra bound 순서 충돌 방지
- `fix_one_sided`: lb/ub 단방향 보정 (Day 7→10 lactate 재소비 처리)
- Fig 3: constraint 아닌 실측 rate 기반 Lac/Glc ratio
- Fig 7: 3단계 반응 탐색 + 자동 높이
- Objective: IgG titer Pearson r 기반 자동 선택

## 새 데이터 추가

```
data/raw/own_experiment/내실험.xlsx 배치 후:
python run_pipeline.py --dataset own_experiment --rate_days 7,10
```

## 참고 논문

| 분석 | 논문 |
|------|------|
| FBA | Orth et al. 2010 Nat Biotechnol 28:245 |
| iCHO3K | Hernandez Bort et al. 2023 NPJ Syst Biol |
| Rate | Goudar et al. 2005 Biotechnol Prog 21:1193 |
| Lac/Glc | Zagari et al. 2013 New Biotechnology 30:238 |
| 구간 | Mulukutla et al. 2012 Trends Biotechnol 30:616 |
| LDH KO | Lim et al. 2010 Metab Eng 12:614 |
| FVA | Mahadevan & Schilling 2003 Metab Eng 5:264 |
| qP | Templeton et al. 2013 Biotechnol Bioeng 110:2508 |
| Escher | King et al. 2015 PLOS Comput Biol 11:e1004321 |
| Fouladiha | Fouladiha et al. 2020 Bioprocess Biosyst Eng 44:1 |
